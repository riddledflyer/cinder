#pragma once

#define CINDER_VERSION "3.15"
#define CINDER_REVISION 45
