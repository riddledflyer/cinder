#!/usr/bin/env python3
"""Build a banner the HOME Menu can play: stereo looping audio, every region slot filled."""
import struct
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
PNG = HERE / "banner.png"
WAV = HERE / "banner.wav"
CWAV = HERE / "banner.bcwav"
OUT = HERE / "banner.bin"

# banner.wav is the first 3 seconds of the in-app track. The HOME Menu
# refuses anything longer (it beeps or plays the placeholder instead).
# Stereo, 16-bit, 32000 Hz, looping.
if not WAV.exists() or WAV.stat().st_size < 64:
    raise SystemExit(f"missing banner audio: {WAV}")

subprocess.check_call(
    ["bannertool", "makecwav", "-i", str(WAV), "-o", str(CWAV), "-l", "true"]
)

# -i is the common graphic. The rest are the per-region slots. A zero slot
# makes some menus dereference the missing graphic instead of falling back.
slots = [
    "-eei", "-efi", "-egi", "-eii", "-esi", "-edi", "-epi",
    "-eri", "-jji", "-uei", "-ufi", "-usi", "-upi",
]
cmd = ["bannertool", "makebanner", "-i", str(PNG)]
for flag in slots:
    cmd.extend([flag, str(PNG)])
cmd.extend(["-ca", str(CWAV), "-o", str(OUT)])
subprocess.check_call(cmd)

blob = OUT.read_bytes()
cgfx = [struct.unpack_from("<I", blob, 8 + i * 4)[0] for i in range(14)]
cwav_off = struct.unpack_from("<I", blob, 0x84)[0]
info = blob[cwav_off + 0x40 :]
channels = struct.unpack_from("<I", info, 0x1C)[0]
loop = info[9]
if any(off == 0 for off in cgfx):
    raise SystemExit("banner is missing a region graphic")
if channels != 2 or loop != 1:
    raise SystemExit(f"banner audio is channels={channels} loop={loop}, want stereo looping")
print(f"banner {len(blob)} bytes, {channels}ch loop={loop}")
