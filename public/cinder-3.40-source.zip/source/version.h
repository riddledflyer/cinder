#pragma once

#define CINDER_VERSION "3.40"
#define CINDER_REVISION 70
