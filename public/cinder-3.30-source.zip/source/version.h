#pragma once

#define CINDER_VERSION "3.30"
#define CINDER_REVISION 60
