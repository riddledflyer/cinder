#pragma once

#define CINDER_VERSION "3.48"
#define CINDER_REVISION 78
