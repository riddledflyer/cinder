#pragma once

#define CINDER_VERSION "3.44"
#define CINDER_REVISION 74
