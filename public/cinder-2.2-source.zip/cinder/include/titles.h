#pragma once

#include <3ds.h>
#include <stdbool.h>
#include <stddef.h>

#define CINDER_TITLE_ID 0x0004000000C1D100ULL
#define TITLE_CAP 1024
#define DELETE_CHUNK 16

typedef enum {
    KIND_GAME = 0,
    KIND_DEMO,
    KIND_UPDATE,
    KIND_DLC,
    KIND_DSIWARE,
    KIND_SYSTEM
} TitleKind;

/* DSi banner 0x0103 flipbook. Bitmaps are 32x32 4bpp, palettes RGB555.
 * Sequence tokens: bit15 flip V, bit14 flip H, bits13-11 palette,
 * bits10-8 bitmap, bits7-0 duration in 60Hz frames. Duration 0 ends
 * the sequence (a token like 0x0100 is not a frame). */
typedef struct {
    u8 bitmap[8][0x200];
    u16 palette[8][16];
    u16 seq[64];
    u8 seq_len;
} IconAnim;

typedef struct {
    u64 id;
    FS_MediaType media;
    u64 size;
    u16 version;
    TitleKind kind;
    bool deletable;
    bool selected;
    char name[96];
    char publisher[64];
    char product[17];
    /* Native RGB565 icon. 48x48 for an SMDH large icon, 32x32 for a DSi
     * banner. NULL if it could not be read. icon_w is 0 in that case.
     * DSiWare uses pixel 0 as transparent. Kept at native size so the
     * screen can draw it 1:1 instead of a blurry rescale. */
    u16 *icon;
    u8 icon_w;
    /* NULL unless this DSiWare title has an animated banner. */
    IconAnim *anim;
} TitleRec;

typedef struct {
    TitleRec *items;
    u32 count;
    FS_MediaType media;
} TitleList;

/* Current process title id, or CINDER_TITLE_ID if it cannot be read. */
u64 titles_self_id(void);

Result titles_load(TitleList *list, FS_MediaType media);
/* SD and NAND together. Real system titles (modules, applets, data
 * archives) and Cinder are left out. Games, including Nintendo's, stay.
 * A title id that is not a known system category is kept. */
Result titles_load_all(TitleList *list);
void titles_free(TitleList *list);

const char *titles_kind_name(TitleKind kind);
char titles_kind_char(TitleKind kind);
/* True only for system modules, applets, and system data archives.
 * Retail and Nintendo games (00040000 and the demo/update/DLC highs)
 * are not system software. Neither is homebrew with some other high. */
bool titles_is_system_id(u64 id);
TitleKind titles_kind_of(u64 id);
void titles_format_size(char *out, size_t n, u64 bytes);
void titles_format_version(char *out, size_t n, u16 version);
void smdh_fill_names(TitleRec *title, u8 language);
/* Name, publisher, and the 48x48 icon from an SMDH blob. icon is malloc'd. */
bool smdh_from_blob(const u8 *blob, u32 got, u8 language,
                    char *name, size_t name_len,
                    char *publisher, size_t pub_len,
                    u16 **icon, u8 *icon_w);
/* DSiWare only. Reads the TWL NAND banner (static icon, and the 0x0103 flipbook). */
void dsi_fill(TitleRec *title, u8 language);
void dsi_shutdown(void);

/* Writes one 32x32 RGB565 frame. Pixel 0 is transparent. */
bool titles_anim_frame(const IconAnim *anim, u32 tick, u16 *dst);

/* Writes selected ids. When include_related is set, matching updates and DLC
 * on the same media are added. Returns the number written, capped at cap. */
u32 titles_collect(const TitleList *list, u64 *out, u32 cap, bool include_related);

typedef void (*TitleProgressFn)(u32 index, u32 total, u64 id, Result rc, bool ticket_ok, void *user);

/* Deletes user titles with AM_DeleteUserTitles. A failed chunk is retried
 * one title at a time. System titles never reach this list. */
Result titles_delete(FS_MediaType media, const u64 *ids, u32 count, bool tickets,
                     TitleProgressFn progress, void *user);
