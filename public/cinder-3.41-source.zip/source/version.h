#pragma once

#define CINDER_VERSION "3.41"
#define CINDER_REVISION 71
