#pragma once

#define CINDER_VERSION "3.36"
#define CINDER_REVISION 66
