#pragma once

#define CINDER_VERSION "3.47"
#define CINDER_REVISION 77
