#pragma once

#define CINDER_VERSION "3.21"
#define CINDER_REVISION 51
