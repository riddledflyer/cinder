#!/usr/bin/env python3
"""Build the HOME Menu banner.

The clip is a later part of the track, already at full level. It plays, then
fades out. There is no fade in. The menu wants stereo 16-bit PCM under 3
seconds and not looping, which bannertool's -a path writes.
"""
import struct
import subprocess
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
PNG = HERE / "banner.png"
WAV = HERE / "banner.wav"
OUT = HERE / "banner.bin"
MP3_CANDIDATES = (
    Path("/workspace/attachments/bgm.mp3"),
    HERE / "bgm.mp3",
)
CLIP_START = 94.5
CLIP_SECONDS = 2.0
RATE = 32000
FADE_OUT = 0.40


def write_clip():
    mp3 = next((path for path in MP3_CANDIDATES if path.exists()), None)
    if mp3 is None:
        if not WAV.exists():
            raise SystemExit("missing banner audio")
        return
    frames = int(CLIP_SECONDS * RATE)
    raw = subprocess.check_output(
        [
            "ffmpeg", "-v", "error",
            "-ss", str(CLIP_START), "-t", str(CLIP_SECONDS),
            "-i", str(mp3),
            "-ac", "2", "-ar", str(RATE),
            "-f", "s16le", "-",
        ]
    )
    samples = list(struct.unpack("<%dh" % (len(raw) // 2), raw))
    if len(samples) < frames * 2:
        raise SystemExit("clip is shorter than 2 seconds")
    samples = samples[: frames * 2]
    # The menu clip plays at full level, then fades out. The start is left alone.
    fade = int(FADE_OUT * RATE)
    for i in range(fade):
        gain = (fade - 1 - i) / fade
        frame = frames - fade + i
        samples[frame * 2] = int(samples[frame * 2] * gain)
        samples[frame * 2 + 1] = int(samples[frame * 2 + 1] * gain)
    with wave.open(str(WAV), "w") as handle:
        handle.setnchannels(2)
        handle.setsampwidth(2)
        handle.setframerate(RATE)
        handle.writeframes(struct.pack("<%dh" % len(samples), *samples))


write_clip()

if not WAV.exists() or WAV.stat().st_size < 64:
    raise SystemExit(f"missing banner audio: {WAV}")

with wave.open(str(WAV), "rb") as handle:
    if handle.getnchannels() != 2 or handle.getsampwidth() != 2:
        raise SystemExit("banner wav must be stereo 16-bit")
    frames = handle.getnframes()
    rate = handle.getframerate()
seconds = frames / rate
if not (0 < seconds < 3.0):
    raise SystemExit(f"banner audio is {seconds:.3f}s, must be under 3 seconds")

subprocess.check_call(
    ["bannertool", "makebanner", "-i", str(PNG), "-a", str(WAV), "-o", str(OUT)]
)
print(f"banner {seconds:.2f}s at {rate} Hz")
