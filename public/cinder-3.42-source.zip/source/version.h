#pragma once

#define CINDER_VERSION "3.42"
#define CINDER_REVISION 72
