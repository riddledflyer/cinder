#pragma once

#define CINDER_VERSION "3.43"
#define CINDER_REVISION 73
