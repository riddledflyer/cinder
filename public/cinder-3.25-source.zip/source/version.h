#pragma once

#define CINDER_VERSION "3.25"
#define CINDER_REVISION 55
