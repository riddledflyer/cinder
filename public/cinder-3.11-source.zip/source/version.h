#pragma once

#define CINDER_VERSION "3.11"
#define CINDER_REVISION 41
