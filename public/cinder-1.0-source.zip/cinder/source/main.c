#include "titles.h"
#include "cia.h"
#include "ui.h"
#include "version.h"

#include <stdio.h>
#include <string.h>

#define LIST_HEADER 18
#define ROW_H 52
#define LIST_ROWS 4
#define CIA_ROW_H 36
#define CIA_ROWS 6

typedef enum {
    MODE_WARN = 0,
    MODE_LIST,
    MODE_CONFIRM,
    MODE_RESULT,
    MODE_INSTALL,
    MODE_INSTALL_CONFIRM
} Mode;

static int g_visible[TITLE_CAP];
static u64 g_ids[TITLE_CAP];

static bool is_nds(const TitleRec *title) {
    return title->kind == KIND_DSIWARE;
}

static int build_visible(const TitleList *list, int nds, int *out) {
    int count = 0;
    for (u32 i = 0; i < list->count; i++) {
        const TitleRec *title = &list->items[i];
        if (title->kind == KIND_SYSTEM) continue;
        if (title->id == CINDER_TITLE_ID || title->id == titles_self_id()) continue;
        if (nds) {
            if (is_nds(title)) out[count++] = (int)i;
        } else if (!is_nds(title)) {
            out[count++] = (int)i;
        }
    }
    return count;
}

static void reload(TitleList *list, Result *load_rc) {
    titles_free(list);
    *load_rc = titles_load_all(list);
}

static u32 count_selected(const TitleList *list, u64 *bytes) {
    u32 count = 0;
    *bytes = 0;
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].selected && list->items[i].deletable) {
            count++;
            *bytes += list->items[i].size;
        }
    }
    return count;
}

static void select_visible(TitleList *list, const int *visible, int count, bool on) {
    for (int i = 0; i < count; i++) {
        TitleRec *title = &list->items[visible[i]];
        if (title->deletable) title->selected = on;
    }
}

static void toggle_visible(TitleList *list, const int *visible, int count) {
    int selectable = 0;
    int selected = 0;
    for (int i = 0; i < count; i++) {
        TitleRec *title = &list->items[visible[i]];
        if (!title->deletable) continue;
        selectable++;
        if (title->selected) selected++;
    }
    if (selectable == 0) return;
    select_visible(list, visible, count, selected < selectable);
}

static bool repeat_key(u32 down, u32 held, u32 key, int *timer) {
    if (down & key) {
        *timer = 0;
        return true;
    }
    if (held & key) {
        (*timer)++;
        return *timer > 16 && (*timer % 3) == 0;
    }
    *timer = 0;
    return false;
}

static FS_MediaType media_of(const TitleList *list, u64 id) {
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].id == id) return list->items[i].media;
    }
    return MEDIATYPE_SD;
}

static void draw_icon(int x, int y, const TitleRec *title, int size, u32 tick) {
    u16 frame[32 * 32];
    const u16 *pix = title->icon;
    int src = title->icon_w > 0 ? title->icon_w : 48;
    if (title->anim && titles_anim_frame(title->anim, tick, frame)) {
        pix = frame;
        src = 32;
    }
    ui_icon(x, y, pix, src, size, title->kind == KIND_DSIWARE);
}

static void draw_top(const TitleList *list, const int *visible, int vcount, int cursor,
                     int nds, Result services, Result load_rc, const char *status, u32 tick) {
    ui_select(GFX_TOP);
    ui_clear();
    int width = 400;
    ui_size(&width, NULL);

    char line[80];
    snprintf(line, sizeof(line), "Cinder %s", CINDER_VERSION);
    ui_text(8, 6, line, 24, 232, 232, 232);
    ui_text(8, 18, nds ? "NDS software" : "3DS software", 24, 148, 148, 156);

    u64 selected_bytes = 0;
    u32 selected = count_selected(list, &selected_bytes);
    char size[16];
    titles_format_size(size, sizeof(size), selected_bytes);
    snprintf(line, sizeof(line), "%lu selected  %s", (unsigned long)selected, size);
    ui_text(width - 8 - (int)strlen(line) * 8, 6, line, 32, 180, 190, 210);

    if (R_FAILED(services)) {
        ui_text(8, 48, "Service init failed.", 40, 232, 232, 232);
        snprintf(line, sizeof(line), "0x%08lX", (unsigned long)services);
        ui_text(8, 62, line, 20, 148, 148, 156);
        ui_text(8, 80, "Install the CIA, or run the 3dsx", 40, 148, 148, 156);
        ui_text(8, 92, "from Homebrew Launcher on Luma.", 40, 148, 148, 156);
    } else if (R_FAILED(load_rc)) {
        ui_text(8, 48, "Could not list titles.", 40, 232, 232, 232);
        snprintf(line, sizeof(line), "0x%08lX", (unsigned long)load_rc);
        ui_text(8, 62, line, 20, 148, 148, 156);
    } else if (vcount <= 0 || cursor < 0 || cursor >= vcount) {
        ui_text(8, 48, nds ? "No NDS software." : "No 3DS software.", 40, 232, 232, 232);
        ui_text(8, 64, nds ? "DSiWare on NAND shows up here." : "Games, demos, updates, and DLC.", 44, 148, 148, 156);
    } else {
        const TitleRec *title = &list->items[visible[cursor]];
        char ver[16];
        titles_format_version(ver, sizeof(ver), title->version);
        titles_format_size(size, sizeof(size), title->size);
        draw_icon(8, 40, title, 48, tick);
        ui_text(64, 40, title->name, 40, 232, 232, 232);
        int y = 56;
        if (strlen(title->name) > 40) {
            ui_text(64, 52, title->name + 40, 40, 232, 232, 232);
            y = 68;
        }
        ui_text(64, y, title->publisher, 40, 180, 186, 198);
        y += 14;
        snprintf(line, sizeof(line), "%s    v%s", titles_kind_name(title->kind), ver);
        ui_text(64, y, line, 40, 232, 232, 232);
        y += 14;
        snprintf(line, sizeof(line), "%s    %s", size, title->media == MEDIATYPE_SD ? "SD card" : "NAND");
        ui_text(64, y, line, 40, 232, 232, 232);
        y += 14;
        ui_text(64, y, title->product[0] ? title->product : "-", 20, 148, 148, 156);
        y += 12;
        snprintf(line, sizeof(line), "%016llX", (unsigned long long)title->id);
        ui_text(64, y, line, 20, 148, 148, 156);
    }

    if (status && status[0]) ui_text(8, 198, status, 48, 230, 196, 120);
    ui_text(8, 214, "A select    X all    SELECT install", 46, 148, 148, 156);
    ui_text(8, 226, "L/R list    START delete", 40, 148, 148, 156);
}

static void draw_list(const TitleList *list, const int *visible, int vcount, int cursor, int scroll, int nds, u32 tick) {
    ui_select(GFX_BOTTOM);
    ui_clear();
    int width = 320;
    ui_size(&width, NULL);

    ui_fill(0, 0, width, LIST_HEADER, 16, 20, 30);
    ui_text(8, 5, "3DS", 4, nds ? 130 : 255, nds ? 136 : 255, nds ? 148 : 255);
    ui_text(52, 5, "NDS", 4, nds ? 255 : 130, nds ? 255 : 136, nds ? 255 : 148);
    ui_fill(nds ? 52 : 8, LIST_HEADER - 2, 24, 2, 110, 168, 255);

    char count[8];
    snprintf(count, sizeof(count), "%d", vcount);
    ui_text(width - 8 - (int)strlen(count) * 8, 5, count, 6, 170, 176, 190);

    if (vcount == 0) {
        ui_text(8, 40, nds ? "No NDS software." : "No 3DS software.", 32, 232, 232, 232);
        return;
    }

    int end = scroll + LIST_ROWS;
    if (end > vcount) end = vcount;
    for (int row = scroll; row < end; row++) {
        const TitleRec *title = &list->items[visible[row]];
        int y = LIST_HEADER + (row - scroll) * ROW_H;
        if (row == cursor) ui_fill(0, y, width, ROW_H - 1, 22, 34, 54);
        if (title->selected) ui_fill(0, y, 3, ROW_H - 1, 88, 196, 132);
        draw_icon(2, y + 2, title, 48, tick);

        char ver[16];
        char size[16];
        titles_format_version(ver, sizeof(ver), title->version);
        titles_format_size(size, sizeof(size), title->size);
        ui_text(width - 6 - (int)strlen(size) * 8, y + 12, size, 10, 210, 214, 224);
        ui_text(54, y + 12, title->name, 22, 232, 232, 232);
        ui_text(54, y + 28, title->publisher, 14, 150, 156, 168);

        char meta[24];
        snprintf(meta, sizeof(meta), "v%s", ver);
        ui_text(54 + 15 * 8, y + 28, meta, 12, 176, 196, 220);
    }
}

static void draw_confirm(u32 count, u64 bytes, bool related, bool tickets) {
    ui_select(GFX_BOTTOM);
    ui_clear();
    char size[16];
    titles_format_size(size, sizeof(size), bytes);
    ui_printf("Delete %lu titles?\n", (unsigned long)count);
    ui_printf("Size %s\n\n", size);
    ui_printf("Updates and DLC: %s  (Y)\n", related ? "ON" : "OFF");
    ui_printf("Delete tickets:  %s  (X)\n\n", tickets ? "ON" : "OFF");
    ui_printf("Tickets stay off unless you\n");
    ui_printf("need the title gone for good.\n");
    ui_printf("Saves may remain either way.\n\n");
    ui_printf("A delete    B cancel\n");
}

static void draw_result(const char *status) {
    ui_select(GFX_BOTTOM);
    ui_clear();
    ui_printf("%s\n\n", status);
    ui_printf("A back to the list\n");
}

static void on_progress(u32 index, u32 total, u64 id, Result rc, bool ticket_ok, void *user) {
    bool tickets = *(bool *)user;
    ui_select(GFX_BOTTOM);
    ui_clear();
    ui_printf("Deleting %lu / %lu\n\n", (unsigned long)(index + 1), (unsigned long)total);
    ui_printf("%016llX\n", (unsigned long long)id);
    if (R_FAILED(rc)) ui_printf("Failed  0x%08lX\n", (unsigned long)rc);
    else ui_printf("Removed\n");
    if (tickets && R_SUCCEEDED(rc) && !ticket_ok) ui_printf("Ticket kept\n");
    ui_present();
}

static Result delete_selected(TitleList *list, bool related, bool tickets) {
    u32 count = titles_collect(list, g_ids, TITLE_CAP, related);
    if (count == 0) return 0;

    u32 sd_n = 0;
    for (u32 i = 0; i < count; i++) {
        if (media_of(list, g_ids[i]) != MEDIATYPE_SD) continue;
        u64 swap = g_ids[sd_n];
        g_ids[sd_n] = g_ids[i];
        g_ids[i] = swap;
        sd_n++;
    }

    Result rc = 0;
    if (sd_n > 0) {
        Result one = titles_delete(MEDIATYPE_SD, g_ids, sd_n, tickets, on_progress, &tickets);
        if (R_FAILED(one)) rc = one;
    }
    if (count > sd_n) {
        Result one = titles_delete(MEDIATYPE_NAND, g_ids + sd_n, count - sd_n, tickets, on_progress, &tickets);
        if (R_FAILED(one)) rc = one;
    }
    return rc;
}

static bool in_cias_dir(const CiaRec *cia) {
    return cia->path[1] == 'c' && cia->path[2] == 'i' && cia->path[3] == 'a' &&
           cia->path[4] == 's' && cia->path[5] == '/';
}

static u32 count_cias(const CiaList *list, u64 *bytes) {
    u32 count = 0;
    *bytes = 0;
    if (!list->items) return 0;
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].selected && list->items[i].installable) {
            count++;
            *bytes += list->items[i].file_size;
        }
    }
    return count;
}

static void toggle_cias(CiaList *list) {
    if (!list->items) return;
    int selectable = 0;
    int selected = 0;
    for (u32 i = 0; i < list->count; i++) {
        if (!list->items[i].installable) continue;
        selectable++;
        if (list->items[i].selected) selected++;
    }
    if (selectable == 0) return;
    bool on = selected < selectable;
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].installable) list->items[i].selected = on;
    }
}

static void draw_install_top(const CiaList *cias, int cursor, const char *status) {
    ui_select(GFX_TOP);
    ui_clear();
    int width = 400;
    ui_size(&width, NULL);

    char line[96];
    snprintf(line, sizeof(line), "Cinder %s", CINDER_VERSION);
    ui_text(8, 6, line, 24, 232, 232, 232);
    ui_text(8, 18, "Install CIAs", 24, 148, 148, 156);

    u64 selected_bytes = 0;
    u32 selected = count_cias(cias, &selected_bytes);
    char size[16];
    titles_format_size(size, sizeof(size), selected_bytes);
    snprintf(line, sizeof(line), "%lu selected  %s", (unsigned long)selected, size);
    ui_text(width - 8 - (int)strlen(line) * 8, 6, line, 36, 180, 190, 210);

    int n = cias->items ? (int)cias->count : 0;
    if (R_FAILED(cias->rc)) {
        ui_text(8, 48, "Could not read the SD card.", 40, 232, 232, 232);
        snprintf(line, sizeof(line), "0x%08lX", (unsigned long)cias->rc);
        ui_text(8, 62, line, 20, 148, 148, 156);
    } else if (n <= 0 || cursor < 0 || cursor >= n) {
        ui_text(8, 48, "No CIAs found.", 40, 232, 232, 232);
        ui_text(8, 64, "Looked in sdmc:/cias/ and", 40, 148, 148, 156);
        ui_text(8, 76, "the SD card root.", 40, 148, 148, 156);
        ui_text(8, 96, "A CIA can be installed when", 40, 148, 148, 156);
        ui_text(8, 108, "its size matches the size", 40, 148, 148, 156);
        ui_text(8, 120, "stored in the header.", 40, 148, 148, 156);
    } else {
        const CiaRec *cia = &cias->items[cursor];
        ui_text(8, 40, cia->name, 46, 232, 232, 232);
        ui_text(8, 56, in_cias_dir(cia) ? "sdmc:/cias/" : "sdmc:/", 20, 180, 186, 198);

        char file_s[16];
        char decl_s[16];
        titles_format_size(file_s, sizeof(file_s), cia->file_size);
        titles_format_size(decl_s, sizeof(decl_s), cia->declared_size);
        int y = 76;
        if (!cia->header_ok) {
            ui_text(8, y, "Not a readable CIA.", 32, 232, 232, 232);
            y += 14;
            snprintf(line, sizeof(line), "File %s", file_s);
            ui_text(8, y, line, 32, 148, 148, 156);
        } else if (!cia->complete) {
            ui_text(8, y, "Incomplete. Left alone.", 36, 232, 196, 120);
            y += 14;
            snprintf(line, sizeof(line), "File %s    header %s", file_s, decl_s);
            ui_text(8, y, line, 46, 180, 186, 198);
        } else if (cia->title_id == 0) {
            snprintf(line, sizeof(line), "%s", file_s);
            ui_text(8, y, line, 40, 232, 232, 232);
            y += 14;
            ui_text(8, y, cia->media == MEDIATYPE_SD ? "SD card" : "NAND", 16, 180, 186, 198);
        } else {
            char ver[16];
            titles_format_version(ver, sizeof(ver), cia->version);
            snprintf(line, sizeof(line), "%s    v%s", titles_kind_name(cia->kind), ver);
            ui_text(8, y, line, 40, 232, 232, 232);
            y += 14;
            snprintf(line, sizeof(line), "%s    %s", file_s, cia->media == MEDIATYPE_SD ? "SD card" : "NAND");
            ui_text(8, y, line, 40, 232, 232, 232);
            y += 14;
            snprintf(line, sizeof(line), "%016llX", (unsigned long long)cia->title_id);
            ui_text(8, y, line, 20, 148, 148, 156);
        }
    }

    if (status && status[0]) ui_text(8, 198, status, 48, 230, 196, 120);
    ui_text(8, 214, "A select   X all   SELECT delete", 44, 148, 148, 156);
    ui_text(8, 226, "START install    B back", 40, 148, 148, 156);
}

static void draw_install_list(const CiaList *cias, int cursor, int scroll) {
    ui_select(GFX_BOTTOM);
    ui_clear();
    int width = 320;
    ui_size(&width, NULL);
    int n = cias->items ? (int)cias->count : 0;

    ui_fill(0, 0, width, LIST_HEADER, 16, 20, 30);
    ui_text(8, 5, "CIAs", 8, 255, 255, 255);
    char count[8];
    snprintf(count, sizeof(count), "%d", n);
    ui_text(width - 8 - (int)strlen(count) * 8, 5, count, 6, 170, 176, 190);

    if (n == 0) {
        ui_text(8, 40, "No CIAs found.", 32, 232, 232, 232);
        return;
    }

    int end = scroll + CIA_ROWS;
    if (end > n) end = n;
    for (int row = scroll; row < end; row++) {
        const CiaRec *cia = &cias->items[row];
        int y = LIST_HEADER + (row - scroll) * CIA_ROW_H;
        if (row == cursor) ui_fill(0, y, width, CIA_ROW_H - 1, 22, 34, 54);
        if (cia->selected) ui_fill(0, y, 3, CIA_ROW_H - 1, 88, 196, 132);

        char size[16];
        titles_format_size(size, sizeof(size), cia->file_size);
        ui_text(width - 6 - (int)strlen(size) * 8, y + 4, size, 10, 210, 214, 224);
        ui_text(8, y + 4, cia->name, 26, cia->installable ? 232 : 140, cia->installable ? 232 : 144, cia->installable ? 232 : 150);

        if (!cia->header_ok) ui_text(8, y + 18, "bad file", 16, 176, 140, 110);
        else if (!cia->complete) ui_text(8, y + 18, "incomplete", 16, 176, 140, 110);
        else if (cia->title_id == 0) {
            ui_text(8, y + 18, cia->media == MEDIATYPE_SD ? "SD" : "NAND", 16, 150, 156, 168);
        } else {
            char ver[16];
            char meta[28];
            titles_format_version(ver, sizeof(ver), cia->version);
            snprintf(meta, sizeof(meta), "v%s  %s", ver, cia->media == MEDIATYPE_SD ? "SD" : "NAND");
            ui_text(8, y + 18, meta, 24, 150, 156, 168);
        }
    }
}

static void draw_install_confirm(u32 count, u64 bytes) {
    ui_select(GFX_BOTTOM);
    ui_clear();
    char size[16];
    titles_format_size(size, sizeof(size), bytes);
    ui_printf("Install %lu CIAs?\n", (unsigned long)count);
    ui_printf("Size %s\n\n", size);
    ui_printf("Incomplete files are not\n");
    ui_printf("in this batch. The file size\n");
    ui_printf("has to match the header.\n");
    ui_printf("Anything that passes that\n");
    ui_printf("check is installed.\n\n");
    ui_printf("A title that is already\n");
    ui_printf("installed is replaced.\n\n");
    ui_printf("A install    B cancel\n");
}

static bool g_quit;

static bool on_cia_pump(const CiaRec *cia, u32 index, u32 total, u64 wrote, void *user) {
    (void)user;
    if (!aptMainLoop()) {
        g_quit = true;
        return false;
    }
    hidScanInput();
    if (hidKeysDown() & KEY_B) return false;

    static u64 last_draw = ~(u64)0;
    static u32 last_index = 0xFFFFFFFFu;
    if (index != last_index) {
        last_draw = ~(u64)0;
        last_index = index;
    }
    if (last_draw != ~(u64)0 && wrote != cia->file_size && wrote > last_draw &&
        wrote - last_draw < 256ull * 1024ull) {
        return true;
    }
    last_draw = wrote;

    ui_select(GFX_TOP);
    ui_clear();
    char line[80];
    char done[16];
    char all[16];
    snprintf(line, sizeof(line), "Installing %lu / %lu", (unsigned long)(index + 1), (unsigned long)total);
    ui_text(8, 8, line, 40, 232, 232, 232);
    ui_text(8, 28, cia->name, 46, 232, 232, 232);
    titles_format_size(done, sizeof(done), wrote);
    titles_format_size(all, sizeof(all), cia->file_size);
    snprintf(line, sizeof(line), "%s / %s", done, all);
    ui_text(8, 48, line, 40, 180, 186, 198);
    ui_text(8, 214, "B cancel", 16, 148, 148, 156);

    ui_select(GFX_BOTTOM);
    ui_clear();
    int width = 320;
    ui_size(&width, NULL);
    int span = width - 16;
    int bar = cia->file_size ? (int)((wrote * (u64)span) / cia->file_size) : 0;
    if (bar > span) bar = span;
    ui_fill(8, 110, span, 14, 20, 24, 32);
    if (bar > 0) ui_fill(8, 110, bar, 14, 110, 168, 255);
    ui_present();
    return true;
}

static void install_selected(CiaList *cias, TitleList *titles, Result *load_rc, char *status, size_t status_n) {
    u64 bytes = 0;
    u32 total = count_cias(cias, &bytes);
    if (total == 0) {
        snprintf(status, status_n, "Nothing to install.");
        return;
    }

    u32 index = 0;
    u32 ok = 0;
    Result rc = 0;
    bool cancelled = false;
    for (u32 i = 0; i < cias->count; i++) {
        CiaRec *cia = &cias->items[i];
        if (!cia->selected || !cia->installable) continue;
        Result one = cias_install_one(cia, index, total, on_cia_pump, NULL);
        if (g_quit || one == CIA_ERR_CANCEL) {
            cancelled = true;
            rc = one;
            break;
        }
        if (R_FAILED(one)) rc = one;
        else {
            ok++;
            cia->selected = false;
        }
        index++;
    }

    if (!g_quit) reload(titles, load_rc);
    if (g_quit) snprintf(status, status_n, "Stopped.");
    else if (cancelled) snprintf(status, status_n, "Cancelled. Installed %lu.", (unsigned long)ok);
    else if (R_FAILED(rc)) snprintf(status, status_n, "Installed %lu. Error 0x%08lX", (unsigned long)ok, (unsigned long)rc);
    else snprintf(status, status_n, "Installed %lu.", (unsigned long)ok);
}

static void enter_install(CiaList *cias, int *cursor, int *scroll) {
    ui_select(GFX_BOTTOM);
    ui_clear();
    ui_printf("Reading CIAs...\n");
    ui_present();
    cias_load(cias);
    *cursor = 0;
    *scroll = 0;
}

int main(int argc, char **argv) {
    (void)argc;
    (void)argv;

    ui_init();

    Result am_rc = amInit();
    Result fs_rc = fsInit();
    Result services = R_FAILED(am_rc) ? am_rc : fs_rc;

    TitleList list;
    memset(&list, 0, sizeof(list));
    CiaList cias;
    memset(&cias, 0, sizeof(cias));
    Result load_rc = 0;
    if (R_SUCCEEDED(services)) reload(&list, &load_rc);

    Mode mode = MODE_WARN;
    int nds = 0;
    int cursor = 0;
    int scroll = 0;
    int icursor = 0;
    int iscroll = 0;
    int down_timer = 0;
    int up_timer = 0;
    bool include_related = true;
    bool delete_tickets = false;
    char status[96];
    status[0] = '\0';

    u32 tick = 0;

    while (aptMainLoop()) {
        hidScanInput();
        u32 down = hidKeysDown();
        u32 held = hidKeysHeld();
        int vcount = build_visible(&list, nds, g_visible);
        if (cursor >= vcount) cursor = vcount > 0 ? vcount - 1 : 0;
        if (cursor < scroll) scroll = cursor;
        if (cursor >= scroll + LIST_ROWS) scroll = cursor - LIST_ROWS + 1;
        if (scroll < 0) scroll = 0;

        if (mode == MODE_WARN) {
            if (down & (KEY_A | KEY_START)) mode = MODE_LIST;
            if (down & KEY_SELECT && R_SUCCEEDED(services)) {
                enter_install(&cias, &icursor, &iscroll);
                status[0] = '\0';
                mode = MODE_INSTALL;
            }
            if (down & KEY_B) break;
        } else if (mode == MODE_RESULT) {
            if (g_quit) break;
            if (down & (KEY_A | KEY_B | KEY_START)) {
                status[0] = '\0';
                mode = MODE_LIST;
            }
        } else if (mode == MODE_CONFIRM) {
            if (down & KEY_B) mode = MODE_LIST;
            if (down & KEY_Y) include_related = !include_related;
            if (down & KEY_X) delete_tickets = !delete_tickets;
            if (down & KEY_A) {
                u64 bytes = 0;
                u32 marked = count_selected(&list, &bytes);
                if (marked == 0) {
                    snprintf(status, sizeof(status), "Nothing selected.");
                    mode = MODE_LIST;
                } else {
                    bool tickets = delete_tickets;
                    Result rc = delete_selected(&list, include_related, tickets);
                    reload(&list, &load_rc);
                    cursor = 0;
                    scroll = 0;
                    if (R_FAILED(rc)) snprintf(status, sizeof(status), "Finished with errors 0x%08lX", (unsigned long)rc);
                    else snprintf(status, sizeof(status), "Removed %lu titles.", (unsigned long)marked);
                    mode = MODE_RESULT;
                }
            }
        } else if (mode == MODE_INSTALL_CONFIRM) {
            if (down & KEY_B) mode = MODE_INSTALL;
            if (down & KEY_A) {
                install_selected(&cias, &list, &load_rc, status, sizeof(status));
                if (g_quit) break;
                mode = MODE_RESULT;
            }
        } else if (mode == MODE_INSTALL && R_SUCCEEDED(services)) {
            int n = cias.items ? (int)cias.count : 0;
            if (icursor >= n) icursor = n > 0 ? n - 1 : 0;
            if (icursor < iscroll) iscroll = icursor;
            if (icursor >= iscroll + CIA_ROWS) iscroll = icursor - CIA_ROWS + 1;
            if (iscroll < 0) iscroll = 0;
            if (down & KEY_B) {
                mode = MODE_WARN;
            } else {
                if (repeat_key(down, held, KEY_DDOWN, &down_timer) || (down & KEY_CPAD_DOWN)) {
                    if (n > 0 && icursor < n - 1) icursor++;
                } else if (repeat_key(down, held, KEY_DUP, &up_timer) || (down & KEY_CPAD_UP)) {
                    if (icursor > 0) icursor--;
                }
                if (down & KEY_A && n > 0) {
                    CiaRec *cia = &cias.items[icursor];
                    if (cia->installable) cia->selected = !cia->selected;
                    else snprintf(status, sizeof(status), "Incomplete CIA.");
                }
                if (down & KEY_X) toggle_cias(&cias);
                if (down & KEY_SELECT) {
                    status[0] = '\0';
                    mode = MODE_LIST;
                }
                if (down & KEY_START) {
                    u64 bytes = 0;
                    if (count_cias(&cias, &bytes) > 0) mode = MODE_INSTALL_CONFIRM;
                    else snprintf(status, sizeof(status), "Select a complete CIA.");
                }
                if (down & KEY_TOUCH && n > 0) {
                    touchPosition touch;
                    hidTouchRead(&touch);
                    if (touch.py >= LIST_HEADER) {
                        int row = ((int)touch.py - LIST_HEADER) / CIA_ROW_H;
                        int index = iscroll + row;
                        if (row >= 0 && row < CIA_ROWS && index >= 0 && index < n) {
                            icursor = index;
                            if (cias.items[icursor].installable) cias.items[icursor].selected = !cias.items[icursor].selected;
                        }
                    }
                }
            }
        } else if (mode == MODE_LIST && R_SUCCEEDED(services)) {
            if (down & KEY_B) {
                mode = MODE_WARN;
            } else {
                if (repeat_key(down, held, KEY_DDOWN, &down_timer) || (down & KEY_CPAD_DOWN)) {
                    if (vcount > 0 && cursor < vcount - 1) cursor++;
                } else if (repeat_key(down, held, KEY_DUP, &up_timer) || (down & KEY_CPAD_UP)) {
                    if (cursor > 0) cursor--;
                }
                if (down & KEY_A && vcount > 0) {
                    TitleRec *title = &list.items[g_visible[cursor]];
                    if (title->deletable) title->selected = !title->selected;
                }
                if (down & KEY_X) toggle_visible(&list, g_visible, vcount);
                if (down & (KEY_L | KEY_R)) {
                    nds = !nds;
                    cursor = 0;
                    scroll = 0;
                    status[0] = '\0';
                }
                if (down & KEY_SELECT) {
                    enter_install(&cias, &icursor, &iscroll);
                    status[0] = '\0';
                    mode = MODE_INSTALL;
                }
                if (down & KEY_START) {
                    u64 bytes = 0;
                    if (count_selected(&list, &bytes) > 0) mode = MODE_CONFIRM;
                    else snprintf(status, sizeof(status), "Select a title first.");
                }
                if (down & KEY_TOUCH) {
                    touchPosition touch;
                    hidTouchRead(&touch);
                    if (touch.py < LIST_HEADER) {
                        if (touch.px < 48) nds = 0;
                        else if (touch.px < 104) nds = 1;
                        cursor = 0;
                        scroll = 0;
                    } else if (vcount > 0) {
                        int row = ((int)touch.py - LIST_HEADER) / ROW_H;
                        int index = scroll + row;
                        if (row >= 0 && row < LIST_ROWS && index >= 0 && index < vcount) {
                            cursor = index;
                            TitleRec *title = &list.items[g_visible[cursor]];
                            if (title->deletable) title->selected = !title->selected;
                        }
                    }
                }
            }
        } else if ((mode == MODE_LIST || mode == MODE_INSTALL) && down & KEY_B) {
            mode = MODE_WARN;
        }

        vcount = build_visible(&list, nds, g_visible);
        if (cursor >= vcount) cursor = vcount > 0 ? vcount - 1 : 0;

        if (mode == MODE_INSTALL || mode == MODE_INSTALL_CONFIRM) {
            draw_install_top(&cias, icursor, status);
        } else {
            draw_top(&list, g_visible, vcount, cursor, nds, services, load_rc, status, tick);
        }

        if (mode == MODE_WARN) {
            ui_select(GFX_BOTTOM);
            ui_clear();
            ui_printf("Cinder deletes installed\n");
            ui_printf("software in a batch.\n\n");
            ui_printf("3DS and NDS are separate\n");
            ui_printf("lists. L and R switch them.\n\n");
            ui_printf("System software stays off\n");
            ui_printf("those lists. Games stay,\n");
            ui_printf("including Nintendo's.\n\n");
            ui_printf("SELECT installs CIAs from\n");
            ui_printf("sdmc:/cias/ and the SD root.\n");
            ui_printf("Any file whose size matches\n");
            ui_printf("the header can be installed.\n\n");
            ui_printf("A continue\n");
            ui_printf("B exit\n");
        } else if (mode == MODE_CONFIRM) {
            u32 count = titles_collect(&list, g_ids, TITLE_CAP, include_related);
            u64 bytes = 0;
            for (u32 i = 0; i < count; i++) {
                for (u32 j = 0; j < list.count; j++) {
                    if (list.items[j].id == g_ids[i]) bytes += list.items[j].size;
                }
            }
            draw_confirm(count, bytes, include_related, delete_tickets);
        } else if (mode == MODE_INSTALL_CONFIRM) {
            u64 bytes = 0;
            draw_install_confirm(count_cias(&cias, &bytes), bytes);
        } else if (mode == MODE_RESULT) {
            draw_result(status);
        } else if (mode == MODE_INSTALL) {
            int n = cias.items ? (int)cias.count : 0;
            if (icursor >= n) icursor = n > 0 ? n - 1 : 0;
            if (icursor < iscroll) iscroll = icursor;
            if (icursor >= iscroll + CIA_ROWS) iscroll = icursor - CIA_ROWS + 1;
            if (iscroll < 0) iscroll = 0;
            draw_install_list(&cias, icursor, iscroll);
        } else {
            draw_list(&list, g_visible, vcount, cursor, scroll, nds, tick);
        }

        ui_present();
        tick++;
    }

    titles_free(&list);
    cias_free(&cias);
    if (R_SUCCEEDED(fs_rc)) fsExit();
    if (R_SUCCEEDED(am_rc)) amExit();
    gfxExit();
    return 0;
}
