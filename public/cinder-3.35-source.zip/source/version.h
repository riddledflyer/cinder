#pragma once

#define CINDER_VERSION "3.35"
#define CINDER_REVISION 65
