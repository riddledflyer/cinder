#pragma once

#define CINDER_VERSION "3.22"
#define CINDER_REVISION 52
