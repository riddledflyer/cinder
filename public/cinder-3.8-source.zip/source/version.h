#pragma once

#define CINDER_VERSION "3.8"
#define CINDER_REVISION 38
