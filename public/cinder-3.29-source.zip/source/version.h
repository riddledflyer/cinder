#pragma once

#define CINDER_VERSION "3.29"
#define CINDER_REVISION 59
