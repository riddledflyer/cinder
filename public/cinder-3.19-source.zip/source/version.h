#pragma once

#define CINDER_VERSION "3.19"
#define CINDER_REVISION 49
