#include "ui.h"

#include <citro2d.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#define FONT_SCALE 0.42f
#define TEXT_GLYPHS 2048
#define ICON_SLOTS 10
#define ICON_TEX 64

typedef struct {
    C3D_Tex tex;
    Tex3DS_SubTexture sub;
    bool ready;
} IconSlot;

static C3D_RenderTarget *g_top;
static C3D_RenderTarget *g_bot;
static C2D_Font g_font;
static C2D_TextBuf g_text;
static IconSlot g_icons[ICON_SLOTS];
static int g_icon_used;
static gfxScreen_t g_screen;
static int g_width;
static int g_height;
static int g_cx;
static int g_cy;
static bool g_frame;
static bool g_ptmu;

static C3D_RenderTarget *target_for(gfxScreen_t screen) {
    return screen == GFX_TOP ? g_top : g_bot;
}

static void screen_size(gfxScreen_t screen, int *w, int *h) {
    if (w) *w = screen == GFX_TOP ? 400 : 320;
    if (h) *h = 240;
}

static void begin_frame(void) {
    if (g_frame) return;
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    g_frame = true;
    g_icon_used = 0;
    if (g_text) C2D_TextBufClear(g_text);
}

static void scene(void) {
    begin_frame();
    C3D_RenderTarget *target = target_for(g_screen);
    if (target) C2D_SceneBegin(target);
}

static int utf8_copy(char *dst, size_t dst_len, const char *text, int max_chars) {
    if (!dst || dst_len == 0) return 0;
    dst[0] = '\0';
    if (!text || max_chars <= 0) return 0;
    size_t o = 0;
    int n = 0;
    const unsigned char *s = (const unsigned char *)text;
    while (*s && n < max_chars && o + 1 < dst_len) {
        if (*s < 0x80) {
            dst[o++] = (char)*s++;
        } else if ((*s & 0xE0) == 0xC0 && s[1] && o + 2 < dst_len) {
            dst[o++] = (char)*s++;
            dst[o++] = (char)*s++;
        } else if ((*s & 0xF0) == 0xE0 && s[1] && s[2] && o + 3 < dst_len) {
            dst[o++] = (char)*s++;
            dst[o++] = (char)*s++;
            dst[o++] = (char)*s++;
        } else if ((*s & 0xF8) == 0xF0 && s[1] && s[2] && s[3] && o + 4 < dst_len) {
            dst[o++] = (char)*s++;
            dst[o++] = (char)*s++;
            dst[o++] = (char)*s++;
            dst[o++] = (char)*s++;
        } else {
            dst[o++] = '?';
            s++;
        }
        n++;
    }
    dst[o] = '\0';
    return n;
}

static bool parse_text(C2D_Text *out, const char *str) {
    if (!g_font || !g_text || !str) return false;
    const char *rest = C2D_TextFontParse(out, g_font, g_text, str);
    if (rest && *rest) {
        C2D_TextBufClear(g_text);
        rest = C2D_TextFontParse(out, g_font, g_text, str);
    }
    if (!rest) return false;
    C2D_TextOptimize(out);
    return true;
}

static void draw_battery(void) {
    if (!g_ptmu || !g_top) return;
    u8 level = 0;
    u8 charging = 0;
    if (R_FAILED(PTMU_GetBatteryLevel(&level))) return;
    PTMU_GetBatteryChargeState(&charging);
    if (level > 5) level = 5;

    C2D_SceneBegin(g_top);
    float x = 400.0f - 34.0f;
    float y = 5.0f;
    u32 shell = C2D_Color32(206, 210, 220, 255);
    u32 bg = C2D_Color32(8, 10, 16, 255);
    u32 cell = charging ? C2D_Color32(96, 210, 140, 255)
                        : (level <= 1 ? C2D_Color32(220, 90, 80, 255) : C2D_Color32(232, 236, 242, 255));
    C2D_DrawRectSolid(x, y, 0.4f, 24, 11, shell);
    C2D_DrawRectSolid(x + 1, y + 1, 0.4f, 22, 9, bg);
    C2D_DrawRectSolid(x + 24, y + 3, 0.4f, 2, 5, shell);
    for (int i = 0; i < (int)level; i++) {
        C2D_DrawRectSolid(x + 2 + i * 4, y + 2, 0.4f, 3, 7, cell);
    }
}

void ui_init(void) {
    gfxInitDefault();
    gfxSet3D(false);
    gfxSetWide(false);
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    g_top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    g_bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    g_font = C2D_FontLoadSystem(CFG_REGION_USA);
    if (g_font) C2D_FontSetFilter(g_font, GPU_LINEAR, GPU_LINEAR);
    g_text = C2D_TextBufNew(TEXT_GLYPHS);
    g_ptmu = R_SUCCEEDED(ptmuInit());
    g_screen = GFX_TOP;
    g_width = 400;
    g_height = 240;
    g_frame = false;
    g_icon_used = 0;
    memset(g_icons, 0, sizeof(g_icons));
    for (int i = 0; i < ICON_SLOTS; i++) {
        if (C3D_TexInit(&g_icons[i].tex, ICON_TEX, ICON_TEX, GPU_RGBA8)) {
            C3D_TexSetFilter(&g_icons[i].tex, GPU_LINEAR, GPU_LINEAR);
            C3D_TexSetWrap(&g_icons[i].tex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
            g_icons[i].ready = true;
        }
    }
}

void ui_exit(void) {
    if (g_frame) {
        C3D_FrameEnd(0);
        g_frame = false;
    }
    for (int i = 0; i < ICON_SLOTS; i++) {
        if (g_icons[i].ready) C3D_TexDelete(&g_icons[i].tex);
        g_icons[i].ready = false;
    }
    if (g_text) C2D_TextBufDelete(g_text);
    g_text = NULL;
    if (g_font) C2D_FontFree(g_font);
    g_font = NULL;
    C2D_Fini();
    C3D_Fini();
    if (g_ptmu) ptmuExit();
    g_ptmu = false;
    gfxExit();
}

void ui_select(gfxScreen_t screen) {
    g_screen = screen;
    screen_size(screen, &g_width, &g_height);
    scene();
}

void ui_clear(void) {
    begin_frame();
    screen_size(g_screen, &g_width, &g_height);
    C3D_RenderTarget *target = target_for(g_screen);
    if (target) {
        C2D_TargetClear(target, C2D_Color32(0, 0, 0, 255));
        C2D_SceneBegin(target);
    }
    g_cx = 8;
    g_cy = 8;
}

void ui_size(int *width, int *height) {
    if (width) *width = g_width;
    if (height) *height = g_height;
}

void ui_fill(int x, int y, int w, int h, u8 r, u8 g, u8 b) {
    if (w <= 0 || h <= 0) return;
    scene();
    C2D_DrawRectSolid((float)x, (float)y, 0.0f, (float)w, (float)h, C2D_Color32(r, g, b, 255));
}

int ui_text_width(const char *text, int max_chars) {
    char tmp[160];
    utf8_copy(tmp, sizeof(tmp), text, max_chars);
    C2D_Text parsed;
    if (!parse_text(&parsed, tmp)) return 0;
    float w = 0;
    C2D_TextGetDimensions(&parsed, FONT_SCALE, FONT_SCALE, &w, NULL);
    return (int)(w + 0.5f);
}

int ui_text(int x, int y, const char *text, int max_chars, u8 r, u8 g, u8 b) {
    char tmp[160];
    utf8_copy(tmp, sizeof(tmp), text, max_chars);
    C2D_Text parsed;
    if (!parse_text(&parsed, tmp)) return x;
    scene();
    C2D_DrawText(&parsed, C2D_WithColor, (float)x, (float)y, 0.1f, FONT_SCALE, FONT_SCALE,
                 C2D_Color32(r, g, b, 255));
    float w = 0;
    C2D_TextGetDimensions(&parsed, FONT_SCALE, FONT_SCALE, &w, NULL);
    return x + (int)(w + 0.5f);
}

static void printf_line(const char *line) {
    C2D_Text parsed;
    if (line[0] && parse_text(&parsed, line)) {
        scene();
        C2D_DrawText(&parsed, C2D_WithColor, (float)g_cx, (float)g_cy, 0.1f, 0.5f, 0.5f,
                     C2D_Color32(232, 232, 232, 255));
    }
    g_cy += 16;
}

void ui_printf(const char *fmt, ...) {
    char buf[192];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    char *start = buf;
    for (char *s = buf;; s++) {
        if (*s != '\n' && *s != '\0') continue;
        char saved = *s;
        *s = '\0';
        printf_line(start);
        if (!saved) break;
        start = s + 1;
    }
}

void ui_present(void) {
    if (!g_frame) return;
    draw_battery();
    C3D_FrameEnd(0);
    g_frame = false;
}

static u32 morton8(u32 x, u32 y) {
    u32 z = 0;
    for (int i = 0; i < 3; i++) z |= ((x & (1u << i)) << i) | ((y & (1u << i)) << (i + 1));
    return z;
}

static void tex_put(u32 *data, int x, int y, u32 color) {
    int tx = x >> 3;
    int ty = y >> 3;
    u32 idx = ((u32)ty * (ICON_TEX >> 3) + (u32)tx) * 64u + morton8(x & 7, y & 7);
    data[idx] = color;
}

static void unpack565(u16 c, int *r, int *g, int *b) {
    int r5 = (c >> 11) & 31;
    int g6 = (c >> 5) & 63;
    int b5 = c & 31;
    *r = (r5 << 3) | (r5 >> 2);
    *g = (g6 << 2) | (g6 >> 4);
    *b = (b5 << 3) | (b5 >> 2);
}

static u32 rgba565(u16 c, bool key_zero) {
    if (key_zero && c == 0) return C2D_Color32(0, 0, 0, 0);
    int r, g, b;
    unpack565(c, &r, &g, &b);
    return C2D_Color32((u8)r, (u8)g, (u8)b, 255);
}

void ui_icon(int x, int y, const u16 *icon, int src_w, int size, bool key_zero) {
    if (size <= 0 || size > ICON_TEX) return;
    scene();
    if (!icon || src_w <= 0) {
        ui_fill(x, y, size, size, 36, 40, 52);
        return;
    }
    if (g_icon_used >= ICON_SLOTS) return;
    IconSlot *slot = &g_icons[g_icon_used++];
    if (!slot->ready || !slot->tex.data) return;

    u32 *data = slot->tex.data;
    memset(data, 0, ICON_TEX * ICON_TEX * sizeof(u32));

    if (src_w == size) {
        for (int row = 0; row < size; row++) {
            const u16 *line = icon + row * src_w;
            for (int col = 0; col < size; col++) tex_put(data, col, row, rgba565(line[col], key_zero));
        }
    } else {
        for (int row = 0; row < size; row++) {
            int sy = row * src_w;
            int y0 = sy / size;
            int fy = ((sy % size) * 256) / size;
            if (y0 >= src_w) y0 = src_w - 1;
            int y1 = y0 + 1;
            if (y1 >= src_w) y1 = y0;
            for (int col = 0; col < size; col++) {
                int sx = col * src_w;
                int x0 = sx / size;
                int fx = ((sx % size) * 256) / size;
                if (x0 >= src_w) x0 = src_w - 1;
                int x1 = x0 + 1;
                if (x1 >= src_w) x1 = x0;
                u16 c00 = icon[y0 * src_w + x0];
                u16 c10 = icon[y0 * src_w + x1];
                u16 c01 = icon[y1 * src_w + x0];
                u16 c11 = icon[y1 * src_w + x1];
                if (key_zero && c00 == 0) continue;
                if (key_zero && (c10 == 0 || c01 == 0 || c11 == 0)) {
                    tex_put(data, col, row, rgba565(c00, true));
                    continue;
                }
                int r00, g00, b00, r10, g10, b10, r01, g01, b01, r11, g11, b11;
                unpack565(c00, &r00, &g00, &b00);
                unpack565(c10, &r10, &g10, &b10);
                unpack565(c01, &r01, &g01, &b01);
                unpack565(c11, &r11, &g11, &b11);
                int w00 = (256 - fx) * (256 - fy);
                int w10 = fx * (256 - fy);
                int w01 = (256 - fx) * fy;
                int w11 = fx * fy;
                tex_put(data, col, row,
                        C2D_Color32((u8)((r00 * w00 + r10 * w10 + r01 * w01 + r11 * w11) >> 16),
                                    (u8)((g00 * w00 + g10 * w10 + g01 * w01 + g11 * w11) >> 16),
                                    (u8)((b00 * w00 + b10 * w10 + b01 * w01 + b11 * w11) >> 16),
                                    255));
            }
        }
    }

    C3D_TexFlush(&slot->tex);
    float u = (float)size / (float)ICON_TEX;
    slot->sub.width = (u16)size;
    slot->sub.height = (u16)size;
    slot->sub.left = 0.0f;
    slot->sub.top = 1.0f;
    slot->sub.right = u;
    slot->sub.bottom = 1.0f - u;
    C2D_Image img = {&slot->tex, &slot->sub};
    C2D_DrawImageAt(img, (float)x, (float)y, 0.05f, NULL, 1.0f, 1.0f);
}
