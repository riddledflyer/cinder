#pragma once

#include <3ds.h>
#include <stdbool.h>

/* Citro2D. Both screens are redrawn into the current frame and shown together. */
void ui_init(void);
void ui_exit(void);
void ui_select(gfxScreen_t screen);
void ui_clear(void);
void ui_printf(const char *fmt, ...);
void ui_present(void);

void ui_size(int *width, int *height);
void ui_fill(int x, int y, int w, int h, u8 r, u8 g, u8 b);
int ui_text_width(const char *text, int max_chars);
int ui_text(int x, int y, const char *text, int max_chars, u8 r, u8 g, u8 b);
/* Square RGB565 icon. Same source and dest size is copied 1:1.
 * A different size is filtered. Pixel 0 is left transparent when key_zero
 * is set (DSiWare color 0). SMDH icons pass key_zero false. */
void ui_icon(int x, int y, const u16 *icon, int src_w, int size, bool key_zero);
