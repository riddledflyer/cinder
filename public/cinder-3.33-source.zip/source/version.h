#pragma once

#define CINDER_VERSION "3.33"
#define CINDER_REVISION 63
