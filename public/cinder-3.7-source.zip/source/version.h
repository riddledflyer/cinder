#pragma once

#define CINDER_VERSION "3.7"
#define CINDER_REVISION 37
