#pragma once

#define CINDER_VERSION "3.32"
#define CINDER_REVISION 62
