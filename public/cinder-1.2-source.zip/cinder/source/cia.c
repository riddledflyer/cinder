#include "cia.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* CIA sections are padded to 64 bytes, in this order: header, certificates,
 * ticket, TMD, contents, meta. A download that died early is shorter than
 * that sum. Those files are listed and refused. */

static FS_Archive g_sd;
static bool g_sd_open;
static u8 *g_buf;
static u32 g_buf_size;

static u64 align64(u64 n) {
    return (n + 63ull) & ~63ull;
}

static void sd_close(void) {
    if (g_sd_open) {
        FSUSER_CloseArchive(g_sd);
        g_sd_open = false;
    }
}

static bool sd_open(void) {
    if (g_sd_open) return true;
    if (R_FAILED(FSUSER_OpenArchive(&g_sd, ARCHIVE_SDMC, fsMakePath(PATH_EMPTY, "")))) return false;
    g_sd_open = true;
    return true;
}

static Result open_path(const u16 *path, Handle *out) {
    return FSUSER_OpenFile(out, g_sd, fsMakePath(PATH_UTF16, path), FS_OPEN_READ, 0);
}

static void name_to_utf8(char *out, size_t out_len, const u16 *in, size_t units) {
    size_t o = 0;
    if (out_len == 0) return;
    for (size_t i = 0; i < units && in[i] != 0 && o + 1 < out_len; i++) {
        u32 cp = in[i];
        if (cp < 0x80) {
            out[o++] = (char)cp;
        } else if (cp < 0x800 && o + 2 < out_len) {
            out[o++] = (char)(0xC0 | (cp >> 6));
            out[o++] = (char)(0x80 | (cp & 0x3F));
        } else if (o + 3 < out_len) {
            out[o++] = (char)(0xE0 | (cp >> 12));
            out[o++] = (char)(0x80 | ((cp >> 6) & 0x3F));
            out[o++] = (char)(0x80 | (cp & 0x3F));
        }
    }
    out[o] = '\0';
}

static bool ends_cia(const u16 *name) {
    int n = 0;
    while (name[n] && n < 0x106) n++;
    if (n < 5 || name[0] == '.' || name[n - 4] != '.') return false;
    u16 ext[3] = {name[n - 3], name[n - 2], name[n - 1]};
    for (int i = 0; i < 3; i++) {
        if (ext[i] >= 'A' && ext[i] <= 'Z') ext[i] = (u16)(ext[i] - 'A' + 'a');
    }
    return ext[0] == 'c' && ext[1] == 'i' && ext[2] == 'a';
}

static bool build_path(u16 *out, int cap, const char *dir, const u16 *name) {
    int i = 0;
    for (const char *p = dir; *p; p++) {
        if (i + 1 >= cap) return false;
        out[i++] = (u16)(unsigned char)*p;
    }
    for (int n = 0; name[n]; n++) {
        if (i + 1 >= cap) return false;
        out[i++] = name[n];
    }
    out[i] = 0;
    return true;
}

static u32 bswap32(u32 v) {
    return (v >> 24) | ((v >> 8) & 0xFF00) | ((v << 8) & 0xFF0000) | (v << 24);
}

static FS_MediaType media_of(u64 id) {
    u32 high = (u32)(id >> 32);
    if (high == 0x00048004 || high == 0x00030004 || titles_is_system_id(id)) return MEDIATYPE_NAND;
    return MEDIATYPE_SD;
}

static u32 sig_block(u32 type) {
    switch (type) {
        case 0x00010000:
        case 0x00010003:
            return 0x240;
        case 0x00010001:
        case 0x00010004:
            return 0x140;
        case 0x00010002:
        case 0x00010005:
            return 0x80;
        default:
            return 0;
    }
}

/* Reads the header and, when the TMD is inside the file, the title id.
 * declared is the padded size of every CIA section. */
static bool read_info(Handle file, u64 file_size, u64 *declared, u64 *title_id, u16 *version) {
    u8 hdr[0x20];
    u32 got = 0;
    if (R_FAILED(FSFILE_Read(file, &got, 0, hdr, sizeof(hdr))) || got < sizeof(hdr)) return false;

    u32 header_size = 0, cert_size = 0, ticket_size = 0, tmd_size = 0, meta_size = 0;
    u64 content_size = 0;
    memcpy(&header_size, hdr + 0x00, 4);
    memcpy(&cert_size, hdr + 0x08, 4);
    memcpy(&ticket_size, hdr + 0x0C, 4);
    memcpy(&tmd_size, hdr + 0x10, 4);
    memcpy(&meta_size, hdr + 0x14, 4);
    memcpy(&content_size, hdr + 0x18, 8);

    if (header_size < 0x2020 || header_size > 0x3000) return false;
    if (cert_size == 0 || cert_size > 0x10000) return false;
    if (ticket_size < 0x200 || ticket_size > 0x2000) return false;
    if (tmd_size < 0x140 || tmd_size > 0x5000) return false;
    if (meta_size > 0x40000) return false;
    if (content_size == 0 || content_size > 0x100000000ull) return false;

    *declared = align64(header_size) + align64(cert_size) + align64(ticket_size) +
                align64(tmd_size) + align64(content_size) + align64(meta_size);
    *title_id = 0;
    *version = 0;

    u64 tmd_off = align64(header_size) + align64(cert_size) + align64(ticket_size);
    if (file_size < tmd_off + 4) return true;

    u32 sig = 0;
    got = 0;
    if (R_FAILED(FSFILE_Read(file, &got, tmd_off, &sig, 4)) || got != 4) return true;
    u32 block = sig_block(sig);
    if (block == 0) block = sig_block(bswap32(sig));
    if (block == 0 || file_size < tmd_off + block + 0x9E) return true;

    u8 body[0xA0];
    got = 0;
    if (R_FAILED(FSFILE_Read(file, &got, tmd_off + block, body, sizeof(body))) || got < sizeof(body)) return true;
    memcpy(title_id, body + 0x4C, 8);
    memcpy(version, body + 0x9C, 2);
    return true;
}

static void fill_rec(CiaRec *cia, Handle file) {
    u64 declared = 0, title = 0;
    u16 version = 0;
    u64 size = 0;
    FSFILE_GetSize(file, &size);
    cia->file_size = size;
    bool ok = read_info(file, size, &declared, &title, &version);
    cia->header_ok = ok;
    cia->declared_size = declared;
    cia->title_id = title;
    cia->version = version;
    cia->complete = ok && declared != 0 && size == declared;
    cia->kind = title ? titles_kind_of(title) : KIND_GAME;
    cia->media = media_of(title);
    /* Size is the only install check. A homebrew CIA is not system
     * software just because its title id was not read, and a Nintendo
     * game is not system software because of who published it. */
    cia->installable = cia->complete;
    cia->selected = false;
}

static int cmp_cia(const void *a, const void *b) {
    const CiaRec *ca = a;
    const CiaRec *cb = b;
    return strcmp(ca->name, cb->name);
}

static void scan_dir(CiaList *list, const char *dir_path, const char *prefix) {
    if (list->count >= CIA_CAP) return;
    Handle handle = 0;
    if (R_FAILED(FSUSER_OpenDirectory(&handle, g_sd, fsMakePath(PATH_ASCII, dir_path)))) return;

    for (;;) {
        if (list->count >= CIA_CAP) break;
        FS_DirectoryEntry ent;
        u32 read = 0;
        if (R_FAILED(FSDIR_Read(handle, &read, 1, &ent)) || read != 1) break;
        if (ent.attributes & FS_ATTRIBUTE_DIRECTORY) continue;
        if (!ends_cia(ent.name)) continue;

        CiaRec *cia = &list->items[list->count];
        memset(cia, 0, sizeof(*cia));
        if (!build_path(cia->path, 160, prefix, ent.name)) continue;
        name_to_utf8(cia->name, sizeof(cia->name), ent.name, 0x106);

        Handle file = 0;
        if (R_FAILED(open_path(cia->path, &file))) continue;
        fill_rec(cia, file);
        FSFILE_Close(file);
        list->count++;
    }
    FSDIR_Close(handle);
}

Result cias_load(CiaList *list) {
    cias_free(list);
    memset(list, 0, sizeof(*list));
    if (!sd_open()) {
        list->rc = (Result)0xC8804471;
        return list->rc;
    }
    list->items = calloc(CIA_CAP, sizeof(CiaRec));
    if (!list->items) {
        list->rc = CIA_ERR_OOM;
        return list->rc;
    }
    u32 before = 0;
    scan_dir(list, "/cias/", "/cias/");
    if (list->count == before) scan_dir(list, "/cias", "/cias/");
    scan_dir(list, "/", "/");
    if (list->count > 1) qsort(list->items, list->count, sizeof(CiaRec), cmp_cia);
    if (list->count == 0) {
        free(list->items);
        list->items = NULL;
    } else if (list->count < CIA_CAP) {
        CiaRec *shrunk = realloc(list->items, list->count * sizeof(CiaRec));
        if (shrunk) list->items = shrunk;
    }
    return 0;
}

void cias_free(CiaList *list) {
    if (!list) return;
    free(list->items);
    list->items = NULL;
    list->count = 0;
    sd_close();
    free(g_buf);
    g_buf = NULL;
    g_buf_size = 0;
}

static u8 *buffer(void) {
    if (g_buf) return g_buf;
    static const u32 sizes[] = {128 * 1024, 64 * 1024, 16 * 1024};
    for (int i = 0; i < 3; i++) {
        g_buf = malloc(sizes[i]);
        if (g_buf) {
            g_buf_size = sizes[i];
            return g_buf;
        }
    }
    return NULL;
}

static void close_import(Handle cia, bool cancel) {
    if (cancel) {
        if (R_FAILED(AM_CancelCIAInstall(cia))) svcCloseHandle(cia);
        return;
    }
}

/* 0xC8E083FC: status / invalid argument / AM / already exists.
 * AM_StartCiaInstall returns a handle before it knows the title id.
 * The "already exists" result comes back from AM_FinishCiaInstall, so a
 * failed Start is not something we can wait for. */
#define AM_ALREADY ((Result)0xC8E083FC)

static bool title_installed(FS_MediaType media, u64 id) {
    AM_TitleInfo info;
    if (id == 0) return false;
    memset(&info, 0, sizeof(info));
    if (R_FAILED(AM_GetTitleInfo(media, 1, &id, &info))) return false;
    return info.titleID == id;
}

static void clear_pending(u64 id) {
    if (id == 0) return;
    AM_DeletePendingTitle(MEDIATYPE_SD, id);
    AM_DeletePendingTitle(MEDIATYPE_NAND, id);
}

static void remove_installed(u64 id, bool self) {
    clear_pending(id);
    if (id == 0 || self) return;
    if (title_installed(MEDIATYPE_SD, id)) {
        if (R_FAILED(AM_DeleteUserTitle(MEDIATYPE_SD, id))) AM_DeleteTitle(MEDIATYPE_SD, id);
    }
    if (title_installed(MEDIATYPE_NAND, id)) {
        if (R_FAILED(AM_DeleteUserTitle(MEDIATYPE_NAND, id))) AM_DeleteTitle(MEDIATYPE_NAND, id);
    }
}

static FS_MediaType choose_media(u64 id, FS_MediaType guess) {
    if (title_installed(MEDIATYPE_SD, id)) return MEDIATYPE_SD;
    if (title_installed(MEDIATYPE_NAND, id)) return MEDIATYPE_NAND;
    return guess;
}

static Result begin_import(FS_MediaType media, u64 id, bool self, Handle *import) {
    bool exists = title_installed(MEDIATYPE_SD, id) || title_installed(MEDIATYPE_NAND, id);
    clear_pending(id);
    Result rc;
    if (exists) rc = AM_StartCiaInstallOverwrite(import, media);
    else rc = AM_StartCiaInstall(media, import);
    if (R_SUCCEEDED(rc)) return rc;
    if (rc != AM_ALREADY) {
        Result other = exists ? AM_StartCiaInstall(media, import)
                              : AM_StartCiaInstallOverwrite(import, media);
        return R_SUCCEEDED(other) ? other : rc;
    }

    remove_installed(id, self);
    rc = AM_StartCiaInstallOverwrite(import, media);
    if (R_SUCCEEDED(rc)) return rc;
    rc = AM_StartCiaInstall(media, import);
    if (rc != AM_ALREADY) return rc;
    if (!self && id != 0) AM_DeleteTicket(id);
    clear_pending(id);
    return AM_StartCiaInstall(media, import);
}

Result cias_install_one(const CiaRec *cia, u32 index, u32 total, CiaPumpFn pump, void *user) {
    if (!cia || !cia->installable || !cia->complete) return CIA_ERR_TRUNCATED;
    if (!sd_open()) return (Result)0xC8804471;

    Handle file = 0;
    Result rc = open_path(cia->path, &file);
    if (R_FAILED(rc)) return rc;

    u64 size = 0;
    FSFILE_GetSize(file, &size);
    u64 declared = 0, title = 0;
    u16 version = 0;
    bool ok = read_info(file, size, &declared, &title, &version);
    if (!ok || declared == 0 || size != declared || title != cia->title_id) {
        FSFILE_Close(file);
        return CIA_ERR_TRUNCATED;
    }

    if (title == 0) {
        AM_TitleInfo info;
        memset(&info, 0, sizeof(info));
        if (R_SUCCEEDED(AM_GetCiaFileInfo(MEDIATYPE_SD, &info, file)) && info.titleID) title = info.titleID;
        else if (R_SUCCEEDED(AM_GetCiaFileInfo(MEDIATYPE_NAND, &info, file)) && info.titleID) title = info.titleID;
    }

    u8 *buf = buffer();
    if (!buf) {
        FSFILE_Close(file);
        return CIA_ERR_OOM;
    }

    bool self = title == CINDER_TITLE_ID || title == titles_self_id();
    FS_MediaType guess = cia->media;
    if (title_installed(MEDIATYPE_NAND, title)) guess = MEDIATYPE_NAND;

    for (int attempt = 0; attempt < 2; attempt++) {
        if (attempt == 1) {
            remove_installed(title, self);
            if (!self && title != 0) AM_DeleteTicket(title);
        }

        Handle import = 0;
        FS_MediaType media = choose_media(title, guess);
        rc = begin_import(media, title, self, &import);
        if (R_FAILED(rc)) {
            FSFILE_Close(file);
            return rc;
        }

        u64 off = 0;
        bool cancel = false;
        while (off < size) {
            if (pump && !pump(cia, index, total, off, user)) {
                cancel = true;
                break;
            }
            u32 chunk = g_buf_size;
            if ((u64)chunk > size - off) chunk = (u32)(size - off);
            u32 got = 0;
            rc = FSFILE_Read(file, &got, off, buf, chunk);
            if (R_FAILED(rc) || got == 0) break;
            u32 wrote = 0;
            rc = FSFILE_Write(import, &wrote, off, buf, got, FS_WRITE_FLUSH);
            if (R_FAILED(rc) || wrote != got) {
                if (R_SUCCEEDED(rc)) rc = CIA_ERR_TRUNCATED;
                break;
            }
            off += wrote;
        }

        if (cancel || off != size || R_FAILED(rc)) {
            close_import(import, true);
            FSFILE_Close(file);
            if (cancel) return CIA_ERR_CANCEL;
            return R_FAILED(rc) ? rc : CIA_ERR_TRUNCATED;
        }
        if (pump) pump(cia, index, total, size, user);

        rc = AM_FinishCiaInstall(import);
        if (rc != AM_ALREADY || attempt == 1) {
            /* Finish moves the handle into AM, including when it fails. */
            FSFILE_Close(file);
            return rc;
        }
    }

    FSFILE_Close(file);
    return rc;
}
