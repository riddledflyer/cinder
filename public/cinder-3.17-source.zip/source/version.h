#pragma once

#define CINDER_VERSION "3.17"
#define CINDER_REVISION 47
