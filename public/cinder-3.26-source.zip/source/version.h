#pragma once

#define CINDER_VERSION "3.26"
#define CINDER_REVISION 56
