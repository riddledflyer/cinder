#include "bgm.h"

#include <3ds.h>
#include <string.h>

extern const u8 bgm_bin[];
extern const u8 bgm_bin_end[];

#define BGM_RATE 16000

static u8 *g_pcm;
static u32 g_play;
static u32 g_rate = BGM_RATE;
static bool g_on;
static bool g_csnd;
static int g_chn = -1;
static aptHookCookie g_hook;
static bool g_hooked;

static int owned_channel(void) {

    for (int ch = 0; ch < 32; ch++) {
        if (csndChannels & BIT(ch)) return ch;
    }
    return -1;
}

static void drop_csnd(void) {
    if (!g_csnd) return;
    csndExit();
    g_csnd = false;
    g_chn = -1;
}

static bool play_now(void) {
    int ch;
    Result rc;
    if (!g_on || !g_pcm || g_play < 64) return false;
    if (!g_csnd) {
        if (R_FAILED(csndInit())) return false;
        g_csnd = true;
    }
    ch = owned_channel();
    if (ch < 0) {
        drop_csnd();
        return false;
    }
    g_chn = ch;
    GSPGPU_FlushDataCache(g_pcm, g_play);
    rc = csndPlaySound(ch, SOUND_FORMAT_8BIT | SOUND_REPEAT, g_rate, 1.0f, 0.0f, g_pcm, g_pcm, g_play);
    if (rc != 0) {
        drop_csnd();
        return false;
    }
    CSND_SetVol(ch, 0x80008000u, 0);
    csndExecCmds(true);
    return true;
}

static volatile int g_wake;

static void apt_event(APT_HookType hook, void *param) {
    (void)param;
    if (hook == APTHOOK_ONSUSPEND || hook == APTHOOK_ONSLEEP || hook == APTHOOK_ONEXIT ||
        hook == APTHOOK_ONRESTORE || hook == APTHOOK_ONWAKEUP) {
        g_wake = 45;
    }
}

void bgm_start(void) {
    u32 size = (u32)(bgm_bin_end - bgm_bin);
    if (size < 64) return;
    if (R_FAILED(csndInit())) return;
    g_csnd = true;

    int ch = owned_channel();
    if (ch < 0) {
        drop_csnd();
        return;
    }

    u32 step = 1;
    u32 freeb = linearSpaceFree();
    while (step < 8 && size / step + 0x2000 > freeb) step++;
    u32 play = size / step;
    play &= ~3u;
    if (play < 64) {
        drop_csnd();
        return;
    }

    g_pcm = linearAlloc(play);
    if (!g_pcm) {
        drop_csnd();
        return;
    }
    if (step == 1) {
        memcpy(g_pcm, bgm_bin, play);
    } else {
        for (u32 i = 0; i < play; i++) g_pcm[i] = bgm_bin[i * step];
    }
    GSPGPU_FlushDataCache(g_pcm, play);

    g_rate = BGM_RATE / step;
    g_play = play;
    g_chn = ch;
    g_on = true;
    if (!play_now()) {
        linearFree(g_pcm);
        g_pcm = NULL;
        g_play = 0;
        g_on = false;
        drop_csnd();
        return;
    }
    if (!g_hooked) {
        aptHook(&g_hook, apt_event, NULL);
        g_hooked = true;
    }
    g_on = true;
}

void bgm_poll(void) {
    if (!g_on) return;
    if (g_wake > 0) {
        int left = g_wake--;
        if (left == 45 || left == 30 || left == 15 || left == 1) {
            drop_csnd();
            play_now();
        }
        return;
    }
    if (!g_csnd) play_now();
}

void bgm_stop(void) {
    if (!g_on && !g_pcm && g_chn < 0) return;
    if (g_hooked) {
        aptUnhook(&g_hook);
        g_hooked = false;
    }

    if (g_csnd) {
        for (int ch = 0; ch < 32; ch++) {
            if (csndChannels & BIT(ch)) {
                CSND_SetVol(ch, 0, 0);
                CSND_SetPlayState(ch, 0);
            }
        }
        csndExecCmds(true);
        if (g_pcm && g_play) {
            memset(g_pcm, 0, g_play);
            GSPGPU_FlushDataCache(g_pcm, g_play);
        }
        svcSleepThread(20000000);
        drop_csnd();
    }
    if (g_pcm) linearFree(g_pcm);
    g_pcm = NULL;
    g_play = 0;
    g_chn = -1;
    g_on = false;
}
