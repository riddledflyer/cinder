#pragma once

#define CINDER_VERSION "3.27"
#define CINDER_REVISION 57
