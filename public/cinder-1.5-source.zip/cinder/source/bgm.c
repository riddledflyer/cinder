#include "bgm.h"

#include <3ds.h>
#include <string.h>

/* data/bgm.bin, converted from the bundled track.
 * Mono signed PCM8 at 16 kHz. A 16-bit or stereo copy does not fit in the
 * 4 MB linear heap next to the framebuffers on an old 3DS. */
extern const u8 bgm_bin[];
extern const u8 bgm_bin_end[];

#define BGM_RATE 16000

static u8 *g_pcm;
static bool g_on;

void bgm_start(void) {
    u32 size = (u32)(bgm_bin_end - bgm_bin);
    if (size < 64) return;
    if (R_FAILED(csndInit())) return;
    g_pcm = linearAlloc(size);
    if (!g_pcm) {
        csndExit();
        return;
    }
    memcpy(g_pcm, bgm_bin, size);
    GSPGPU_FlushDataCache(g_pcm, size);
    if (R_FAILED(csndPlaySound(0, SOUND_FORMAT_8BIT | SOUND_REPEAT, BGM_RATE, 0.9f, 0.0f,
                               g_pcm, g_pcm, size))) {
        linearFree(g_pcm);
        g_pcm = NULL;
        csndExit();
        return;
    }
    g_on = true;
}

void bgm_stop(void) {
    if (!g_on && !g_pcm) return;
    csndExit();
    if (g_pcm) linearFree(g_pcm);
    g_pcm = NULL;
    g_on = false;
}
