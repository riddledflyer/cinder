#pragma once

#define CINDER_VERSION "3.16"
#define CINDER_REVISION 46
