#pragma once

#define CINDER_VERSION "3.20"
#define CINDER_REVISION 50
