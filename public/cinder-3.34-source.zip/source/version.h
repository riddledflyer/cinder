#pragma once

#define CINDER_VERSION "3.34"
#define CINDER_REVISION 64
