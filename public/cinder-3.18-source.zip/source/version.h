#pragma once

#define CINDER_VERSION "3.18"
#define CINDER_REVISION 48
