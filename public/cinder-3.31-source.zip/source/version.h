#pragma once

#define CINDER_VERSION "3.31"
#define CINDER_REVISION 61
