#pragma once

#define CINDER_VERSION "3.37"
#define CINDER_REVISION 67
