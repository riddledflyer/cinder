#include "titles.h"
#include "cia.h"
#include "ui.h"
#include "bgm.h"
#include "version.h"

#include "imgui.h"

#include <stdio.h>
#include <string.h>

#define LIST_HEADER 18
#define ROW_H 52
#define LIST_ROWS 4
#define CIA_ROW_H 52
#define CIA_ROWS 4

typedef enum {
    MODE_LIST = 0,
    MODE_CONFIRM,
    MODE_RESULT,
    MODE_INSTALL,
    MODE_INSTALL_CONFIRM
} Mode;

static int g_visible[TITLE_CAP];
static u64 g_ids[TITLE_CAP];

static bool is_nds(const TitleRec *title) {
    return title->kind == KIND_DSIWARE;
}

static int build_visible(const TitleList *list, int nds, int *out) {
    int count = 0;
    for (u32 i = 0; i < list->count; i++) {
        const TitleRec *title = &list->items[i];
        if (title->kind == KIND_SYSTEM) continue;
        if (title->id == CINDER_TITLE_ID || title->id == titles_self_id()) continue;
        if (nds) {
            if (is_nds(title)) out[count++] = (int)i;
        } else if (!is_nds(title)) {
            out[count++] = (int)i;
        }
    }
    return count;
}

static void reload(TitleList *list, Result *load_rc) {
    ui_drop_images();
    titles_free(list);
    *load_rc = titles_load_all(list);
}

static u32 count_selected(const TitleList *list, u64 *bytes) {
    u32 count = 0;
    *bytes = 0;
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].selected && list->items[i].deletable) {
            count++;
            *bytes += list->items[i].size;
        }
    }
    return count;
}

static void select_visible(TitleList *list, const int *visible, int count, bool on) {
    for (int i = 0; i < count; i++) {
        TitleRec *title = &list->items[visible[i]];
        if (title->deletable) title->selected = on;
    }
}

static void toggle_visible(TitleList *list, const int *visible, int count) {
    int selectable = 0;
    int selected = 0;
    for (int i = 0; i < count; i++) {
        TitleRec *title = &list->items[visible[i]];
        if (!title->deletable) continue;
        selectable++;
        if (title->selected) selected++;
    }
    if (selectable == 0) return;
    select_visible(list, visible, count, selected < selectable);
}

static bool repeat_key(u32 down, u32 held, u32 key, int *timer) {
    if (down & key) {
        *timer = 0;
        return true;
    }
    if (held & key) {
        (*timer)++;
        return *timer > 16 && (*timer % 3) == 0;
    }
    *timer = 0;
    return false;
}

static FS_MediaType media_of(const TitleList *list, u64 id) {
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].id == id) return list->items[i].media;
    }
    return MEDIATYPE_SD;
}

static void panel(const char *id) {
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);
    ImGui::Begin(id, NULL,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus |
                     ImGuiWindowFlags_NoNav);
}

static void *icon_tex(const TitleRec *title, u32 tick) {
    const u16 *pix = title->icon;
    int src = title->icon_w > 0 ? title->icon_w : 48;
    if (title->anim) {
        u16 token = titles_anim_token(title->anim, tick);
        if (token) {
            struct Frame {
                const TitleRec *title;
                u16 token;
                u32 used;
                u16 pix[32 * 32];
            };
            static Frame cache[16];
            static u32 stamp = 1;
            int slot = -1;
            int oldest = 0;
            for (int i = 0; i < 16; i++) {
                if (cache[i].title == title) slot = i;
                if (cache[i].used < cache[oldest].used) oldest = i;
            }
            if (slot < 0) slot = oldest;
            if (cache[slot].title != title || cache[slot].token != token) {
                if (titles_anim_frame(title->anim, tick, cache[slot].pix)) {
                    cache[slot].title = title;
                    cache[slot].token = token;
                }
            }
            if (cache[slot].title == title) {
                pix = cache[slot].pix;
                src = 32;
                cache[slot].used = stamp++;
            }
        }
    }
    if (!pix) return NULL;
    return ui_image(pix, src, title->kind == KIND_DSIWARE);
}

static void storage_line(char *out, size_t n, const char *name, Result rc, const FS_ArchiveResource *res) {
    if (R_FAILED(rc) || res->totalClusters == 0) {
        snprintf(out, n, "%s  --", name);
        return;
    }
    u64 cluster = res->clusterSize ? (u64)res->clusterSize : 1;
    char free_s[16];
    char total_s[16];
    titles_format_size(free_s, sizeof(free_s), (u64)res->freeClusters * cluster);
    titles_format_size(total_s, sizeof(total_s), (u64)res->totalClusters * cluster);
    snprintf(out, n, "%s  %s / %s", name, free_s, total_s);
}

static bool g_ptmu;

static void civil_date(u32 days, int *year, int *month, int *day) {
    int y = 1900;
    while (1) {
        int leap = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
        u32 diy = leap ? 366u : 365u;
        if (days < diy) break;
        days -= diy;
        y++;
    }
    static const u8 mdays[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int leap = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
    int m = 0;
    for (; m < 12; m++) {
        u32 dim = mdays[m] + (m == 1 && leap);
        if (days < dim) break;
        days -= dim;
    }
    *year = y;
    *month = m + 1;
    *day = (int)days + 1;
}

static void format_clock(char *out, size_t n) {
    u64 secs = osGetTime() / 1000;
    u32 days = (u32)(secs / 86400);
    u32 sod = (u32)(secs % 86400);
    int hour = (int)(sod / 3600);
    int minute = (int)((sod % 3600) / 60);
    int year = 0;
    int month = 1;
    int day = 1;
    civil_date(days, &year, &month, &day);
    static const char *mo[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    int h12 = hour % 12;
    if (h12 == 0) h12 = 12;
    snprintf(out, n, "%s %d %d  %d:%02d %s", mo[month - 1], day, year, h12, minute, hour < 12 ? "AM" : "PM");
}

static void draw_battery(void) {
    u8 level = 0;
    u8 charge = 0;
    bool charging = false;
    if (g_ptmu && R_SUCCEEDED(PTMU_GetBatteryLevel(&level))) {
        if (level > 5) level = 5;
    } else {
        level = 0;
    }
    if (g_ptmu && R_SUCCEEDED(PTMU_GetBatteryChargeState(&charge))) charging = charge != 0;
    ImVec2 p = ImGui::GetCursorScreenPos();
    float h = ImGui::GetTextLineHeight();
    float w = 18.f;
    float bh = h * 0.62f;
    float by = p.y + (h - bh) * 0.5f;
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImU32 frame = IM_COL32(231, 233, 238, 255);
    ImU32 fill = charging ? IM_COL32(115, 217, 140, 255) : frame;
    if (!charging && level <= 1) fill = IM_COL32(181, 82, 74, 255);
    dl->AddRect(ImVec2(p.x, by), ImVec2(p.x + w - 3.f, by + bh), frame, 1.f);
    dl->AddRectFilled(ImVec2(p.x + w - 3.f, by + bh * 0.28f), ImVec2(p.x + w, by + bh * 0.72f), frame);
    if (level > 0) {
        float inner = (w - 7.f) * ((float)level / 5.f);
        dl->AddRectFilled(ImVec2(p.x + 2.f, by + 2.f), ImVec2(p.x + 2.f + inner, by + bh - 2.f), fill);
    }
    ImGui::Dummy(ImVec2(w + 2.f, h));
}

static void draw_clock_line(void) {
    char left[24];
    char clock[40];
    snprintf(left, sizeof(left), "Cinder %s", CINDER_VERSION);
    format_clock(clock, sizeof(clock));
    const float batt = 22.f;
    float pad = ImGui::GetStyle().WindowPadding.x;
    float left_w = ImGui::CalcTextSize(left).x;
    float clock_w = ImGui::CalcTextSize(clock).x;
    float x = ImGui::GetWindowWidth() - pad - batt - 8.f - clock_w;
    if (x < left_w + 12.f) {
        u64 secs = osGetTime() / 1000;
        u32 sod = (u32)(secs % 86400);
        int hour = (int)(sod / 3600);
        int minute = (int)((sod % 3600) / 60);
        int h12 = hour % 12;
        if (h12 == 0) h12 = 12;
        snprintf(clock, sizeof(clock), "%d:%02d %s", h12, minute, hour < 12 ? "AM" : "PM");
        clock_w = ImGui::CalcTextSize(clock).x;
        x = ImGui::GetWindowWidth() - pad - batt - 8.f - clock_w;
    }
    ImGui::TextUnformatted(left);
    ImGui::SameLine();
    ImGui::SetCursorPosX(x);
    ImGui::TextUnformatted(clock);
    ImGui::SameLine(0.f, 8.f);
    draw_battery();
}

static void draw_prompts(const char *line) {
    float width = ImGui::CalcTextSize(line).x;
    float avail = ImGui::GetWindowContentRegionMax().x - ImGui::GetWindowContentRegionMin().x;
    float scale = 1.f;
    if (width > avail && width > 1.f) scale = avail / width;
    float y = ImGui::GetWindowContentRegionMax().y - ImGui::GetTextLineHeight() * scale;
    ImGui::SetCursorPosY(y);
    ImGui::SetWindowFontScale(scale);
    ImGui::TextDisabled("%s", line);
    ImGui::SetWindowFontScale(1.f);
}

static void draw_selection(u32 selected, u64 bytes) {
    char size[16];
    char line[40];
    titles_format_size(size, sizeof(size), bytes);
    snprintf(line, sizeof(line), "%lu selected  %s", (unsigned long)selected, size);
    float w = ImGui::CalcTextSize(line).x;
    ImGui::SameLine();
    ImGui::SetCursorPosX(ImGui::GetWindowWidth() - w - ImGui::GetStyle().WindowPadding.x);
    ImGui::TextUnformatted(line);
}

static void storage_side(float y) {
    FS_ArchiveResource sd;
    FS_ArchiveResource nand;
    memset(&sd, 0, sizeof(sd));
    memset(&nand, 0, sizeof(nand));
    Result sd_rc = FSUSER_GetSdmcArchiveResource(&sd);
    Result nand_rc = FSUSER_GetNandArchiveResource(&nand);
    char a[64];
    char b[64];
    storage_line(a, sizeof(a), "SD", sd_rc, &sd);
    storage_line(b, sizeof(b), "NAND", nand_rc, &nand);
    float right = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
    float step = ImGui::GetTextLineHeightWithSpacing();
    ImVec2 saved = ImGui::GetCursorScreenPos();
    ImGui::SetCursorScreenPos(ImVec2(right - ImGui::CalcTextSize(a).x, y));
    ImGui::TextDisabled("%s", a);
    ImGui::SetCursorScreenPos(ImVec2(right - ImGui::CalcTextSize(b).x, y + step));
    ImGui::TextDisabled("%s", b);
    ImGui::SetCursorScreenPos(saved);
}

static bool shelf_tabs(int *nds, int *cursor) {
    bool changed = false;
    if (!ImGui::BeginTabBar("shelf")) return false;
    static int synced = -1;
    ImGuiTabItemFlags ds = 0;
    ImGuiTabItemFlags ns = 0;
    if (synced != *nds) {
        if (*nds) ns = ImGuiTabItemFlags_SetSelected;
        else ds = ImGuiTabItemFlags_SetSelected;
        synced = *nds;
    }
    if (ImGui::BeginTabItem("3DS", NULL, ds)) {
        if (*nds) {
            *nds = 0;
            *cursor = 0;
            changed = true;
            synced = 0;
        }
        ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem("NDS", NULL, ns)) {
        if (!*nds) {
            *nds = 1;
            *cursor = 0;
            changed = true;
            synced = 1;
        }
        ImGui::EndTabItem();
    }
    ImGui::EndTabBar();
    return changed;
}

static bool list_row(const char *id, bool active, bool marked, void *tex, const char *title, const char *sub, const char *side) {
    ImGui::PushID(id);
    ImVec2 origin = ImGui::GetCursorScreenPos();
    bool hit = ImGui::Selectable("##row", active, 0, ImVec2(0, 48));
    ImGui::SetCursorScreenPos(ImVec2(origin.x + 4, origin.y + 5));
    if (tex) {
        ImGui::Image((ImTextureID)tex, ImVec2(36, 36));
        ImGui::SameLine();
    }
    ImGui::BeginGroup();
    if (marked) ImGui::TextColored(ImVec4(0.45f, 0.85f, 0.55f, 1.f), "%s", title);
    else ImGui::TextUnformatted(title);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.60f, 0.64f, 0.68f, 1.f));
    ImGui::TextUnformatted(sub[0] ? sub : "-");
    ImGui::PopStyleColor();
    ImGui::EndGroup();
    if (side && side[0]) {
        float x = origin.x + ImGui::GetWindowWidth() - ImGui::CalcTextSize(side).x - 18.f;
        ImGui::SameLine();
        ImGui::SetCursorScreenPos(ImVec2(x, origin.y + 14));
        ImGui::TextUnformatted(side);
    }
    ImGui::SetCursorScreenPos(ImVec2(origin.x, origin.y + 48));
    ImGui::Dummy(ImVec2(0, 0));
    ImGui::PopID();
    return hit;
}

static void scroll_to(const char *key, int cursor) {
    float avail = ImGui::GetContentRegionAvail().y;
    int rows = (int)(avail / 48.f);
    if (rows < 1) rows = 1;
    ImGuiID id = ImGui::GetID(key);
    static ImGuiID last_id = 0;
    static int top = 0;
    if (last_id != id) {
        top = 0;
        last_id = id;
    }
    if (cursor < top) top = cursor;
    if (cursor >= top + rows) top = cursor - rows + 1;
    if (top < 0) top = 0;
    ImGui::SetNextWindowScroll(ImVec2(0.f, (float)top * 48.f));
}

static void draw_top(const TitleList *list, const int *visible, int vcount, int cursor,
                     int nds, Result services, Result load_rc, const char *status, u32 tick) {
    ui_screen(GFX_TOP);
    panel("top");
    draw_clock_line();
    ImGui::Separator();
    ImVec2 block = ImGui::GetCursorScreenPos();
    storage_side(block.y);
    if (R_FAILED(services)) {
        ImGui::Text("Service init failed.");
        ImGui::TextDisabled("0x%08lX", (unsigned long)services);
        ImGui::TextDisabled("Install the CIA, or run the 3dsx from Homebrew Launcher on Luma.");
    } else if (R_FAILED(load_rc)) {
        ImGui::Text("Could not list titles.");
        ImGui::TextDisabled("0x%08lX", (unsigned long)load_rc);
    } else if (vcount <= 0 || cursor < 0 || cursor >= vcount) {
        ImGui::Text("%s", nds ? "No NDS software." : "No 3DS software.");
        ImGui::TextDisabled("%s", nds ? "DSiWare on NAND shows up here." : "Games, demos, updates, and DLC.");
    } else {
        const TitleRec *title = &list->items[visible[cursor]];
        char ver[16];
        char size[16];
        titles_format_version(ver, sizeof(ver), title->version);
        titles_format_size(size, sizeof(size), title->size);
        void *tex = icon_tex(title, tick);
        if (tex) {
            ImGui::Image((ImTextureID)tex, ImVec2(48, 48));
            ImGui::SameLine();
        }
        float wrap = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x - 168.f;
        ImGui::BeginGroup();
        ImGui::PushTextWrapPos(wrap);
        ImGui::TextWrapped("%s", title->name);
        ImGui::TextDisabled("%s", title->publisher[0] ? title->publisher : "-");
        ImGui::PopTextWrapPos();
        ImGui::Text("%s    v%s", titles_kind_name(title->kind), ver);
        ImGui::Text("%s    %s", size, title->media == MEDIATYPE_SD ? "SD card" : "NAND");
        ImGui::TextDisabled("%s", title->product[0] ? title->product : "-");
        ImGui::TextDisabled("%016llX", (unsigned long long)title->id);
        ImGui::EndGroup();
    }
    if (status && status[0]) ImGui::TextColored(ImVec4(0.90f, 0.77f, 0.47f, 1.f), "%s", status);
    draw_prompts("A select  X all  SELECT install  START delete  START+SELECT exit");
    ImGui::End();
}

static void draw_list(const TitleList *list, const int *visible, int vcount, int *cursor, int *nds, u32 tick) {
    ui_screen(GFX_BOTTOM);
    panel("list");
    shelf_tabs(nds, cursor);
    ImGui::TextDisabled("%d", vcount);
    u64 selected_bytes = 0;
    draw_selection(count_selected(list, &selected_bytes), selected_bytes);
    scroll_to("titles", *cursor);
    ImGui::BeginChild("rows", ImVec2(0, 0), false);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.f, 0.f));
    if (vcount <= 0) ImGui::Text("%s", *nds ? "No NDS software." : "No 3DS software.");
    ImGuiListClipper clipper;
    clipper.Begin(vcount, 48.f);
    while (clipper.Step()) {
        for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; row++) {
            const TitleRec *title = &list->items[visible[row]];
            char ver[16];
            char size[16];
            char sub[80];
            titles_format_version(ver, sizeof(ver), title->version);
            titles_format_size(size, sizeof(size), title->size);
            snprintf(sub, sizeof(sub), "%s  v%s", title->publisher[0] ? title->publisher : "-", ver);
            char id[16];
            snprintf(id, sizeof(id), "t%d", row);
            if (list_row(id, row == *cursor, title->selected, icon_tex(title, tick), title->name, sub, size)) {
                *cursor = row;
                if (title->deletable) {
                    TitleRec *mut = (TitleRec *)&list->items[visible[row]];
                    mut->selected = !mut->selected;
                }
            }
        }
    }
    ImGui::PopStyleVar();
    ImGui::EndChild();
    ImGui::End();
}

static void draw_confirm(u32 count, u64 bytes, bool *related, bool *tickets, int *action) {
    ui_screen(GFX_BOTTOM);
    panel("confirm");
    char size[16];
    titles_format_size(size, sizeof(size), bytes);
    ImGui::Text("Delete %lu titles?", (unsigned long)count);
    ImGui::Text("Size %s", size);
    ImGui::Checkbox("Updates and DLC", related);
    ImGui::Checkbox("Delete tickets", tickets);
    ImGui::TextWrapped("Tickets stay off unless you need the title gone for good. Saves may remain either way.");
    if (ImGui::Button("Delete", ImVec2(120, 28))) *action = 1;
    ImGui::SameLine();
    if (ImGui::Button("Cancel", ImVec2(120, 28))) *action = 2;
    ImGui::End();
}

static void draw_result(const char *status, int *action) {
    ui_screen(GFX_BOTTOM);
    panel("result");
    ImGui::TextWrapped("%s", status);
    if (ImGui::Button("Back", ImVec2(120, 28))) *action = 2;
    ImGui::End();
}

static void on_progress(u32 index, u32 total, u64 id, Result rc, bool ticket_ok, void *user) {
    bool tickets = *(bool *)user;
    ui_screen(GFX_BOTTOM);
    panel("progress");
    ImGui::Text("Deleting %lu / %lu", (unsigned long)(index + 1), (unsigned long)total);
    ImGui::TextDisabled("%016llX", (unsigned long long)id);
    if (R_FAILED(rc)) ImGui::Text("Failed  0x%08lX", (unsigned long)rc);
    else ImGui::Text("Removed");
    if (tickets && R_SUCCEEDED(rc) && !ticket_ok) ImGui::TextDisabled("Ticket kept");
    float frac = total ? (float)(index + 1) / (float)total : 1.f;
    ImGui::ProgressBar(frac, ImVec2(-1, 18));
    ImGui::End();
    ui_present();
}

static Result delete_selected(TitleList *list, bool related, bool tickets) {
    u32 count = titles_collect(list, g_ids, TITLE_CAP, related);
    if (count == 0) return 0;

    u32 sd_n = 0;
    for (u32 i = 0; i < count; i++) {
        if (media_of(list, g_ids[i]) != MEDIATYPE_SD) continue;
        u64 swap = g_ids[sd_n];
        g_ids[sd_n] = g_ids[i];
        g_ids[i] = swap;
        sd_n++;
    }

    Result rc = 0;
    if (sd_n > 0) {
        Result one = titles_delete(MEDIATYPE_SD, g_ids, sd_n, tickets, on_progress, &tickets);
        if (R_FAILED(one)) rc = one;
    }
    if (count > sd_n) {
        Result one = titles_delete(MEDIATYPE_NAND, g_ids + sd_n, count - sd_n, tickets, on_progress, &tickets);
        if (R_FAILED(one)) rc = one;
    }
    return rc;
}

static bool in_cias_dir(const CiaRec *cia) {
    return cia->path[1] == 'c' && cia->path[2] == 'i' && cia->path[3] == 'a' &&
           cia->path[4] == 's' && cia->path[5] == '/';
}

static u32 count_cias(const CiaList *list, u64 *bytes) {
    u32 count = 0;
    *bytes = 0;
    if (!list->items) return 0;
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].selected && list->items[i].installable) {
            count++;
            *bytes += list->items[i].file_size;
        }
    }
    return count;
}

static void toggle_cias(CiaList *list) {
    if (!list->items) return;
    int selectable = 0;
    int selected = 0;
    for (u32 i = 0; i < list->count; i++) {
        if (!list->items[i].installable) continue;
        selectable++;
        if (list->items[i].selected) selected++;
    }
    if (selectable == 0) return;
    bool on = selected < selectable;
    for (u32 i = 0; i < list->count; i++) {
        if (list->items[i].installable) list->items[i].selected = on;
    }
}

static const char *cia_label(const CiaRec *cia) {
    return cia->title_name[0] ? cia->title_name : cia->name;
}

static void draw_install_top(const CiaList *cias, int cursor, const char *status) {
    ui_screen(GFX_TOP);
    panel("itop");
    draw_clock_line();
    ImGui::Separator();
    ImVec2 block = ImGui::GetCursorScreenPos();
    storage_side(block.y);
    int n = cias->items ? (int)cias->count : 0;
    if (R_FAILED(cias->rc)) {
        ImGui::Text("Could not read the SD card.");
        ImGui::TextDisabled("0x%08lX", (unsigned long)cias->rc);
    } else if (n <= 0 || cursor < 0 || cursor >= n) {
        ImGui::Text("No CIAs found.");
        ImGui::TextDisabled("Looked in sdmc:/cias/ and the SD card root.");
        ImGui::TextDisabled("A CIA can be installed when its size matches the header.");
    } else {
        const CiaRec *cia = &cias->items[cursor];
        void *tex = cia->icon ? ui_image(cia->icon, cia->icon_w > 0 ? cia->icon_w : 48, false) : NULL;
        if (tex) {
            ImGui::Image((ImTextureID)tex, ImVec2(48, 48));
            ImGui::SameLine();
        }
        float wrap = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x - 168.f;
        ImGui::BeginGroup();
        ImGui::PushTextWrapPos(wrap);
        ImGui::TextWrapped("%s", cia_label(cia));
        ImGui::TextDisabled("%s", cia->publisher[0] ? cia->publisher : "-");
        ImGui::PopTextWrapPos();
        ImGui::TextDisabled("%s", in_cias_dir(cia) ? "sdmc:/cias/" : "sdmc:/");
        ImGui::EndGroup();
        char ver[16];
        char file_s[16];
        char inst_s[16];
        titles_format_version(ver, sizeof(ver), cia->version);
        titles_format_size(file_s, sizeof(file_s), cia->file_size);
        titles_format_size(inst_s, sizeof(inst_s), cia->install_size);
        if (!cia->header_ok) {
            ImGui::Text("Not a readable CIA.");
            ImGui::TextDisabled("File %s", file_s);
        } else {
            if (!cia->complete) ImGui::TextColored(ImVec4(0.90f, 0.77f, 0.47f, 1.f), "Incomplete. Left alone.");
            ImGui::Text("v%s    %s", ver, titles_kind_name(cia->kind));
            ImGui::Text("File %s", file_s);
            if (cia->install_size) ImGui::Text("Install %s", inst_s);
            ImGui::TextDisabled("%s", cia->media == MEDIATYPE_SD ? "SD card" : "NAND");
            if (cia->title_id) ImGui::SameLine();
            if (cia->title_id) ImGui::TextDisabled("%016llX", (unsigned long long)cia->title_id);
        }
    }
    if (status && status[0]) ImGui::TextColored(ImVec4(0.90f, 0.77f, 0.47f, 1.f), "%s", status);
    draw_prompts("A select  X all  SELECT titles  START install  START+SELECT exit");
    ImGui::End();
}

static void draw_install_list(CiaList *cias, int *cursor, char *status, size_t status_n) {
    ui_screen(GFX_BOTTOM);
    panel("cias");
    int n = cias->items ? (int)cias->count : 0;
    ImGui::Text("CIAs");
    ImGui::SameLine();
    ImGui::TextDisabled("%d", n);
    u64 selected_bytes = 0;
    draw_selection(count_cias(cias, &selected_bytes), selected_bytes);
    scroll_to("cias", *cursor);
    ImGui::BeginChild("crows", ImVec2(0, 0), false);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.f, 0.f));
    if (n <= 0) ImGui::Text("No CIAs found.");
    ImGuiListClipper clipper;
    clipper.Begin(n, 48.f);
    while (clipper.Step()) {
        for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; row++) {
            CiaRec *cia = &cias->items[row];
            char size[16];
            char sub[80];
            titles_format_size(size, sizeof(size), cia->file_size);
            if (!cia->header_ok) snprintf(sub, sizeof(sub), "bad file");
            else if (!cia->complete) snprintf(sub, sizeof(sub), "incomplete");
            else {
                char ver[16];
                titles_format_version(ver, sizeof(ver), cia->version);
                snprintf(sub, sizeof(sub), "%s  v%s", cia->publisher[0] ? cia->publisher : "-", ver);
            }
            char id[16];
            snprintf(id, sizeof(id), "c%d", row);
            void *tex = cia->icon ? ui_image(cia->icon, cia->icon_w > 0 ? cia->icon_w : 48, false) : NULL;
            if (list_row(id, row == *cursor, cia->selected, tex, cia_label(cia), sub, size)) {
                *cursor = row;
                if (cia->installable) cia->selected = !cia->selected;
                else if (status && status_n) snprintf(status, status_n, "Incomplete CIA.");
            }
        }
    }
    ImGui::PopStyleVar();
    ImGui::EndChild();
    ImGui::End();
}

static void draw_install_confirm(u32 count, u64 bytes, int *action) {
    ui_screen(GFX_BOTTOM);
    panel("iconfirm");
    char size[16];
    titles_format_size(size, sizeof(size), bytes);
    if (count == 1) ImGui::Text("Install 1 CIA?");
    else ImGui::Text("Install %lu CIAs?", (unsigned long)count);
    ImGui::Text("%s", size);
    if (ImGui::Button("Install", ImVec2(120, 28))) *action = 1;
    ImGui::SameLine();
    if (ImGui::Button("Cancel", ImVec2(120, 28))) *action = 2;
    ImGui::End();
}

static bool g_quit;

static bool on_cia_pump(const CiaRec *cia, u32 index, u32 total, u64 wrote, void *user) {
    (void)user;
    if (!aptMainLoop()) {
        g_quit = true;
        return false;
    }
    hidScanInput();
    u32 held = hidKeysHeld();
    if ((held & KEY_START) && (held & KEY_SELECT)) {
        g_quit = true;
        return false;
    }
    if (hidKeysDown() & KEY_B) return false;

    static u64 last_draw = ~(u64)0;
    static u32 last_index = 0xFFFFFFFFu;
    if (index != last_index) {
        last_draw = ~(u64)0;
        last_index = index;
    }
    if (last_draw != ~(u64)0 && wrote != cia->file_size && wrote > last_draw &&
        wrote - last_draw < 256ull * 1024ull) {
        return true;
    }
    last_draw = wrote;

    ui_screen(GFX_TOP);
    panel("ipump");
    ImGui::Text("Installing %lu / %lu", (unsigned long)(index + 1), (unsigned long)total);
    ImGui::TextWrapped("%s", cia->name);
    char done[16];
    char all[16];
    titles_format_size(done, sizeof(done), wrote);
    titles_format_size(all, sizeof(all), cia->file_size);
    ImGui::Text("%s / %s", done, all);
    ImGui::TextDisabled("B cancel");
    ImGui::End();

    ui_screen(GFX_BOTTOM);
    panel("ibar");
    float frac = cia->file_size ? (float)((double)wrote / (double)cia->file_size) : 0.f;
    if (frac < 0) frac = 0;
    if (frac > 1) frac = 1;
    ImGui::ProgressBar(frac, ImVec2(-1, 22));
    ImGui::End();
    ui_present();
    return true;
}

static void install_selected(CiaList *cias, TitleList *titles, Result *load_rc, char *status, size_t status_n) {
    u64 bytes = 0;
    u32 total = count_cias(cias, &bytes);
    if (total == 0) {
        snprintf(status, status_n, "Nothing to install.");
        return;
    }

    u32 index = 0;
    u32 ok = 0;
    Result rc = 0;
    bool cancelled = false;
    for (u32 i = 0; i < cias->count; i++) {
        CiaRec *cia = &cias->items[i];
        if (!cia->selected || !cia->installable) continue;
        Result one = cias_install_one(cia, index, total, on_cia_pump, NULL);
        if (g_quit || one == CIA_ERR_CANCEL) {
            cancelled = true;
            rc = one;
            break;
        }
        if (R_FAILED(one)) rc = one;
        else {
            ok++;
            cia->selected = false;
        }
        index++;
    }

    if (!g_quit) reload(titles, load_rc);
    if (g_quit) snprintf(status, status_n, "Stopped.");
    else if (cancelled) snprintf(status, status_n, "Cancelled. Installed %lu.", (unsigned long)ok);
    else if (R_FAILED(rc)) snprintf(status, status_n, "Installed %lu. Error 0x%08lX", (unsigned long)ok, (unsigned long)rc);
    else snprintf(status, status_n, "Installed %lu.", (unsigned long)ok);
}

static void enter_install(CiaList *cias, int *cursor, int *scroll) {
    ui_screen(GFX_BOTTOM);
    panel("reading");
    ImGui::Text("Reading CIAs...");
    ImGui::End();
    ui_present();
    ui_drop_images();
    cias_load(cias);
    *cursor = 0;
    *scroll = 0;
}

int main(int argc, char **argv) {
    (void)argc;
    (void)argv;

    ui_init();
    bgm_start();

    Result am_rc = amInit();
    Result fs_rc = fsInit();
    g_ptmu = R_SUCCEEDED(ptmuInit());
    Result services = R_FAILED(am_rc) ? am_rc : fs_rc;

    TitleList list;
    memset(&list, 0, sizeof(list));
    CiaList cias;
    memset(&cias, 0, sizeof(cias));
    Result load_rc = 0;
    if (R_SUCCEEDED(services)) reload(&list, &load_rc);

    Mode mode = MODE_LIST;
    int nds = 0;
    int cursor = 0;
    int scroll = 0;
    int icursor = 0;
    int iscroll = 0;
    int down_timer = 0;
    int up_timer = 0;
    bool include_related = true;
    bool delete_tickets = false;
    char status[96];
    status[0] = '\0';

    u32 tick = 0;

    while (aptMainLoop()) {
        bgm_poll();
        hidScanInput();
        u32 down = hidKeysDown();
        u32 held = hidKeysHeld();
        int vcount = build_visible(&list, nds, g_visible);
        if (cursor >= vcount) cursor = vcount > 0 ? vcount - 1 : 0;
        if (cursor < scroll) scroll = cursor;
        if (cursor >= scroll + LIST_ROWS) scroll = cursor - LIST_ROWS + 1;
        if (scroll < 0) scroll = 0;

        if ((held & KEY_START) && (held & KEY_SELECT)) break;

        if (mode == MODE_RESULT) {
            if (g_quit) break;
            if (down & (KEY_A | KEY_B | KEY_START)) {
                status[0] = '\0';
                mode = MODE_LIST;
            }
        } else if (mode == MODE_CONFIRM) {
            if (down & KEY_B) mode = MODE_LIST;
            if (down & KEY_Y) include_related = !include_related;
            if (down & KEY_X) delete_tickets = !delete_tickets;
            if (down & KEY_A) {
                u64 bytes = 0;
                u32 marked = count_selected(&list, &bytes);
                if (marked == 0) {
                    snprintf(status, sizeof(status), "Nothing selected.");
                    mode = MODE_LIST;
                } else {
                    bool tickets = delete_tickets;
                    Result rc = delete_selected(&list, include_related, tickets);
                    reload(&list, &load_rc);
                    cursor = 0;
                    scroll = 0;
                    if (R_FAILED(rc)) snprintf(status, sizeof(status), "Finished with errors 0x%08lX", (unsigned long)rc);
                    else snprintf(status, sizeof(status), "Removed %lu titles.", (unsigned long)marked);
                    mode = MODE_RESULT;
                }
            }
        } else if (mode == MODE_INSTALL_CONFIRM) {
            if (down & KEY_B) mode = MODE_INSTALL;
            if (down & KEY_A) {
                install_selected(&cias, &list, &load_rc, status, sizeof(status));
                if (g_quit) break;
                mode = MODE_RESULT;
            }
        } else if (mode == MODE_INSTALL && R_SUCCEEDED(services)) {
            int n = cias.items ? (int)cias.count : 0;
            if (icursor >= n) icursor = n > 0 ? n - 1 : 0;
            if (icursor < iscroll) iscroll = icursor;
            if (icursor >= iscroll + CIA_ROWS) iscroll = icursor - CIA_ROWS + 1;
            if (iscroll < 0) iscroll = 0;
            if (down & KEY_B) {
                mode = MODE_LIST;
            } else {
                if (repeat_key(down, held, KEY_DDOWN, &down_timer) || (down & KEY_CPAD_DOWN)) {
                    if (n > 0 && icursor < n - 1) icursor++;
                } else if (repeat_key(down, held, KEY_DUP, &up_timer) || (down & KEY_CPAD_UP)) {
                    if (icursor > 0) icursor--;
                }
                if (down & KEY_A && n > 0) {
                    CiaRec *cia = &cias.items[icursor];
                    if (cia->installable) cia->selected = !cia->selected;
                    else snprintf(status, sizeof(status), "Incomplete CIA.");
                }
                if (down & KEY_X) toggle_cias(&cias);
                if (down & KEY_SELECT) {
                    status[0] = '\0';
                    mode = MODE_LIST;
                }
                if (down & KEY_START) {
                    u64 bytes = 0;
                    if (count_cias(&cias, &bytes) > 0) {
                        status[0] = '\0';
                        mode = MODE_INSTALL_CONFIRM;
                    } else snprintf(status, sizeof(status), "Select a Cia.");
                }
            }
        } else if (mode == MODE_LIST && R_SUCCEEDED(services)) {
            if (repeat_key(down, held, KEY_DDOWN, &down_timer) || (down & KEY_CPAD_DOWN)) {
                if (vcount > 0 && cursor < vcount - 1) cursor++;
            } else if (repeat_key(down, held, KEY_DUP, &up_timer) || (down & KEY_CPAD_UP)) {
                if (cursor > 0) cursor--;
            }
            if (down & KEY_A && vcount > 0) {
                TitleRec *title = &list.items[g_visible[cursor]];
                if (title->deletable) title->selected = !title->selected;
            }
            if (down & KEY_X) toggle_visible(&list, g_visible, vcount);
            if (down & (KEY_L | KEY_R)) {
                nds = !nds;
                cursor = 0;
                scroll = 0;
                status[0] = '\0';
            }
            if (down & KEY_SELECT) {
                enter_install(&cias, &icursor, &iscroll);
                status[0] = '\0';
                mode = MODE_INSTALL;
            }
            if (down & KEY_START) {
                u64 bytes = 0;
                if (count_selected(&list, &bytes) > 0) {
                    status[0] = '\0';
                    mode = MODE_CONFIRM;
                } else snprintf(status, sizeof(status), "Select a title first.");
            }
        }

        vcount = build_visible(&list, nds, g_visible);
        if (cursor >= vcount) cursor = vcount > 0 ? vcount - 1 : 0;

        int action = 0;
        if (mode == MODE_INSTALL || mode == MODE_INSTALL_CONFIRM) {
            draw_install_top(&cias, icursor, status);
        } else {
            draw_top(&list, g_visible, vcount, cursor, nds, services, load_rc, status, tick);
        }

        if (mode == MODE_CONFIRM) {
            u32 count = titles_collect(&list, g_ids, TITLE_CAP, include_related);
            u64 bytes = 0;
            for (u32 i = 0; i < count; i++) {
                for (u32 j = 0; j < list.count; j++) {
                    if (list.items[j].id == g_ids[i]) bytes += list.items[j].size;
                }
            }
            draw_confirm(count, bytes, &include_related, &delete_tickets, &action);
        } else if (mode == MODE_INSTALL_CONFIRM) {
            u64 bytes = 0;
            draw_install_confirm(count_cias(&cias, &bytes), bytes, &action);
        } else if (mode == MODE_RESULT) {
            draw_result(status, &action);
        } else if (mode == MODE_INSTALL) {
            int n = cias.items ? (int)cias.count : 0;
            if (icursor >= n) icursor = n > 0 ? n - 1 : 0;
            draw_install_list(&cias, &icursor, status, sizeof(status));
        } else {
            draw_list(&list, g_visible, vcount, &cursor, &nds, tick);
        }

        ui_present();
        if (action == 2 && mode == MODE_CONFIRM) mode = MODE_LIST;
        if (action == 2 && mode == MODE_INSTALL_CONFIRM) mode = MODE_INSTALL;
        if (action == 2 && mode == MODE_RESULT) {
            status[0] = '\0';
            mode = MODE_LIST;
        }
        if (action == 1 && mode == MODE_CONFIRM) {
            u64 bytes = 0;
            u32 marked = count_selected(&list, &bytes);
            if (marked == 0) {
                snprintf(status, sizeof(status), "Nothing selected.");
                mode = MODE_LIST;
            } else {
                bool tickets = delete_tickets;
                Result rc = delete_selected(&list, include_related, tickets);
                reload(&list, &load_rc);
                cursor = 0;
                scroll = 0;
                if (R_FAILED(rc)) snprintf(status, sizeof(status), "Finished with errors 0x%08lX", (unsigned long)rc);
                else snprintf(status, sizeof(status), "Removed %lu titles.", (unsigned long)marked);
                mode = MODE_RESULT;
            }
        }
        if (action == 1 && mode == MODE_INSTALL_CONFIRM) {
            install_selected(&cias, &list, &load_rc, status, sizeof(status));
            if (g_quit) break;
            mode = MODE_RESULT;
        }
        tick++;
    }

    ui_drop_images();
    titles_free(&list);
    cias_free(&cias);
    bgm_stop();
    if (R_SUCCEEDED(fs_rc)) fsExit();
    if (R_SUCCEEDED(am_rc)) amExit();
    if (g_ptmu) ptmuExit();
    ui_exit();
    return 0;
}
