#pragma once

#define CINDER_VERSION "3.13"
#define CINDER_REVISION 43
