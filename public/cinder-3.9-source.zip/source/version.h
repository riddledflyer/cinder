#pragma once

#define CINDER_VERSION "3.9"
#define CINDER_REVISION 39
