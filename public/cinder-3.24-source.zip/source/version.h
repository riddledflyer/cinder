#pragma once

#define CINDER_VERSION "3.24"
#define CINDER_REVISION 54
