#!/usr/bin/env python3
"""Build a banner the HOME Menu can play: stereo looping audio, every region slot filled."""
import struct
import subprocess
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
PNG = HERE / "banner.png"
WAV = HERE / "banner.wav"
CWAV = HERE / "banner.bcwav"
OUT = HERE / "banner.bin"

# The HOME Menu ignores a banner clip that is 3 seconds or longer and keeps
# playing the placeholder. This file is stereo 16-bit PCM, strictly shorter.
if not WAV.exists() or WAV.stat().st_size < 64:
    raise SystemExit(f"missing banner audio: {WAV}")

with wave.open(str(WAV), "rb") as handle:
    if handle.getnchannels() != 2 or handle.getsampwidth() != 2:
        raise SystemExit("banner wav must be stereo 16-bit")
    frames = handle.getnframes()
    rate = handle.getframerate()
seconds = frames / rate
if seconds >= 3.0:
    raise SystemExit(f"banner audio is {seconds:.3f}s, must be under 3 seconds")

subprocess.check_call(
    [
        "bannertool", "makecwav",
        "-i", str(WAV),
        "-o", str(CWAV),
        "-l", "true",
        "-s", "0",
        "-f", str(frames - 1),
    ]
)

# -i is the common graphic. The rest are the per-region slots. A zero slot
# makes some menus dereference the missing graphic instead of falling back.
slots = [
    "-eei", "-efi", "-egi", "-eii", "-esi", "-edi", "-epi",
    "-eri", "-jji", "-uei", "-ufi", "-usi", "-upi",
]
cmd = ["bannertool", "makebanner", "-i", str(PNG)]
for flag in slots:
    cmd.extend([flag, str(PNG)])
cmd.extend(["-ca", str(CWAV), "-o", str(OUT)])
subprocess.check_call(cmd)

blob = OUT.read_bytes()
cgfx = [struct.unpack_from("<I", blob, 8 + i * 4)[0] for i in range(14)]
cwav_off = struct.unpack_from("<I", blob, 0x84)[0]
info = blob[cwav_off + 0x40 :]
channels = struct.unpack_from("<I", info, 0x1C)[0]
loop = info[9]
if any(off == 0 for off in cgfx):
    raise SystemExit("banner is missing a region graphic")
if channels != 2 or loop != 1:
    raise SystemExit(f"banner audio is channels={channels} loop={loop}, want stereo looping")
print(f"banner {len(blob)} bytes, {channels}ch loop={loop}, {seconds:.2f}s at {rate} Hz")
