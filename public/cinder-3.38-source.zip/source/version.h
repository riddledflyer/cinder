#pragma once

#define CINDER_VERSION "3.38"
#define CINDER_REVISION 68
