#pragma once

#define CINDER_VERSION "3.46"
#define CINDER_REVISION 76
