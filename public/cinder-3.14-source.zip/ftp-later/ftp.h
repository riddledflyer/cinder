#pragma once

#ifdef FTP_HOST_TEST
#include "ftp_host.h"
#else
#include <3ds.h>
#endif
#include <stdbool.h>

#define FTP_PORT 5000
#define FTP_LOG 10

typedef struct {
    bool running;
    bool client;
    char ip[40];
    char status[96];
    char cwd[160];
    char peer[40];
    char xfer_name[64];
    u64 xfer_done;
    u64 xfer_total;
    int log_count;
    char log[FTP_LOG][48];
} FtpInfo;

Result ftp_start(void);

void ftp_stop(void);
void ftp_poll(void);
void ftp_info(FtpInfo *out);

bool ftp_sd_changed(void);
