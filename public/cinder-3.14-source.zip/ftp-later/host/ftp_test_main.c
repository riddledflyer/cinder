#include "ftp.h"

#include <stdio.h>
#include <unistd.h>

int main(void) {
    if (ftp_start() != 0) {
        fprintf(stderr, "start failed\n");
        return 1;
    }
    fprintf(stderr, "ready\n");
    fflush(stderr);
    for (;;) {
        ftp_poll();
        usleep(1000);
    }
}
