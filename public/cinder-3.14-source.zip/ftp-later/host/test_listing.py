#!/usr/bin/env python3
"""Client session that must list, change folders, download, and upload."""

import os
import re
import shutil
import socket
import subprocess
import sys
import time
from ftplib import FTP, error_perm
from io import BytesIO
from pathlib import Path

ROOT = Path("/tmp/cinder-ftp-root")
PORT = 5000
BIN = Path("/tmp/cinder-ftp-host")
UNIX_LIST = re.compile(
    r"^([d\-])[r\-][w\-][x\-][r\-][w\-][x\-][r\-][w\-][x\-]\s+\d+\s+\S+\s+\S+\s+(\d+)\s+\w{3}\s+\d{1,2}\s+(?:\d{2}:\d{2}|\d{4})\s+(.+)$"
)


def wait_ready(proc, timeout=5):
    deadline = time.time() + timeout
    buf = b""
    while time.time() < deadline:
        chunk = proc.stderr.read(1)
        if not chunk:
            if proc.poll() is not None:
                raise SystemExit("server exited before ready")
            time.sleep(0.01)
            continue
        buf += chunk
        if b"ready\n" in buf:
            return
    raise SystemExit("server did not become ready")


def parse_list(lines):
    files, dirs = {}, []
    for line in lines:
        m = UNIX_LIST.match(line)
        if not m:
            raise SystemExit("unreadable listing line: " + line)
        if m.group(1) == "d":
            dirs.append(m.group(3))
        else:
            files[m.group(3)] = int(m.group(2))
    return files, dirs


class Raw:
    """Plain FTP client that can connect the data socket after the 150 reply."""

    def __init__(self):
        self.ctrl = socket.create_connection(("127.0.0.1", PORT), 5)
        self.ctrl.settimeout(5)
        banner = self.reply()
        if not banner.startswith("220"):
            raise SystemExit("bad banner " + banner)

    def reply(self):
        buf = b""
        while True:
            chunk = self.ctrl.recv(1)
            if not chunk:
                raise SystemExit("control connection closed: " + buf.decode("utf-8", "replace"))
            buf += chunk
            if buf.endswith(b"\n") and len(buf) >= 4 and buf[3:4] != b"-":
                text = buf.decode("utf-8", "replace")
                if text[3] == " ":
                    return text

    def cmd(self, line):
        self.ctrl.sendall((line + "\r\n").encode())
        return self.reply()

    def login(self):
        if not self.cmd("USER anonymous").startswith("331"):
            raise SystemExit("USER failed")
        if not self.cmd("PASS guest").startswith("230"):
            raise SystemExit("PASS failed")
        self.cmd("TYPE I")

    def pasv_port(self):
        line = self.cmd("PASV")
        if not line.startswith("227"):
            raise SystemExit("PASV failed: " + line.strip())
        nums = line[line.find("(") + 1:line.find(")")].split(",")
        return int(nums[4]) * 256 + int(nums[5])

    def close(self):
        try:
            self.cmd("QUIT")
        except Exception:
            pass
        self.ctrl.close()


def transfer_after_150(command, payload=None):
    raw = Raw()
    raw.login()
    port = raw.pasv_port()
    raw.ctrl.sendall((command + "\r\n").encode())
    opened = raw.reply()
    if not opened.startswith("150"):
        raise SystemExit(command + " did not open: " + opened.strip())
    data = socket.create_connection(("127.0.0.1", port), 5)
    data.settimeout(5)
    if payload is None:
        blob = b""
        while True:
            chunk = data.recv(65536)
            if not chunk:
                break
            blob += chunk
        data.close()
        done = raw.reply()
        raw.close()
        if not done.startswith("226"):
            raise SystemExit(command + " did not finish: " + done.strip())
        return blob
    data.sendall(payload)
    data.close()
    done = raw.reply()
    raw.close()
    if not done.startswith("226"):
        raise SystemExit(command + " did not finish: " + done.strip())
    return None


def active_retr(command):
    raw = Raw()
    raw.login()
    gate = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    gate.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    gate.bind(("127.0.0.1", 0))
    gate.listen(1)
    gate.settimeout(5)
    host, port = gate.getsockname()
    parts = [int(x) for x in host.split(".")] + [port // 256, port % 256]
    reply = raw.cmd("PORT " + ",".join(str(n) for n in parts))
    if not reply.startswith("200"):
        raise SystemExit("PORT failed: " + reply.strip())
    raw.ctrl.sendall((command + "\r\n").encode())
    opened = raw.reply()
    if not opened.startswith("150"):
        raise SystemExit("active " + command + " failed: " + opened.strip())
    conn, _ = gate.accept()
    blob = b""
    while True:
        chunk = conn.recv(65536)
        if not chunk:
            break
        blob += chunk
    conn.close()
    gate.close()
    done = raw.reply()
    raw.close()
    if not done.startswith("226"):
        raise SystemExit("active transfer did not finish: " + done.strip())
    return blob


def main():
    if ROOT.exists():
        shutil.rmtree(ROOT)
    (ROOT / "cias").mkdir(parents=True)
    (ROOT / "User Folder").mkdir()
    (ROOT / "hello.txt").write_bytes(b"hello-from-sd")
    (ROOT / "My Game.cia").write_bytes(b"cia-bytes")
    big = bytes((i * 17 + 3) & 0xFF for i in range(200_000))
    (ROOT / "cias" / "game.cia").write_bytes(big)
    (ROOT / "User Folder" / "note.txt").write_text("inside")

    proc = subprocess.Popen(
        [str(BIN)],
        env={**os.environ, "FTP_ROOT": str(ROOT)},
        stderr=subprocess.PIPE,
    )
    try:
        wait_ready(proc)
        ftp = FTP()
        ftp.connect("127.0.0.1", PORT, timeout=5)
        ftp.login("anonymous", "guest")
        ftp.sendcmd("SYST")
        ftp.sendcmd("FEAT")
        ftp.sendcmd("OPTS UTF8 ON")
        try:
            ftp.sendcmd("AUTH TLS")
            raise SystemExit("AUTH TLS should be refused")
        except error_perm:
            pass
        ftp.voidcmd("TYPE I")
        if ftp.pwd() != "/":
            raise SystemExit("expected root, got " + ftp.pwd())

        lines = []
        ftp.retrlines("LIST -a", lines.append)
        files, dirs = parse_list(lines)
        print("root:", sorted(dirs), sorted(files))
        if "cias" not in dirs or "User Folder" not in dirs:
            raise SystemExit("root directories missing")
        if files.get("hello.txt") != 13 or files.get("My Game.cia") != 9:
            raise SystemExit("root files missing or sized wrong: " + repr(files))
        if ftp.size("hello.txt") != 13:
            raise SystemExit("SIZE failed")

        got = []
        ftp.retrbinary("RETR hello.txt", got.append)
        if b"".join(got) != b"hello-from-sd":
            raise SystemExit("download of hello.txt mismatch")
        got = []
        ftp.retrbinary("RETR My Game.cia", got.append)
        if b"".join(got) != b"cia-bytes":
            raise SystemExit("download of spaced name mismatch")

        ftp.cwd("cias")
        if ftp.pwd() != "/cias":
            raise SystemExit("CWD cias landed on " + ftp.pwd())
        sub = []
        ftp.retrlines("LIST", sub.append)
        sub_files, sub_dirs = parse_list(sub)
        print("cias:", sorted(sub_dirs), sorted(sub_files))
        if sub_files.get("game.cia") != len(big):
            raise SystemExit("listing inside cias/ failed: " + repr(sub_files))
        if "hello.txt" in sub_files:
            raise SystemExit("parent files leaked into cias/")

        ftp.cwd("..")
        ftp.cwd("User Folder")
        nested = []
        ftp.retrlines("LIST", nested.append)
        nested_files, _ = parse_list(nested)
        if "note.txt" not in nested_files:
            raise SystemExit("listing User Folder failed")
        ftp.cwd("/")

        payload = bytes((i * 13) & 0xFF for i in range(50_000))
        ftp.storbinary("STOR /cias/dropped.cia", BytesIO(payload))
        if (ROOT / "cias" / "dropped.cia").read_bytes() != payload:
            raise SystemExit("upload did not land in cias/")
        ftp.cwd("cias")
        again = []
        ftp.retrlines("LIST", again.append)
        again_files, _ = parse_list(again)
        if again_files.get("dropped.cia") != len(payload):
            raise SystemExit("uploaded file is not listed")
        back = []
        ftp.retrbinary("RETR dropped.cia", back.append)
        if b"".join(back) != payload:
            raise SystemExit("re-download of upload mismatch")
        ftp.cwd("/")

        ftp.storbinary("STOR hello.txt", BytesIO(b"replaced"))
        if (ROOT / "hello.txt").read_bytes() != b"replaced":
            raise SystemExit("overwrite failed")
        ftp.storbinary("STOR empty.dat", BytesIO(b""))
        if (ROOT / "empty.dat").read_bytes() != b"":
            raise SystemExit("empty upload failed")

        rest = ftp.sendcmd("REST 1000")
        if not rest.startswith("350"):
            raise SystemExit("REST failed: " + rest)
        piece = []
        ftp.retrbinary("RETR /cias/game.cia", piece.append)
        if b"".join(piece) != big[1000:]:
            raise SystemExit("restart download mismatch")

        root_again = []
        ftp.retrlines("LIST", root_again.append)
        root_files, root_dirs = parse_list(root_again)
        if "cias" not in root_dirs or "hello.txt" not in root_files:
            raise SystemExit("root listing broke after transfers")
        ftp.quit()
        print("session list/cwd/retr/stor ok")

        listed = transfer_after_150("LIST /cias")
        if b"game.cia" not in listed or b"dropped.cia" not in listed:
            raise SystemExit("late data connection failed listing a folder:\n" + listed.decode())
        downloaded = transfer_after_150("RETR /cias/game.cia")
        if downloaded != big:
            raise SystemExit("late data connection download mismatch")
        late = bytes(range(256)) * 40
        transfer_after_150("STOR /User Folder/late.bin", late)
        if (ROOT / "User Folder" / "late.bin").read_bytes() != late:
            raise SystemExit("late data connection upload mismatch")
        print("late data connection ok")

        if active_retr("RETR /hello.txt") != b"replaced":
            raise SystemExit("active mode download mismatch")
        print("active mode ok")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
    print("thorough ftp test passed")


if __name__ == "__main__":
    try:
        main()
    except error_perm as exc:
        print("FTP error:", exc, file=sys.stderr)
        sys.exit(1)
