#include "ftp.h"
#include "version.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

#define SOC_ALIGN 0x1000
#define SOC_SIZE 0x100000
#define CHUNK (16 * 1024)

enum {
    XFER_NONE = 0,
    XFER_WAIT,
    XFER_LIST,
    XFER_RETR,
    XFER_STOR
};

static struct {
    bool running;
    bool ac_up;
    bool sd_changed;
    u32 *soc;
    int listen_fd;
    int ctrl;
    int data_fd;
    int data_listen;
    int xfer;
    int xfer_kind;
    int mlsd;
    bool sent_150;
    u16 data_port;
    u64 rest;
    u64 xfer_done;
    u64 xfer_total;
    u64 xfer_deadline;
    struct sockaddr_in active;
    bool use_active;
    Handle file;
    Handle dirh;
    u64 file_off;
    char cwd[160];
    char ip[40];
    char status[96];
    char peer[40];
    char xfer_name[64];
    char sd_path[320];
    char inbuf[768];
    int inlen;
    char outq[1024];
    int outlen;
    u8 chunk[CHUNK];
    int chunk_len;
    int chunk_pos;
    int log_count;
    char log[FTP_LOG][48];
} g;

static bool g_ready;

static void ensure_init(void) {
    if (g_ready) return;
    memset(&g, 0, sizeof(g));
    g.listen_fd = -1;
    g.ctrl = -1;
    g.data_fd = -1;
    g.data_listen = -1;
    g.data_port = 5001;
    snprintf(g.cwd, sizeof(g.cwd), "/");
    snprintf(g.ip, sizeof(g.ip), "0.0.0.0");
    g_ready = true;
}

static void note(const char *text) {
    if (!text || !text[0]) return;
    if (g.log_count >= FTP_LOG) {
        memmove(g.log[0], g.log[1], (FTP_LOG - 1) * sizeof(g.log[0]));
        g.log_count = FTP_LOG - 1;
    }
    snprintf(g.log[g.log_count], sizeof(g.log[0]), "%s", text);
    g.log_count++;
}

static void set_status(const char *text) {
    snprintf(g.status, sizeof(g.status), "%s", text ? text : "");
}

static void set_nb(int fd) {
    int on = 1;
    ioctl(fd, FIONBIO, &on);
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) flags = 0;
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

static void nodelay(int fd) {
    int on = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));
}

static void close_fd(int *fd) {
    if (fd && *fd >= 0) {
        close(*fd);
        *fd = -1;
    }
}

static bool flush_out(void) {
    while (g.outlen > 0 && g.ctrl >= 0) {
        int n = send(g.ctrl, g.outq, g.outlen, 0);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) return false;
            return false;
        }
        if (n == 0) return false;
        if (n < g.outlen) memmove(g.outq, g.outq + n, (size_t)(g.outlen - n));
        g.outlen -= n;
    }
    return true;
}

static void reply_raw(const char *text) {
    if (!text || g.ctrl < 0) return;
    size_t n = strlen(text);
    if (n > sizeof(g.outq)) n = sizeof(g.outq);
    if (g.outlen + (int)n > (int)sizeof(g.outq)) flush_out();
    if (g.outlen + (int)n > (int)sizeof(g.outq)) return;
    memcpy(g.outq + g.outlen, text, n);
    g.outlen += (int)n;
    flush_out();
}

static void reply(int code, const char *text) {
    char line[384];
    snprintf(line, sizeof(line), "%d %s\r\n", code, text ? text : "");
    reply_raw(line);
}

static void clear_data(void) {
    if (g.file) {
        FSFILE_Close(g.file);
        g.file = 0;
    }
    if (g.dirh) {
        FSDIR_Close(g.dirh);
        g.dirh = 0;
    }
    close_fd(&g.data_fd);
    close_fd(&g.data_listen);
    g.xfer = XFER_NONE;
    g.sent_150 = false;
    g.chunk_len = 0;
    g.chunk_pos = 0;
    g.xfer_name[0] = '\0';
    g.use_active = false;
}

static bool normalize_path(char *out, size_t out_n, const char *cwd, const char *arg) {
    char raw[480];
    if (!arg || arg[0] == '\0') {
        snprintf(raw, sizeof(raw), "%s", cwd && cwd[0] ? cwd : "/");
    } else if (arg[0] == '/') {
        snprintf(raw, sizeof(raw), "%s", arg);
    } else if (!cwd || strcmp(cwd, "/") == 0) {
        snprintf(raw, sizeof(raw), "/%s", arg);
    } else {
        snprintf(raw, sizeof(raw), "%s/%s", cwd, arg);
    }
    for (char *p = raw; *p; p++) {
        if (*p == '\\') *p = '/';
    }

    char built[480];
    size_t len = 0;
    built[0] = '\0';
    const char *p = raw;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        const char *start = p;
        while (*p && *p != '/') p++;
        size_t n = (size_t)(p - start);
        if (n == 1 && start[0] == '.') continue;
        if (n == 2 && start[0] == '.' && start[1] == '.') {
            if (len > 1) {
                char *slash = strrchr(built, '/');
                if (!slash || slash == built) {
                    built[1] = '\0';
                    len = 1;
                } else {
                    *slash = '\0';
                    len = strlen(built);
                }
            }
            continue;
        }
        if (n == 0 || n > 120) return false;
        if (len == 0) {
            if (1 + n >= sizeof(built)) return false;
            built[0] = '/';
            memcpy(built + 1, start, n);
            len = 1 + n;
            built[len] = '\0';
        } else if (len == 1) {
            if (len + n >= sizeof(built)) return false;
            memcpy(built + 1, start, n);
            len = 1 + n;
            built[len] = '\0';
        } else {
            if (len + 1 + n >= sizeof(built)) return false;
            built[len++] = '/';
            memcpy(built + len, start, n);
            len += n;
            built[len] = '\0';
        }
    }
    if (len == 0) {
        built[0] = '/';
        built[1] = '\0';
        len = 1;
    }
    if (len + 1 > out_n) return false;
    memcpy(out, built, len + 1);
    return true;
}

static FS_Archive g_arch;
static bool g_arch_open;
static u16 g_pasv_port;
#define FTP_U16 400
static u16 g_u16[FTP_U16];
static u16 g_u16b[FTP_U16];
#define FILE_RW (FS_OPEN_READ | FS_OPEN_WRITE)

static bool fs_ready(void) {
    if (g_arch_open) return true;
    if (R_FAILED(FSUSER_OpenArchive(&g_arch, ARCHIVE_SDMC, fsMakePath(PATH_EMPTY, "")))) return false;
    g_arch_open = true;
    return true;
}

static void fs_shutdown(void) {
    if (g.file) {
        FSFILE_Close(g.file);
        g.file = 0;
    }
    if (g.dirh) {
        FSDIR_Close(g.dirh);
        g.dirh = 0;
    }
    if (g_arch_open) {
        FSUSER_CloseArchive(g_arch);
        g_arch_open = false;
    }
}

static bool to_utf16(u16 *out, size_t cap, const char *utf8) {
    size_t j = 0;
    const unsigned char *s = (const unsigned char *)utf8;
    if (!utf8 || utf8[0] != '/' || cap == 0) return false;
    while (*s) {
        u32 cp;
        if (*s < 0x80) {
            cp = *s++;
        } else if ((*s & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
            cp = ((u32)(s[0] & 0x1F) << 6) | (u32)(s[1] & 0x3F);
            s += 2;
        } else if ((*s & 0xF0) == 0xE0 && (s[1] & 0xC0) == 0x80 && (s[2] & 0xC0) == 0x80) {
            cp = ((u32)(s[0] & 0x0F) << 12) | ((u32)(s[1] & 0x3F) << 6) | (u32)(s[2] & 0x3F);
            s += 3;
        } else {
            cp = '?';
            s++;
        }
        if (cp == 0 || cp > 0xFFFF) cp = '?';
        if (j + 1 >= cap) return false;
        out[j++] = (u16)cp;
    }
    out[j] = 0;
    return true;
}

static bool open_dir(Handle *out, const char *ftp) {
    char slashed[260];
    size_t n;
    const char *first = ftp;
    if (!ftp || ftp[0] != '/' || !out) return false;
    n = strlen(ftp);
    if (n > 1 && ftp[n - 1] != '/' && n + 2 < sizeof(slashed)) {
        memcpy(slashed, ftp, n);
        slashed[n] = '/';
        slashed[n + 1] = '\0';
        first = slashed;
    }
    if (R_SUCCEEDED(FSUSER_OpenDirectory(out, g_arch, fsMakePath(PATH_ASCII, first)))) return true;
    if (first != ftp) return R_SUCCEEDED(FSUSER_OpenDirectory(out, g_arch, fsMakePath(PATH_ASCII, ftp)));
    return false;
}

static void ftp_utf16_to_utf8(char *out, size_t n, const u16 *in) {
    size_t o = 0;
    if (n == 0) return;
    for (size_t i = 0; in && in[i] && o + 1 < n; i++) {
        u32 cp = in[i];
        if (cp < 0x20 || cp == 0x7F) cp = '?';
        if (cp < 0x80) {
            out[o++] = (char)cp;
        } else if (cp < 0x800 && o + 2 < n) {
            out[o++] = (char)(0xC0 | (cp >> 6));
            out[o++] = (char)(0x80 | (cp & 0x3F));
        } else if (o + 3 < n) {
            out[o++] = (char)(0xE0 | (cp >> 12));
            out[o++] = (char)(0x80 | ((cp >> 6) & 0x3F));
            out[o++] = (char)(0x80 | (cp & 0x3F));
        }
    }
    out[o] = '\0';
}

static bool is_dir_path(const char *ftp) {
    Handle h = 0;
    if (!ftp || ftp[0] != '/') return false;
    if (strcmp(ftp, "/") == 0) return true;
    if (!fs_ready()) return false;
    if (!fs_ready() || !open_dir(&h, ftp)) return false;
    FSDIR_Close(h);
    return true;
}

static bool is_file_path(const char *ftp, u64 *size_out) {
    Handle h = 0;
    u64 sz = 0;
    if (!ftp || ftp[0] != '/' || strcmp(ftp, "/") == 0) return false;
    if (!fs_ready() || !to_utf16(g_u16, FTP_U16, ftp)) return false;
    if (R_FAILED(FSUSER_OpenFile(&h, g_arch, fsMakePath(PATH_UTF16, g_u16), FS_OPEN_READ, 0))) return false;
    FSFILE_GetSize(h, &sz);
    FSFILE_Close(h);
    if (size_out) *size_out = sz;
    return true;
}

static void base_name(const char *path, char *out, size_t n) {
    const char *slash = strrchr(path, '/');
    const char *name = slash ? slash + 1 : path;
    if (!name[0]) name = "/";
    snprintf(out, n, "%s", name);
}

static void drop_client(const char *why) {
    clear_data();
    close_fd(&g.ctrl);
    g.inlen = 0;
    g.outlen = 0;
    g.rest = 0;
    g.peer[0] = '\0';
    if (why) note(why);
    if (g.running) set_status("Listening");
}

static bool send_blocked(int fd, const u8 *data, int len, int *sent) {
    while (*sent < len) {
        int n = send(fd, data + *sent, len - *sent, 0);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) return true;
            return false;
        }
        if (n == 0) return false;
        *sent += n;
    }
    return true;
}

static bool open_pasv(void) {
    close_fd(&g.data_listen);
    close_fd(&g.data_fd);
    g.use_active = false;
    g_pasv_port = 0;
    for (int attempt = 0; attempt < 32; attempt++) {
        int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
        struct sockaddr_in addr;
        struct sockaddr_in bound;
        socklen_t bl = sizeof(bound);
        int on = 1;
        u16 port = attempt == 0 ? 0 : g.data_port;
        if (fd < 0) return false;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == 0 && listen(fd, 1) == 0 &&
            getsockname(fd, (struct sockaddr *)&bound, &bl) == 0 && ntohs(bound.sin_port) != 0) {
            set_nb(fd);
            g.data_listen = fd;
            g_pasv_port = ntohs(bound.sin_port);
            g.data_port = (u16)(g_pasv_port + 1);
            if (g.data_port < 5001 || g.data_port > 64000) g.data_port = 5001;
            return true;
        }
        close(fd);
        g.data_port++;
        if (g.data_port < 5001 || g.data_port > 64000) g.data_port = 5001;
    }
    return false;
}

static bool pasv_ip(unsigned *ip_host) {
    struct sockaddr_in sa;
    socklen_t sl = sizeof(sa);
    if (g.ctrl >= 0 && getsockname(g.ctrl, (struct sockaddr *)&sa, &sl) == 0 && sa.sin_addr.s_addr != 0) {
        *ip_host = ntohl(sa.sin_addr.s_addr);
        inet_ntop(AF_INET, &sa.sin_addr, g.ip, sizeof(g.ip));
        return true;
    }
    if (g.ip[0] && strcmp(g.ip, "0.0.0.0") != 0) {
        u32 addr = (u32)inet_addr(g.ip);
        if (addr != 0xFFFFFFFFu && addr != 0) {
            *ip_host = ntohl(addr);
            return true;
        }
    }
    return false;
}

static void reply_pasv(void) {
    unsigned ip = 0;
    unsigned port = g_pasv_port;
    char line[96];
    if (!pasv_ip(&ip) || port == 0) {
        reply(425, "No network address for passive mode");
        close_fd(&g.data_listen);
        return;
    }
    snprintf(line, sizeof(line), "Entering Passive Mode (%u,%u,%u,%u,%u,%u)",
             (ip >> 24) & 255, (ip >> 16) & 255, (ip >> 8) & 255, ip & 255,
             (port >> 8) & 255, port & 255);
    reply(227, line);
}

static bool accept_data(void) {
    struct pollfd pfd;
    struct sockaddr_in peer;
    socklen_t sl = sizeof(peer);
    int fd;
    int pr;
    if (g.data_fd >= 0) return true;
    if (g.data_listen < 0) return false;
    pfd.fd = g.data_listen;
    pfd.events = POLLIN;
    pfd.revents = 0;
    pr = poll(&pfd, 1, 0);
    if (pr == 0) return false;
    fd = accept(g.data_listen, (struct sockaddr *)&peer, &sl);
    if (fd < 0) return false;
    set_nb(fd);
    nodelay(fd);
    g.data_fd = fd;
    close_fd(&g.data_listen);
    return true;
}

static bool connect_active(void) {
    if (g.data_fd >= 0) return true;
    if (!g.use_active) return false;
    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (fd < 0) return false;
    set_nb(fd);
    nodelay(fd);
    int rc = connect(fd, (struct sockaddr *)&g.active, sizeof(g.active));
    if (rc == 0) {
        g.data_fd = fd;
        return true;
    }
    if (errno == EINPROGRESS || errno == EAGAIN) {
        g.data_fd = fd;
        return false;
    }
    close(fd);
    return false;
}

static bool active_ready(void) {
    if (!g.use_active || g.data_fd < 0) return false;
    struct pollfd pfd;
    pfd.fd = g.data_fd;
    pfd.events = POLLOUT;
    pfd.revents = 0;
    if (poll(&pfd, 1, 0) <= 0) return false;
    int err = 0;
    socklen_t len = sizeof(err);
    if (getsockopt(g.data_fd, SOL_SOCKET, SO_ERROR, &err, &len) < 0 || err != 0) return false;
    return true;
}

static void finish_xfer(bool ok, const char *why) {
    bool announced = g.sent_150;
    clear_data();
    if (!announced) {
        reply(425, why && why[0] ? why : "Can't open data connection");
        return;
    }
    if (ok) {
        reply(226, "Transfer complete");
        set_status("Listening");
    } else {
        reply(426, why && why[0] ? why : "Transfer aborted");
        set_status(why && why[0] ? why : "Transfer aborted");
    }
}

static void quote_path(const char *path, char *out, size_t n) {
    size_t j = 0;
    if (n == 0) return;
    for (size_t i = 0; path[i] && j + 2 < n; i++) {
        if (path[i] == '"') out[j++] = '"';
        out[j++] = path[i];
    }
    out[j] = '\0';
}

static bool list_one(void) {
    if (!g.dirh) return false;
    for (;;) {
        FS_DirectoryEntry ent;
        u32 read = 0;
        char name[200];
        bool dir;
        if (R_FAILED(FSDIR_Read(g.dirh, &read, 1, &ent)) || read != 1) return false;
        ftp_utf16_to_utf8(name, sizeof(name), ent.name);
        if (!name[0] || strcmp(name, ".") == 0 || strcmp(name, "..") == 0) continue;
        dir = (ent.attributes & FS_ATTRIBUTE_DIRECTORY) != 0;
        if (g.mlsd == 2) {
            g.chunk_len = snprintf((char *)g.chunk, CHUNK, "%s\r\n", name);
        } else if (g.mlsd == 1) {
            if (dir) g.chunk_len = snprintf((char *)g.chunk, CHUNK, "type=dir;modify=19800101000000; %s\r\n", name);
            else g.chunk_len = snprintf((char *)g.chunk, CHUNK, "type=file;size=%llu;modify=19800101000000; %s\r\n",
                                        (unsigned long long)ent.fileSize, name);
        } else {
            g.chunk_len = snprintf((char *)g.chunk, CHUNK, "%s 1 user user %llu Jan  1  1980 %s\r\n",
                                   dir ? "drwxrwxrwx" : "-rw-rw-rw-",
                                   dir ? 0ull : (unsigned long long)ent.fileSize, name);
        }
        if (g.chunk_len < 0) g.chunk_len = 0;
        if (g.chunk_len >= CHUNK) g.chunk_len = CHUNK - 1;
        g.chunk_pos = 0;
        return g.chunk_len > 0;
    }
}

static bool start_list(const char *ftp_path, int kind) {
    Handle h = 0;
    const char *label = "LIST";
    if (!fs_ready()) {
        reply(550, "SD card is not mounted");
        return false;
    }
    if (!ftp_path || ftp_path[0] != '/') {
        reply(550, "Bad path");
        return false;
    }
    if (!open_dir(&h, ftp_path)) {
        reply(550, "Not a directory");
        return false;
    }
    g.dirh = h;
    g.xfer_kind = XFER_LIST;
    g.mlsd = kind;
    g.xfer = XFER_WAIT;
    g.xfer_done = 0;
    g.xfer_total = 0;
    g.xfer_deadline = osGetTime() + 20000;
    if (kind == 1) label = "MLSD";
    else if (kind == 2) label = "NLST";
    snprintf(g.xfer_name, sizeof(g.xfer_name), "%s", label);
    reply(150, "Opening data connection");
    g.sent_150 = true;
    return true;
}

static bool start_retr(const char *arg) {
    char ftp[240];
    u64 sz = 0;
    Handle h = 0;
    if (!arg || !arg[0] || !normalize_path(ftp, sizeof(ftp), g.cwd, arg)) {
        reply(550, "Not a file");
        return false;
    }
    if (!is_file_path(ftp, &sz)) {
        reply(550, "Not a file");
        return false;
    }
    if (g.rest > sz) {
        reply(554, "Restart past end");
        g.rest = 0;
        return false;
    }
    if (!to_utf16(g_u16, FTP_U16, ftp) ||
        R_FAILED(FSUSER_OpenFile(&h, g_arch, fsMakePath(PATH_UTF16, g_u16), FS_OPEN_READ, 0))) {
        reply(550, "Can't open");
        return false;
    }
    g.file = h;
    g.file_off = g.rest;
    g.xfer_kind = XFER_RETR;
    g.xfer = XFER_WAIT;
    g.xfer_done = g.rest;
    g.xfer_total = sz;
    g.rest = 0;
    g.xfer_deadline = osGetTime() + 20000;
    base_name(ftp, g.xfer_name, sizeof(g.xfer_name));
    snprintf(g.sd_path, sizeof(g.sd_path), "%s", ftp);
    reply(150, "Opening data connection");
    g.sent_150 = true;
    set_status("Sending");
    return true;
}

static bool ends_cia(const char *name) {
    size_t n = strlen(name);
    if (n < 4) return false;
    const char *e = name + n - 4;
    return (e[0] == '.' ) &&
           (e[1] == 'c' || e[1] == 'C') &&
           (e[2] == 'i' || e[2] == 'I') &&
           (e[3] == 'a' || e[3] == 'A');
}

static bool start_stor(const char *arg, bool append) {
    char ftp[240];
    char parent[240];
    char *slash;
    Handle h = 0;
    Result rc;
    if (!arg || !arg[0] || !normalize_path(ftp, sizeof(ftp), g.cwd, arg)) {
        reply(550, "Bad path");
        return false;
    }
    if (strcmp(ftp, "/") == 0 || is_dir_path(ftp)) {
        reply(550, "Not a file");
        return false;
    }
    snprintf(parent, sizeof(parent), "%s", ftp);
    slash = strrchr(parent, '/');
    if (!slash) {
        reply(550, "Bad path");
        return false;
    }
    if (slash == parent) parent[1] = '\0';
    else *slash = '\0';
    if (!is_dir_path(parent)) {
        reply(550, "No such directory");
        return false;
    }
    if (!fs_ready() || !to_utf16(g_u16, FTP_U16, ftp)) {
        reply(550, "Bad path");
        return false;
    }
    if (append || g.rest) {
        rc = FSUSER_OpenFile(&h, g_arch, fsMakePath(PATH_UTF16, g_u16), FILE_RW, 0);
        if (R_FAILED(rc)) {
            rc = FSUSER_CreateFile(g_arch, fsMakePath(PATH_UTF16, g_u16), 0, 0);
            if (R_SUCCEEDED(rc)) rc = FSUSER_OpenFile(&h, g_arch, fsMakePath(PATH_UTF16, g_u16), FILE_RW, 0);
        }
        if (R_SUCCEEDED(rc) && append) {
            u64 sz = 0;
            FSFILE_GetSize(h, &sz);
            g.file_off = sz;
        } else {
            g.file_off = g.rest;
        }
    } else {
        FSUSER_DeleteFile(g_arch, fsMakePath(PATH_UTF16, g_u16));
        rc = FSUSER_CreateFile(g_arch, fsMakePath(PATH_UTF16, g_u16), 0, 0);
        if (R_FAILED(rc)) {
            reply(550, "Can't create");
            g.rest = 0;
            return false;
        }
        rc = FSUSER_OpenFile(&h, g_arch, fsMakePath(PATH_UTF16, g_u16), FILE_RW, 0);
        g.file_off = 0;
    }
    if (R_FAILED(rc) || !h) {
        if (h) FSFILE_Close(h);
        reply(550, "Can't create");
        g.rest = 0;
        return false;
    }
    g.file = h;
    g.xfer_kind = XFER_STOR;
    g.xfer = XFER_WAIT;
    g.xfer_done = append ? 0 : g.rest;
    g.xfer_total = 0;
    g.rest = 0;
    g.xfer_deadline = osGetTime() + 20000;
    base_name(ftp, g.xfer_name, sizeof(g.xfer_name));
    snprintf(g.sd_path, sizeof(g.sd_path), "%s", ftp);
    reply(150, "Opening data connection");
    g.sent_150 = true;
    set_status("Receiving");
    return true;
}

static void mark_changed(const char *name) {
    g.sd_changed = true;
    if (name && ends_cia(name)) note("CIA stored");
}

static void handle(char *line) {
    char verb[16];
    char arg[320];
    size_t i = 0;
    while (line[i] == ' ') i++;
    size_t v = 0;
    while (line[i] && line[i] != ' ') {
        char c = line[i++];
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
        if (v + 1 < sizeof(verb)) verb[v++] = c;
    }
    verb[v] = '\0';
    while (line[i] == ' ') i++;
    snprintf(arg, sizeof(arg), "%s", line + i);
    size_t an = strlen(arg);
    while (an && (arg[an - 1] == ' ' || arg[an - 1] == '\r')) arg[--an] = '\0';

    if (verb[0] == '\0') return;
    if (strcmp(verb, "PASS") != 0) {
        char shown[48];
        if (arg[0] && strcmp(verb, "PASS") != 0) snprintf(shown, sizeof(shown), "%s %s", verb, arg);
        else snprintf(shown, sizeof(shown), "%s", verb);
        note(shown);
    } else {
        note("PASS");
    }

    if (strcmp(verb, "QUIT") == 0) {
        reply(221, "Bye");
        drop_client("Client left");
        return;
    }
    if (strcmp(verb, "USER") == 0) {
        reply(331, "Any password");
        return;
    }
    if (strcmp(verb, "PASS") == 0) {
        reply(230, "Logged in");
        return;
    }
    if (strcmp(verb, "SYST") == 0) {
        reply(215, "UNIX Type: L8");
        return;
    }
    if (strcmp(verb, "FEAT") == 0) {
        reply_raw("211-Features\r\n SIZE\r\n REST STREAM\r\n UTF8\r\n EPSV\r\n211 End\r\n");
        return;
    }
    if (strcmp(verb, "HOST") == 0) {
        reply(220, "Plain FTP");
        return;
    }
    if (strcmp(verb, "NOOP") == 0 || strcmp(verb, "CLNT") == 0 || strcmp(verb, "OPTS") == 0) {
        reply(200, "OK");
        return;
    }
    if (strcmp(verb, "TYPE") == 0 || strcmp(verb, "MODE") == 0 || strcmp(verb, "STRU") == 0) {
        reply(200, "OK");
        return;
    }
    if (strcmp(verb, "AUTH") == 0 || strcmp(verb, "PBSZ") == 0 || strcmp(verb, "CCC") == 0) {
        reply(502, "Plain FTP only");
        return;
    }
    if (strcmp(verb, "PROT") == 0) {
        if ((arg[0] == 'C' || arg[0] == 'c') && arg[1] == '\0') reply(200, "Protection clear");
        else reply(502, "Plain FTP only");
        return;
    }
    if (strcmp(verb, "PWD") == 0 || strcmp(verb, "XPWD") == 0) {
        char q[200];
        char body[280];
        quote_path(g.cwd, q, sizeof(q));
        snprintf(body, sizeof(body), "\"%s\" is current directory", q);
        reply(257, body);
        return;
    }
    if (strcmp(verb, "CWD") == 0 || strcmp(verb, "XCWD") == 0) {
        char next[160];
        const char *use = arg[0] ? arg : "/";
        if (!normalize_path(next, sizeof(next), g.cwd, use) || !is_dir_path(next)) {
            reply(550, "No such directory");
            return;
        }
        snprintf(g.cwd, sizeof(g.cwd), "%s", next);
        reply(250, "Directory changed");
        return;
    }
    if (strcmp(verb, "CDUP") == 0) {
        char next[160];
        if (!normalize_path(next, sizeof(next), g.cwd, "..")) {
            reply(550, "No such directory");
            return;
        }
        snprintf(g.cwd, sizeof(g.cwd), "%s", next);
        reply(250, "Directory changed");
        return;
    }
    if (strcmp(verb, "MKD") == 0 || strcmp(verb, "XMKD") == 0) {
        char next[240];
        char q[200];
        char body[280];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !fs_ready()) {
            reply(550, "Bad path");
            return;
        }
        if (R_FAILED(FSUSER_CreateDirectory(g_arch, fsMakePath(PATH_ASCII, next), 0))) {
            reply(550, "Can't create");
            return;
        }
        g.sd_changed = true;
        quote_path(next, q, sizeof(q));
        snprintf(body, sizeof(body), "\"%s\" created", q);
        reply(257, body);
        return;
    }
    if (strcmp(verb, "RMD") == 0 || strcmp(verb, "XRMD") == 0) {
        char next[240];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || strcmp(next, "/") == 0 || !fs_ready()) {
            reply(550, "Bad path");
            return;
        }
        if (R_FAILED(FSUSER_DeleteDirectory(g_arch, fsMakePath(PATH_ASCII, next)))) {
            reply(550, "Can't remove");
            return;
        }
        g.sd_changed = true;
        reply(250, "Removed");
        return;
    }
    if (strcmp(verb, "DELE") == 0) {
        char next[240];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !fs_ready() || !to_utf16(g_u16, FTP_U16, next)) {
            reply(550, "Bad path");
            return;
        }
        if (R_FAILED(FSUSER_DeleteFile(g_arch, fsMakePath(PATH_UTF16, g_u16)))) {
            reply(550, "Can't delete");
            return;
        }
        mark_changed(next);
        reply(250, "Deleted");
        return;
    }
    if (strcmp(verb, "RNFR") == 0) {
        char next[240];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg)) {
            reply(550, "Bad path");
            return;
        }
        if (!is_file_path(next, NULL) && !is_dir_path(next)) {
            g.sd_path[0] = '\0';
            reply(550, "Not found");
            return;
        }
        snprintf(g.sd_path, sizeof(g.sd_path), "%s", next);
        reply(350, "Ready for destination");
        return;
    }
    if (strcmp(verb, "RNTO") == 0) {
        char next[240];
        bool dir;
        if (!g.sd_path[0] || !arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !fs_ready()) {
            reply(503, "No rename from");
            return;
        }
        dir = is_dir_path(g.sd_path);
        if (dir) {
            if (R_FAILED(FSUSER_RenameDirectory(g_arch, fsMakePath(PATH_ASCII, g.sd_path), g_arch, fsMakePath(PATH_ASCII, next)))) {
                reply(550, "Can't rename");
                return;
            }
        } else if (!to_utf16(g_u16, FTP_U16, g.sd_path) || !to_utf16(g_u16b, FTP_U16, next) ||
                   R_FAILED(FSUSER_RenameFile(g_arch, fsMakePath(PATH_UTF16, g_u16), g_arch, fsMakePath(PATH_UTF16, g_u16b)))) {
            reply(550, "Can't rename");
            return;
        }
        g.sd_path[0] = '\0';
        mark_changed(next);
        reply(250, "Renamed");
        return;
    }
    if (strcmp(verb, "SIZE") == 0) {
        char next[240];
        u64 sz = 0;
        char body[40];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !is_file_path(next, &sz)) {
            reply(550, "Not a file");
            return;
        }
        snprintf(body, sizeof(body), "%llu", (unsigned long long)sz);
        reply(213, body);
        return;
    }
    if (strcmp(verb, "REST") == 0) {
        char *end = NULL;
        unsigned long long off = strtoull(arg, &end, 10);
        if (!arg[0] || (end && *end)) {
            reply(501, "Bad restart");
            return;
        }
        g.rest = (u64)off;
        char body[48];
        snprintf(body, sizeof(body), "Restart at %llu", off);
        reply(350, body);
        return;
    }
    if (strcmp(verb, "PASV") == 0) {
        if (!open_pasv()) {
            reply(425, "Can't open passive port");
            return;
        }
        reply_pasv();
        return;
    }
    if (strcmp(verb, "EPSV") == 0) {
        char body[80];
        if (!open_pasv()) {
            reply(425, "Can't open passive port");
            return;
        }
        snprintf(body, sizeof(body), "Entering Extended Passive Mode (|||%u|)", (unsigned)g_pasv_port);
        reply(229, body);
        return;
    }
    if (strcmp(verb, "PORT") == 0) {
        unsigned h1, h2, h3, h4, p1, p2;
        if (sscanf(arg, "%u,%u,%u,%u,%u,%u", &h1, &h2, &h3, &h4, &p1, &p2) != 6 ||
            h1 > 255 || h2 > 255 || h3 > 255 || h4 > 255 || p1 > 255 || p2 > 255) {
            reply(501, "Bad PORT");
            return;
        }
        close_fd(&g.data_listen);
        close_fd(&g.data_fd);
        memset(&g.active, 0, sizeof(g.active));
        g.active.sin_family = AF_INET;
        g.active.sin_port = htons((u16)(p1 * 256u + p2));
        char ipbuf[32];
        snprintf(ipbuf, sizeof(ipbuf), "%u.%u.%u.%u", h1, h2, h3, h4);
        if (inet_pton(AF_INET, ipbuf, &g.active.sin_addr) != 1) {
            reply(501, "Bad PORT");
            return;
        }
        g.use_active = true;
        reply(200, "PORT ok");
        return;
    }
    if (strcmp(verb, "EPRT") == 0) {
        reply(502, "Use PORT");
        return;
    }
    if (strcmp(verb, "LIST") == 0 || strcmp(verb, "NLST") == 0 || strcmp(verb, "MLSD") == 0) {
        const char *p = arg;
        char resolved[240];
        const char *use = g.cwd;
        int kind = 0;
        if (g.xfer != XFER_NONE) {
            reply(425, "Transfer already open");
            return;
        }
        if (!g.use_active && g.data_listen < 0 && g.data_fd < 0) {
            reply(425, "Use PASV or PORT first");
            return;
        }
        while (*p == ' ') p++;
        while (*p == '-') {
            while (*p && *p != ' ') p++;
            while (*p == ' ') p++;
        }
        if (*p) {
            if (!normalize_path(resolved, sizeof(resolved), g.cwd, p)) {
                reply(550, "Bad path");
                return;
            }
            use = resolved;
        }
        if (strcmp(verb, "MLSD") == 0) kind = 1;
        else if (strcmp(verb, "NLST") == 0) kind = 2;
        start_list(use, kind);
        return;
    }
    if (strcmp(verb, "RETR") == 0) {
        if (!g.use_active && g.data_listen < 0 && g.data_fd < 0) {
            reply(425, "Use PASV or PORT first");
            return;
        }
        start_retr(arg);
        return;
    }
    if (strcmp(verb, "STOR") == 0 || strcmp(verb, "APPE") == 0) {
        if (!g.use_active && g.data_listen < 0 && g.data_fd < 0) {
            reply(425, "Use PASV or PORT first");
            return;
        }
        start_stor(arg, strcmp(verb, "APPE") == 0);
        return;
    }
    if (strcmp(verb, "ABOR") == 0) {
        if (g.xfer != XFER_NONE) finish_xfer(false, "Aborted");
        else reply(226, "No transfer");
        return;
    }
    if (strcmp(verb, "ALLO") == 0) {
        reply(202, "OK");
        return;
    }
    reply(502, "Not implemented");
}

static void take_lines(void) {
    int start = 0;
    for (int i = 0; i < g.inlen; i++) {
        if (g.inbuf[i] != '\n') continue;
        g.inbuf[i] = '\0';
        if (i > start && g.inbuf[i - 1] == '\r') g.inbuf[i - 1] = '\0';
        if (g.xfer != XFER_NONE && strcmp(g.inbuf + start, "ABOR") == 0) {
            finish_xfer(false, "Aborted");
        } else if (g.xfer != XFER_NONE) {

            g.inbuf[i] = '\n';
            if (start > 0) {
                memmove(g.inbuf, g.inbuf + start, (size_t)(g.inlen - start));
                g.inlen -= start;
            }
            return;
        } else {
            handle(g.inbuf + start);
            if (g.ctrl < 0) {
                g.inlen = 0;
                return;
            }
        }
        start = i + 1;
    }
    if (start > 0) {
        memmove(g.inbuf, g.inbuf + start, (size_t)(g.inlen - start));
        g.inlen -= start;
    }
    if (g.inlen >= (int)sizeof(g.inbuf) - 1) g.inlen = 0;
}

static void read_ctrl(void) {
    if (g.ctrl < 0 || g.outlen > 0) return;
    if (g.inlen >= (int)sizeof(g.inbuf) - 1) return;
    int n = recv(g.ctrl, g.inbuf + g.inlen, sizeof(g.inbuf) - 1 - g.inlen, 0);
    if (n < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return;
        drop_client("Client lost");
        return;
    }
    if (n == 0) {
        drop_client("Client left");
        return;
    }
    g.inlen += n;
    g.inbuf[g.inlen] = '\0';
    take_lines();
}

static void pump(void) {
    if (g.xfer == XFER_NONE) return;
    if (g.xfer == XFER_WAIT) {
        bool ready = false;
        if (g.data_listen >= 0) ready = accept_data();
        else if (g.use_active) {
            if (g.data_fd < 0 && !connect_active() && g.data_fd < 0) {
                finish_xfer(false, "Can't open data connection");
                return;
            }
            ready = g.data_fd >= 0 && active_ready();
        } else if (g.data_fd >= 0) {
            ready = true;
        }
        if (!ready) {
            if (osGetTime() > g.xfer_deadline) finish_xfer(false, "Data connection timed out");
            return;
        }
        g.xfer = g.xfer_kind;
        if (g.xfer == XFER_LIST && !g.dirh && g.chunk_len <= 0) {
            finish_xfer(true, NULL);
            return;
        }
    }

    int budget = 256 * 1024;
    if (g.xfer == XFER_LIST) {
        while (budget > 0 && g.data_fd >= 0) {
            if (g.chunk_pos < g.chunk_len) {
                int before = g.chunk_pos;
                if (!send_blocked(g.data_fd, g.chunk + g.chunk_pos, g.chunk_len - g.chunk_pos, &g.chunk_pos)) {
                    finish_xfer(false, "Send failed");
                    return;
                }
                budget -= g.chunk_pos - before;
                if (g.chunk_pos < g.chunk_len) return;
                g.chunk_len = 0;
                g.chunk_pos = 0;
            }
            if (!list_one()) {
                finish_xfer(true, NULL);
                return;
            }
        }
        return;
    }
    if (g.xfer == XFER_RETR && g.file && g.data_fd >= 0) {
        while (budget > 0) {
            if (g.chunk_pos >= g.chunk_len) {
                u32 want = CHUNK;
                u32 got = 0;
                Result rc;
                if (g.xfer_total > g.file_off) {
                    u64 left = g.xfer_total - g.file_off;
                    if (left < want) want = (u32)left;
                } else {
                    want = 0;
                }
                if (want == 0) {
                    finish_xfer(true, NULL);
                    return;
                }
                rc = FSFILE_Read(g.file, &got, g.file_off, g.chunk, want);
                if (R_FAILED(rc) || got == 0) {
                    finish_xfer(false, "Read failed");
                    return;
                }
                g.file_off += got;
                g.chunk_len = (int)got;
                g.chunk_pos = 0;
            }
            int before = g.chunk_pos;
            if (!send_blocked(g.data_fd, g.chunk + g.chunk_pos, g.chunk_len - g.chunk_pos, &g.chunk_pos)) {
                finish_xfer(false, "Send failed");
                return;
            }
            int moved = g.chunk_pos - before;
            g.xfer_done += (u64)moved;
            budget -= moved;
            if (g.chunk_pos < g.chunk_len) return;
        }
        return;
    }
    if (g.xfer == XFER_STOR && g.file && g.data_fd >= 0) {
        while (budget > 0) {
            int n = recv(g.data_fd, g.chunk, CHUNK, 0);
            u32 put = 0;
            u64 end;
            u64 cur = 0;
            if (n < 0) {
                if (errno == EAGAIN || errno == EWOULDBLOCK) return;
                finish_xfer(false, "Receive failed");
                return;
            }
            if (n == 0) {
                char name[64];
                snprintf(name, sizeof(name), "%s", g.xfer_name);
                FSFILE_Flush(g.file);
                mark_changed(name);
                finish_xfer(true, NULL);
                return;
            }
            end = g.file_off + (u64)n;
            FSFILE_GetSize(g.file, &cur);
            if (end > cur && R_FAILED(FSFILE_SetSize(g.file, end))) {
                finish_xfer(false, "SD write failed");
                return;
            }
            if (R_FAILED(FSFILE_Write(g.file, &put, g.file_off, g.chunk, (u32)n, FS_WRITE_FLUSH)) ||
                put != (u32)n) {
                finish_xfer(false, "SD write failed");
                return;
            }
            g.file_off += put;
            g.xfer_done += put;
            budget -= n;
        }
    }
}

static void accept_client(void) {
    if (g.listen_fd < 0 || g.ctrl >= 0) return;
    struct sockaddr_in peer;
    socklen_t sl = sizeof(peer);
    int fd = accept(g.listen_fd, (struct sockaddr *)&peer, &sl);
    if (fd < 0) return;
    set_nb(fd);
    nodelay(fd);
    g.ctrl = fd;
    inet_ntop(AF_INET, &peer.sin_addr, g.peer, sizeof(g.peer));
    {
        struct sockaddr_in local;
        socklen_t ll = sizeof(local);
        if (getsockname(fd, (struct sockaddr *)&local, &ll) == 0 && local.sin_addr.s_addr != 0) {
            inet_ntop(AF_INET, &local.sin_addr, g.ip, sizeof(g.ip));
        }
    }
    snprintf(g.cwd, sizeof(g.cwd), "/");
    g.rest = 0;
    note("Client connected");
    set_status("Client connected");
    char hello[64];
    snprintf(hello, sizeof(hello), "Cinder %s plain FTP", CINDER_VERSION);
    reply(220, hello);
}

static void refresh_ip(void) {
    struct in_addr ip, mask, bcast;
    memset(&ip, 0, sizeof(ip));
    if (g.soc && SOCU_GetIPInfo(&ip, &mask, &bcast) == 0) inet_ntop(AF_INET, &ip, g.ip, sizeof(g.ip));
    if (!g.ip[0]) snprintf(g.ip, sizeof(g.ip), "0.0.0.0");
    if (strcmp(g.ip, "0.0.0.0") == 0) {
        if (g.ctrl < 0) set_status("Wi-Fi is off. Press Y to retry.");
    } else if (g.ctrl < 0 && g.xfer == XFER_NONE) {
        set_status("Listening");
    }
}

Result ftp_start(void) {
    ensure_init();
    if (g.running) {
        refresh_ip();
        return 0;
    }

    if (!g.ac_up) {
        if (R_SUCCEEDED(acInit())) g.ac_up = true;
    }

    if (!g.soc) {
        g.soc = (u32 *)memalign(SOC_ALIGN, SOC_SIZE);
        if (!g.soc) {
            set_status("Out of memory");
            return -1;
        }
        Result rc = socInit(g.soc, SOC_SIZE);
        if (R_FAILED(rc)) {
            free(g.soc);
            g.soc = NULL;
            set_status("Wi-Fi is off");
            return rc;
        }
    }

    refresh_ip();

    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (fd < 0) {
        set_status("Can't open a socket");
        return -1;
    }
    int on = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(FTP_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(fd, 1) != 0) {
        close(fd);
        set_status("Port 5000 is in use");
        return -1;
    }
    set_nb(fd);
    g.listen_fd = fd;
    g.running = true;
    refresh_ip();
    if (strcmp(g.status, "Wi-Fi is off. Press Y to retry.") != 0 && g.status[0] == '\0') set_status("Listening");
    if (strcmp(g.ip, "0.0.0.0") != 0 && strcmp(g.status, "Wi-Fi is off. Press Y to retry.") != 0) set_status("Listening");
    note("Listening");
    return 0;
}

void ftp_stop(void) {
    ensure_init();
    clear_data();
    fs_shutdown();
    close_fd(&g.ctrl);
    close_fd(&g.listen_fd);
    g.inlen = 0;
    g.outlen = 0;
    g.running = false;
    g.peer[0] = '\0';
    g.rest = 0;
    if (g.soc) {
        socExit();
        free(g.soc);
        g.soc = NULL;
    }
    set_status("Stopped");
}

void ftp_poll(void) {
    ensure_init();
    if (!g.running) return;
    if (!flush_out() && g.ctrl < 0) return;
    accept_client();
    read_ctrl();
    pump();
    if (g.xfer == XFER_NONE && g.ctrl >= 0 && g.inlen > 0) take_lines();
}

void ftp_info(FtpInfo *out) {
    ensure_init();
    memset(out, 0, sizeof(*out));
    out->running = g.running;
    out->client = g.ctrl >= 0;
    snprintf(out->ip, sizeof(out->ip), "%s", g.ip);
    snprintf(out->status, sizeof(out->status), "%s", g.status);
    snprintf(out->cwd, sizeof(out->cwd), "%s", g.cwd[0] ? g.cwd : "/");
    snprintf(out->peer, sizeof(out->peer), "%s", g.peer);
    snprintf(out->xfer_name, sizeof(out->xfer_name), "%s", g.xfer == XFER_NONE ? "" : g.xfer_name);
    out->xfer_done = g.xfer == XFER_NONE ? 0 : g.xfer_done;
    out->xfer_total = g.xfer == XFER_NONE ? 0 : g.xfer_total;
    out->log_count = g.log_count;
    for (int i = 0; i < g.log_count; i++) snprintf(out->log[i], sizeof(out->log[i]), "%s", g.log[i]);
}

bool ftp_sd_changed(void) {
    ensure_init();
    bool was = g.sd_changed;
    g.sd_changed = false;
    return was;
}
