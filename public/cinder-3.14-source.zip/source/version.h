#pragma once

#define CINDER_VERSION "3.14"
#define CINDER_REVISION 44
