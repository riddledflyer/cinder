#pragma once

#define CINDER_VERSION "3.23"
#define CINDER_REVISION 53
