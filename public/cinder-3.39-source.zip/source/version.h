#pragma once

#define CINDER_VERSION "3.39"
#define CINDER_REVISION 69
