#pragma once

#define CINDER_VERSION "3.45"
#define CINDER_REVISION 75
