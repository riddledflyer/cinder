#pragma once

#define CINDER_VERSION "3.49"
#define CINDER_REVISION 79
