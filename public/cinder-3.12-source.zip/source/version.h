#pragma once

#define CINDER_VERSION "3.12"
#define CINDER_REVISION 42
