#include "bgm.h"

#include <3ds.h>
#include <string.h>

/* data/bgm.bin, converted from the bundled track.
 * Mono signed PCM8 at 16 kHz. A 16-bit or stereo copy does not fit in the
 * 4 MB linear heap next to the framebuffers on an old 3DS. */
extern const u8 bgm_bin[];
extern const u8 bgm_bin_end[];

#define BGM_RATE 16000

static u8 *g_pcm;
static bool g_on;
static int g_chn = -1;

static int owned_channel(void) {
    /* csndPlaySound refuses any channel not in this mask, and it returns 1.
     * That is not a negative Result, so it looks like success and nothing plays.
     * Channel 0 is usually absent from the mask. */
    for (int ch = 0; ch < 32; ch++) {
        if (csndChannels & BIT(ch)) return ch;
    }
    return -1;
}

void bgm_start(void) {
    u32 size = (u32)(bgm_bin_end - bgm_bin);
    if (size < 64) return;
    if (R_FAILED(csndInit())) return;

    int ch = owned_channel();
    if (ch < 0) {
        csndExit();
        return;
    }

    u32 step = 1;
    u32 freeb = linearSpaceFree();
    while (step < 8 && size / step + 0x2000 > freeb) step++;
    u32 play = size / step;
    play &= ~3u;
    if (play < 64) {
        csndExit();
        return;
    }

    g_pcm = linearAlloc(play);
    if (!g_pcm) {
        csndExit();
        return;
    }
    if (step == 1) {
        memcpy(g_pcm, bgm_bin, play);
    } else {
        for (u32 i = 0; i < play; i++) g_pcm[i] = bgm_bin[i * step];
    }
    GSPGPU_FlushDataCache(g_pcm, play);

    u32 rate = BGM_RATE / step;
    Result rc = csndPlaySound(ch, SOUND_FORMAT_8BIT | SOUND_REPEAT, rate, 1.0f, 0.0f, g_pcm, g_pcm, play);
    if (rc != 0) {
        linearFree(g_pcm);
        g_pcm = NULL;
        csndExit();
        return;
    }
    g_chn = ch;
    g_on = true;
}

void bgm_stop(void) {
    if (!g_on && !g_pcm) return;
    if (g_chn >= 0) CSND_SetPlayState(g_chn, 0);
    csndExit();
    if (g_pcm) linearFree(g_pcm);
    g_pcm = NULL;
    g_chn = -1;
    g_on = false;
}
