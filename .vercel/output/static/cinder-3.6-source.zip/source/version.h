#pragma once

#define CINDER_VERSION "3.6"
#define CINDER_REVISION 36
