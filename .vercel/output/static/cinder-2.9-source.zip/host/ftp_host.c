#include "ftp_host.h"

#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define SLOT_N 48

typedef struct {
    int kind;
    DIR *dir;
    FILE *fp;
    char path[768];
} Slot;

static Slot g_slots[SLOT_N];
static char g_root[512];

static Result fail(void) {
    return -1;
}

static int join_path(char *out, size_t n, const char *ftp) {
    int wrote;
    if (!ftp || ftp[0] != '/') return -1;
    if (!g_root[0]) return -1;
    if (strcmp(ftp, "/") == 0) wrote = snprintf(out, n, "%s", g_root);
    else wrote = snprintf(out, n, "%s%s", g_root, ftp);
    return (wrote > 0 && (size_t)wrote < n) ? 0 : -1;
}

static const char *ascii_path(FS_Path path) {
    if (path.type != PATH_ASCII || !path.data) return NULL;
    return (const char *)path.data;
}

static Handle alloc_slot(int kind) {
    for (Handle i = 1; i < SLOT_N; i++) {
        if (g_slots[i].kind == 0) {
            memset(&g_slots[i], 0, sizeof(g_slots[i]));
            g_slots[i].kind = kind;
            return i;
        }
    }
    return 0;
}

static void free_slot(Handle h) {
    if (h == 0 || h >= SLOT_N) return;
    if (g_slots[h].dir) closedir(g_slots[h].dir);
    if (g_slots[h].fp) fclose(g_slots[h].fp);
    memset(&g_slots[h], 0, sizeof(g_slots[h]));
}

FS_Path fsMakePath(FS_PathType type, const void *path) {
    FS_Path out;
    memset(&out, 0, sizeof(out));
    out.type = type;
    out.data = path;
    if (type == PATH_ASCII && path) out.size = (u32)strlen((const char *)path) + 1;
    else if (type == PATH_EMPTY) out.size = 1;
    return out;
}

Result acInit(void) {
    return 0;
}

Result socInit(u32 *buffer, u32 size) {
    (void)buffer;
    (void)size;
    return 0;
}

void socExit(void) {}

Result SOCU_GetIPInfo(struct in_addr *ip, struct in_addr *netmask, struct in_addr *broadcast) {
    if (ip) inet_aton("127.0.0.1", ip);
    if (netmask) inet_aton("255.0.0.0", netmask);
    if (broadcast) inet_aton("127.255.255.255", broadcast);
    return 0;
}

u64 osGetTime(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (u64)ts.tv_sec * 1000ull + (u64)ts.tv_nsec / 1000000ull;
}

Result FSUSER_OpenArchive(FS_Archive *archive, u32 id, FS_Path path) {
    const char *root;
    (void)id;
    (void)path;
    root = getenv("FTP_ROOT");
    if (!root || !root[0]) return fail();
    snprintf(g_root, sizeof(g_root), "%s", root);
    if (g_root[strlen(g_root) - 1] == '/') g_root[strlen(g_root) - 1] = '\0';
    if (archive) *archive = 1;
    return 0;
}

Result FSUSER_CloseArchive(FS_Archive archive) {
    (void)archive;
    return 0;
}

Result FSUSER_OpenDirectory(Handle *out, FS_Archive archive, FS_Path path) {
    char full[768];
    DIR *dir;
    Handle h;
    const char *ftp = ascii_path(path);
    (void)archive;
    if (!out || !ftp || join_path(full, sizeof(full), ftp) != 0) return fail();
    dir = opendir(full);
    if (!dir) return fail();
    h = alloc_slot(1);
    if (!h) {
        closedir(dir);
        return fail();
    }
    g_slots[h].dir = dir;
    snprintf(g_slots[h].path, sizeof(g_slots[h].path), "%s", full);
    *out = h;
    return 0;
}

Result FSDIR_Read(Handle handle, u32 *read, u32 count, FS_DirectoryEntry *ent) {
    struct dirent *de;
    char child[768];
    struct stat st;
    size_t i;
    (void)count;
    if (read) *read = 0;
    if (handle == 0 || handle >= SLOT_N || g_slots[handle].kind != 1 || !ent) return fail();
    de = readdir(g_slots[handle].dir);
    if (!de) return 0;
    memset(ent, 0, sizeof(*ent));
    for (i = 0; de->d_name[i] && i + 1 < 0x106; i++) ent->name[i] = (u16)(unsigned char)de->d_name[i];
    ent->name[i] = 0;
    ent->valid = 1;
    snprintf(child, sizeof(child), "%s/%s", g_slots[handle].path, de->d_name);
    if (stat(child, &st) == 0) {
        if (S_ISDIR(st.st_mode)) ent->attributes = FS_ATTRIBUTE_DIRECTORY;
        ent->fileSize = (u64)st.st_size;
    } else if (de->d_type == DT_DIR) {
        ent->attributes = FS_ATTRIBUTE_DIRECTORY;
    }
    if (read) *read = 1;
    return 0;
}

Result FSDIR_Close(Handle handle) {
    free_slot(handle);
    return 0;
}

Result FSUSER_OpenFile(Handle *out, FS_Archive archive, FS_Path path, u32 flags, u32 attr) {
    char full[768];
    FILE *fp;
    Handle h;
    const char *ftp = ascii_path(path);
    const char *mode = (flags & FS_OPEN_WRITE) ? "r+b" : "rb";
    (void)archive;
    (void)attr;
    if (!out || !ftp || join_path(full, sizeof(full), ftp) != 0) return fail();
    fp = fopen(full, mode);
    if (!fp && (flags & FS_OPEN_WRITE)) fp = fopen(full, "w+b");
    if (!fp) return fail();
    h = alloc_slot(2);
    if (!h) {
        fclose(fp);
        return fail();
    }
    g_slots[h].fp = fp;
    *out = h;
    return 0;
}

Result FSFILE_Close(Handle handle) {
    free_slot(handle);
    return 0;
}

static FILE *file_of(Handle handle) {
    if (handle == 0 || handle >= SLOT_N || g_slots[handle].kind != 2) return NULL;
    return g_slots[handle].fp;
}

Result FSFILE_GetSize(Handle handle, u64 *size) {
    FILE *fp = file_of(handle);
    long cur, end;
    if (!fp || !size) return fail();
    cur = ftell(fp);
    if (fseek(fp, 0, SEEK_END) != 0) return fail();
    end = ftell(fp);
    if (cur >= 0) fseek(fp, cur, SEEK_SET);
    if (end < 0) return fail();
    *size = (u64)end;
    return 0;
}

Result FSFILE_SetSize(Handle handle, u64 size) {
    FILE *fp = file_of(handle);
    if (!fp) return fail();
    if (fflush(fp) != 0) return fail();
    if (ftruncate(fileno(fp), (off_t)size) != 0) return fail();
    return 0;
}

Result FSFILE_Read(Handle handle, u32 *got, u64 offset, void *buf, u32 size) {
    FILE *fp = file_of(handle);
    size_t n;
    if (got) *got = 0;
    if (!fp) return fail();
    if (fseeko(fp, (off_t)offset, SEEK_SET) != 0) return fail();
    n = fread(buf, 1, size, fp);
    if (got) *got = (u32)n;
    return 0;
}

Result FSFILE_Write(Handle handle, u32 *put, u64 offset, const void *buf, u32 size, u32 flags) {
    FILE *fp = file_of(handle);
    size_t n;
    (void)flags;
    if (put) *put = 0;
    if (!fp) return fail();
    if (fseeko(fp, (off_t)offset, SEEK_SET) != 0) return fail();
    n = fwrite(buf, 1, size, fp);
    if (put) *put = (u32)n;
    if (n != size) return fail();
    return 0;
}

Result FSFILE_Flush(Handle handle) {
    FILE *fp = file_of(handle);
    if (!fp) return fail();
    return fflush(fp) == 0 ? 0 : fail();
}

Result FSUSER_CreateFile(FS_Archive archive, FS_Path path, u32 attr, u64 size) {
    char full[768];
    FILE *fp;
    const char *ftp = ascii_path(path);
    (void)archive;
    (void)attr;
    (void)size;
    if (!ftp || join_path(full, sizeof(full), ftp) != 0) return fail();
    fp = fopen(full, "wb");
    if (!fp) return fail();
    fclose(fp);
    return 0;
}

Result FSUSER_DeleteFile(FS_Archive archive, FS_Path path) {
    char full[768];
    const char *ftp = ascii_path(path);
    (void)archive;
    if (!ftp || join_path(full, sizeof(full), ftp) != 0) return fail();
    return unlink(full) == 0 ? 0 : fail();
}

Result FSUSER_CreateDirectory(FS_Archive archive, FS_Path path, u32 attr) {
    char full[768];
    const char *ftp = ascii_path(path);
    (void)archive;
    (void)attr;
    if (!ftp || join_path(full, sizeof(full), ftp) != 0) return fail();
    return mkdir(full, 0777) == 0 ? 0 : fail();
}

Result FSUSER_DeleteDirectory(FS_Archive archive, FS_Path path) {
    char full[768];
    const char *ftp = ascii_path(path);
    (void)archive;
    if (!ftp || join_path(full, sizeof(full), ftp) != 0) return fail();
    return rmdir(full) == 0 ? 0 : fail();
}

Result FSUSER_RenameFile(FS_Archive a, FS_Path src, FS_Archive b, FS_Path dst) {
    char from[768], to[768];
    (void)a;
    (void)b;
    if (!ascii_path(src) || !ascii_path(dst)) return fail();
    if (join_path(from, sizeof(from), ascii_path(src)) != 0) return fail();
    if (join_path(to, sizeof(to), ascii_path(dst)) != 0) return fail();
    return rename(from, to) == 0 ? 0 : fail();
}

Result FSUSER_RenameDirectory(FS_Archive a, FS_Path src, FS_Archive b, FS_Path dst) {
    return FSUSER_RenameFile(a, src, b, dst);
}
