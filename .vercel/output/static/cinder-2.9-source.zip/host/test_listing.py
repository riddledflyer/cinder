#!/usr/bin/env python3
"""Prove a plain FTP client can list, download, and upload before a CIA is shipped."""

import os
import re
import shutil
import socket
import subprocess
import sys
import time
from ftplib import FTP, error_perm
from pathlib import Path

ROOT = Path("/tmp/cinder-ftp-root")
PORT = 5000
BIN = Path("/tmp/cinder-ftp-host")
UNIX_LIST = re.compile(
    r"^([d\-])[r\-][w\-][x\-][r\-][w\-][x\-][r\-][w\-][x\-]\s+\d+\s+\S+\s+\S+\s+\d+\s+\w{3}\s+\d{1,2}\s+(?:\d{2}:\d{2}|\d{4})\s+(.+)$"
)


def wait_ready(proc, timeout=5):
    deadline = time.time() + timeout
    buf = b""
    while time.time() < deadline:
        chunk = proc.stderr.read(1)
        if not chunk:
            if proc.poll() is not None:
                raise SystemExit("server exited before ready")
            time.sleep(0.01)
            continue
        buf += chunk
        if b"ready\n" in buf:
            return
    raise SystemExit("server did not become ready: " + buf.decode("utf-8", "replace"))


def epsv_list():
    ctrl = socket.create_connection(("127.0.0.1", PORT), 5)
    ctrl_f = ctrl.makefile("rwb", buffering=0)

    def cmd(line):
        ctrl.sendall((line + "\r\n").encode())
        reply = b""
        while True:
            part = ctrl.recv(1)
            if not part:
                break
            reply += part
            if reply.endswith(b"\n") and (len(reply) < 4 or reply[3:4] != b"-"):
                if reply[:3].isdigit() and reply[3:4] == b" ":
                    return reply.decode("utf-8", "replace")

    banner = b""
    while not banner.endswith(b"\n"):
        banner += ctrl.recv(1)
    if not banner.startswith(b"220"):
        raise SystemExit("bad banner " + banner.decode())
    if not cmd("USER anonymous").startswith("331"):
        raise SystemExit("USER failed")
    if not cmd("PASS").startswith("230"):
        raise SystemExit("PASS failed")
    if not cmd("AUTH TLS").startswith("502"):
        raise SystemExit("AUTH TLS was not refused")
    epsv = cmd("EPSV")
    if not epsv.startswith("229"):
        raise SystemExit("EPSV failed: " + epsv.strip())
    port = int(epsv.split("|")[-2])
    data = socket.create_connection(("127.0.0.1", port), 5)
    listing_reply = cmd("LIST")
    if not listing_reply.startswith("150"):
        raise SystemExit("EPSV LIST failed: " + listing_reply.strip())
    blob = b""
    while True:
        chunk = data.recv(4096)
        if not chunk:
            break
        blob += chunk
    data.close()
    end = cmd("NOOP")
    # The 226 may already be buffered ahead of NOOP. Accept either.
    pending = b""
    ctrl.settimeout(0.3)
    try:
        while True:
            pending += ctrl.recv(1024)
    except socket.timeout:
        pass
    text = listing_reply + end + pending.decode("utf-8", "replace")
    if "226" not in text and "226" not in listing_reply:
        # read one more reply if 226 was the next line before NOOP was sent
        pass
    ctrl.close()
    body = blob.decode("utf-8", "replace")
    if "hello.txt" not in body or "cias" not in body:
        raise SystemExit("EPSV listing missing entries:\n" + body)
    for line in body.splitlines():
        if line and not UNIX_LIST.match(line):
            raise SystemExit("unreadable listing line: " + line)
    print("epsv list ok")
    print(body)


def main():
    if ROOT.exists():
        shutil.rmtree(ROOT)
    (ROOT / "cias").mkdir(parents=True)
    (ROOT / "hello.txt").write_bytes(b"hello-from-sd")
    (ROOT / "cias" / "game.cia").write_bytes(b"not-a-real-cia")
    (ROOT / "User Folder").mkdir()
    (ROOT / "User Folder" / "note.txt").write_text("inside")

    proc = subprocess.Popen(
        [str(BIN)],
        env={**os.environ, "FTP_ROOT": str(ROOT)},
        stderr=subprocess.PIPE,
    )
    try:
        wait_ready(proc)
        ftp = FTP()
        ftp.connect("127.0.0.1", PORT, timeout=5)
        ftp.login("anonymous", "guest")
        lines = []
        ftp.retrlines("LIST", lines.append)
        text = "\n".join(lines)
        print("pasv list:")
        print(text)
        if not lines:
            raise SystemExit("PASV LIST returned no entries")
        names = []
        dirs = []
        for line in lines:
            m = UNIX_LIST.match(line)
            if not m:
                raise SystemExit("client could not parse listing line: " + line)
            if m.group(1) == "d":
                dirs.append(m.group(2))
            else:
                names.append(m.group(2))
        if "hello.txt" not in names:
            raise SystemExit("hello.txt missing from listing")
        if "cias" not in dirs or "User Folder" not in dirs:
            raise SystemExit("directories missing: " + ", ".join(dirs))
        nlst = ftp.nlst()
        if "hello.txt" not in nlst or "cias" not in nlst:
            raise SystemExit("NLST failed: " + repr(nlst))
        got = []
        ftp.retrbinary("RETR hello.txt", got.append)
        if b"".join(got) != b"hello-from-sd":
            raise SystemExit("RETR mismatch")
        ftp.cwd("cias")
        sub = []
        ftp.retrlines("LIST", sub.append)
        if not any("game.cia" in line for line in sub):
            raise SystemExit("listing inside cias/ failed: " + repr(sub))
        from io import BytesIO
        ftp.storbinary("STOR dropped.cia", BytesIO(b"uploaded-cia"))
        ftp.quit()
        stored = (ROOT / "cias" / "dropped.cia").read_bytes()
        if stored != b"uploaded-cia":
            raise SystemExit("STOR did not land on the card")
        print("pasv list, nlst, retr, cwd, stor ok")
        epsv_list()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
    print("listing test passed")


if __name__ == "__main__":
    try:
        main()
    except error_perm as exc:
        print("FTP error:", exc, file=sys.stderr)
        sys.exit(1)
