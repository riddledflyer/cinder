#pragma once

#ifdef FTP_HOST_TEST
#include "ftp_host.h"
#else
#include <3ds.h>
#endif
#include <stdbool.h>

/* Homebrew FTP port. The server is only up while the FTP screen is open.
 * Root is the SD card. NAND is not shared. Login is anonymous. */
#define FTP_PORT 5000
#define FTP_LOG 10

typedef struct {
    bool running;
    bool client;
    char ip[40];
    char status[96];
    char cwd[160];
    char peer[40];
    char xfer_name[64];
    u64 xfer_done;
    u64 xfer_total;
    int log_count;
    char log[FTP_LOG][48];
} FtpInfo;

/* Opens port 5000. Safe to call again to retry after Wi-Fi comes up. */
Result ftp_start(void);
/* Closes every socket. Safe if start never succeeded. */
void ftp_stop(void);
void ftp_poll(void);
void ftp_info(FtpInfo *out);
/* True once if a client wrote, deleted, or renamed anything since last call. */
bool ftp_sd_changed(void);
