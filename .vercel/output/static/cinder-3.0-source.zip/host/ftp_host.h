/* Host stand-in for the 3DS headers, so the FTP server can be listed by a real client. */
#pragma once

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <netinet/in.h>

typedef int32_t s32;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef u32 Handle;
typedef s32 Result;
typedef u64 FS_Archive;

#define R_SUCCEEDED(r) ((r) >= 0)
#define R_FAILED(r) ((r) < 0)

typedef enum {
    PATH_INVALID = 0,
    PATH_EMPTY = 1,
    PATH_BINARY = 2,
    PATH_ASCII = 3,
    PATH_UTF16 = 4
} FS_PathType;

typedef struct {
    FS_PathType type;
    u32 size;
    const void *data;
} FS_Path;

typedef struct {
    u16 name[0x106];
    char shortName[0x0A];
    char shortExt[0x04];
    u8 valid;
    u8 reserved;
    u32 attributes;
    u64 fileSize;
} FS_DirectoryEntry;

enum {
    FS_OPEN_READ = 1,
    FS_OPEN_WRITE = 2,
    FS_OPEN_CREATE = 4
};

enum {
    FS_WRITE_FLUSH = 1,
    FS_WRITE_UPDATE_TIME = 0x100
};

enum {
    FS_ATTRIBUTE_DIRECTORY = 1
};

enum {
    ARCHIVE_SDMC = 9
};

FS_Path fsMakePath(FS_PathType type, const void *path);
Result acInit(void);
Result socInit(u32 *buffer, u32 size);
void socExit(void);
Result SOCU_GetIPInfo(struct in_addr *ip, struct in_addr *netmask, struct in_addr *broadcast);
u64 osGetTime(void);

Result FSUSER_OpenArchive(FS_Archive *archive, u32 id, FS_Path path);
Result FSUSER_CloseArchive(FS_Archive archive);
Result FSUSER_OpenDirectory(Handle *out, FS_Archive archive, FS_Path path);
Result FSDIR_Read(Handle handle, u32 *read, u32 count, FS_DirectoryEntry *ent);
Result FSDIR_Close(Handle handle);
Result FSUSER_OpenFile(Handle *out, FS_Archive archive, FS_Path path, u32 flags, u32 attr);
Result FSFILE_Close(Handle handle);
Result FSFILE_GetSize(Handle handle, u64 *size);
Result FSFILE_SetSize(Handle handle, u64 size);
Result FSFILE_Read(Handle handle, u32 *got, u64 offset, void *buf, u32 size);
Result FSFILE_Write(Handle handle, u32 *put, u64 offset, const void *buf, u32 size, u32 flags);
Result FSFILE_Flush(Handle handle);
Result FSUSER_CreateFile(FS_Archive archive, FS_Path path, u32 attr, u64 size);
Result FSUSER_DeleteFile(FS_Archive archive, FS_Path path);
Result FSUSER_CreateDirectory(FS_Archive archive, FS_Path path, u32 attr);
Result FSUSER_DeleteDirectory(FS_Archive archive, FS_Path path);
Result FSUSER_RenameFile(FS_Archive a, FS_Path src, FS_Archive b, FS_Path dst);
Result FSUSER_RenameDirectory(FS_Archive a, FS_Path src, FS_Archive b, FS_Path dst);
