#pragma once

#define CINDER_VERSION "3.4"
#define CINDER_REVISION 34
