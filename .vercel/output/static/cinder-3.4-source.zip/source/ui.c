#include "ui.h"

#include <citro2d.h>

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

extern const u8 default_font_bin[];

#define FONT_GLYPHS 256
#define FONT_TEX 128
#define ICON_TEX 64
#define ICON_SLOTS 24

typedef struct {
    const u16 *pix;
    u32 sum;
    int src_w;
    bool key_zero;
    bool live;
    u32 used;
    C3D_Tex tex;
    Tex3DS_SubTexture sub;
    C2D_Image img;
} IconSlot;

static C3D_RenderTarget *g_top;
static C3D_RenderTarget *g_bot;
static C3D_RenderTarget *g_target;
static gfxScreen_t g_screen = GFX_TOP;
static bool g_c3d;
static bool g_c2d;
static bool g_ready;
static bool g_frame;
static bool g_scene;
static int g_pix_w = 400;
static int g_pix_h = 240;
static int g_cols = 50;
static int g_rows = 30;
static int g_cx;
static int g_cy;

static C3D_Tex g_font_tex;
static Tex3DS_SubTexture g_glyph_sub[FONT_GLYPHS];
static C2D_Image g_glyph[FONT_GLYPHS];
static bool g_font_ok;

static IconSlot g_icons[ICON_SLOTS];
static int g_icon_clock;
static u32 *g_stage;
static u32 g_stage_bytes;
static u32 *g_icon_lin;

static void unpack565(u16 c, int *r, int *g, int *b) {
    int r5 = (c >> 11) & 31;
    int g6 = (c >> 5) & 63;
    int b5 = c & 31;
    *r = (r5 << 3) | (r5 >> 2);
    *g = (g6 << 2) | (g6 >> 4);
    *b = (b5 << 3) | (b5 >> 2);
}

static u32 checksum(const u16 *pix, int n) {
    u32 sum = 2166136261u;
    int step = n > 48 ? n / 24 : 1;
    if (step < 1) step = 1;
    for (int i = 0; i < n; i += step) sum = (sum ^ pix[i]) * 16777619u;
    return sum ? sum : 1;
}

static void swizzle_rgba8(u32 *dst, const u32 *src, int dim) {
    int tiles = dim >> 3;
    for (int ty = 0; ty < tiles; ty++) {
        for (int tx = 0; tx < tiles; tx++) {
            u32 *tile = dst + ((ty * tiles + tx) << 6);
            const u32 *row = src + ((ty << 3) * dim) + (tx << 3);
            for (int y = 0; y < 8; y++) {
                for (int x = 0; x < 8; x++) {
                    int m = (x & 1) | ((y & 1) << 1) | ((x & 2) << 1) | ((y & 2) << 2) |
                            ((x & 4) << 2) | ((y & 4) << 3);
                    tile[m] = row[y * dim + x];
                }
            }
        }
    }
}

static void begin_frame(void) {
    if (g_frame) return;
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    g_frame = true;
}

static void ensure(void) {
    begin_frame();
    if (!g_scene && g_target) {
        C2D_SceneBegin(g_target);
        g_scene = true;
    }
}

static bool upload_rgba(C3D_Tex *tex, const u32 *rgba, u16 dim) {
    u32 bytes = (u32)dim * dim * 4;
    if (!g_stage || !rgba || rgba == g_stage || bytes > g_stage_bytes) return false;
    swizzle_rgba8(g_stage, rgba, dim);
    GSPGPU_FlushDataCache(g_stage, bytes);
    if (!tex->data) {
        if (!C3D_TexInitVRAM(tex, dim, dim, GPU_RGBA8)) return false;
        C3D_TexSetWrap(tex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
    }
    C3D_TexLoadImage(tex, g_stage, GPU_TEXFACE_2D, 0);
    return tex->data != NULL;
}

static bool build_font(void) {
    u32 *rgba = linearAlloc(FONT_TEX * FONT_TEX * 4);
    if (!rgba) return false;
    memset(rgba, 0, FONT_TEX * FONT_TEX * 4);
    for (int c = 0; c < FONT_GLYPHS; c++) {
        int col = c & 15;
        int row = c >> 4;
        const u8 *glyph = default_font_bin + c * 8;
        for (int gy = 0; gy < 8; gy++) {
            for (int gx = 0; gx < 8; gx++) {
                if (glyph[gy] & (u8)(0x80 >> gx)) {
                    int x = col * 8 + gx;
                    int y = row * 8 + gy;
                    rgba[y * FONT_TEX + x] = C2D_Color32(255, 255, 255, 255);
                }
            }
        }
        float u0 = (col * 8) / (float)FONT_TEX;
        float v0 = 1.0f - (row * 8) / (float)FONT_TEX;
        g_glyph_sub[c].width = 8;
        g_glyph_sub[c].height = 8;
        g_glyph_sub[c].left = u0;
        g_glyph_sub[c].right = u0 + 8.0f / FONT_TEX;
        g_glyph_sub[c].top = v0;
        g_glyph_sub[c].bottom = v0 - 8.0f / FONT_TEX;
        g_glyph[c].tex = &g_font_tex;
        g_glyph[c].subtex = &g_glyph_sub[c];
    }
    memset(&g_font_tex, 0, sizeof(g_font_tex));
    bool ok = upload_rgba(&g_font_tex, rgba, FONT_TEX);
    linearFree(rgba);
    if (!ok) return false;
    C3D_TexSetFilter(&g_font_tex, GPU_NEAREST, GPU_NEAREST);
    g_font_ok = true;
    return true;
}

void ui_init(void) {
    gfxInitDefault();
    gfxSet3D(false);
    gfxSetWide(false);
    if (!C3D_Init(0x20000)) return;
    g_c3d = true;
    if (!C2D_Init(1024)) return;
    g_c2d = true;
    C2D_Prepare();
    C2D_SetTintMode(C2D_TintMult);
    g_top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    g_bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    if (!g_top || !g_bot) return;
    g_stage_bytes = FONT_TEX * FONT_TEX * 4;
    g_stage = linearAlloc(g_stage_bytes);
    g_icon_lin = linearAlloc(ICON_TEX * ICON_TEX * 4);
    if (!g_stage || !g_icon_lin) return;
    if (!build_font()) return;
    g_ready = true;
    g_screen = GFX_TOP;
    g_target = g_top;
    g_pix_w = 400;
    g_pix_h = 240;
    begin_frame();
    C2D_TargetClear(g_top, C2D_Color32(0, 0, 0, 255));
    C2D_SceneBegin(g_top);
    C2D_TargetClear(g_bot, C2D_Color32(0, 0, 0, 255));
    C2D_SceneBegin(g_bot);
    C3D_FrameEnd(0);
    g_frame = false;
    g_scene = false;
}

void ui_drop_images(void) {
    for (int i = 0; i < ICON_SLOTS; i++) {
        if (g_icons[i].live && g_icons[i].tex.data) C3D_TexDelete(&g_icons[i].tex);
        memset(&g_icons[i], 0, sizeof(g_icons[i]));
    }
}

void ui_exit(void) {
    if (g_frame) {
        C3D_FrameEnd(0);
        g_frame = false;
    }
    ui_drop_images();
    if (g_font_tex.data) C3D_TexDelete(&g_font_tex);
    if (g_stage) linearFree(g_stage);
    g_stage = NULL;
    if (g_icon_lin) linearFree(g_icon_lin);
    g_icon_lin = NULL;
    if (g_c2d) C2D_Fini();
    if (g_c3d) C3D_Fini();
    gfxExit();
    g_c2d = false;
    g_c3d = false;
    g_ready = false;
}

void ui_select(gfxScreen_t screen) {
    g_screen = screen;
    g_target = screen == GFX_TOP ? g_top : g_bot;
    g_pix_w = screen == GFX_TOP ? 400 : 320;
    g_pix_h = 240;
    g_cols = g_pix_w / 8;
    g_rows = g_pix_h / 8;
    if (g_cols < 1) g_cols = 1;
    if (g_rows < 1) g_rows = 1;
    g_scene = false;
}

void ui_clear(void) {
    if (!g_ready || !g_target) return;
    begin_frame();
    C2D_TargetClear(g_target, C2D_Color32(0, 0, 0, 255));
    C2D_SceneBegin(g_target);
    g_scene = true;
    g_cx = 0;
    g_cy = 0;
}

static void glyph_at(int x, int y, int c, u8 r, u8 g, u8 b) {
    C2D_ImageTint tint;
    if (!g_font_ok) return;
    if (c < 0 || c > 255) c = ' ';
    if (x <= -8 || y <= -8 || x >= g_pix_w || y >= g_pix_h) return;
    C2D_PlainImageTint(&tint, C2D_Color32(r, g, b, 255), 1.0f);
    C2D_DrawImageAt(g_glyph[c], (float)x, (float)y, 0.0f, &tint, 1.0f, 1.0f);
}

static void putc_ui(unsigned char c) {
    if (c == '\n') {
        g_cx = 0;
        g_cy++;
        return;
    }
    if (c == '\r') {
        g_cx = 0;
        return;
    }
    if (g_cx >= g_cols) {
        g_cx = 0;
        g_cy++;
    }
    if (g_cy < 0 || g_cy >= g_rows) return;
    if (c >= 32) glyph_at(g_cx * 8, g_cy * 8, c, 192, 192, 192);
    g_cx++;
}

void ui_printf(const char *fmt, ...) {
    char buf[192];
    va_list ap;
    if (!g_ready) return;
    ensure();
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    for (char *s = buf; *s; s++) putc_ui((unsigned char)*s);
}

void ui_present(void) {
    if (!g_frame) return;
    C3D_FrameEnd(0);
    g_frame = false;
    g_scene = false;
}

void ui_size(int *width, int *height) {
    if (width) *width = g_pix_w;
    if (height) *height = g_pix_h;
}

void ui_fill(int x, int y, int w, int h, u8 r, u8 g, u8 b) {
    int x2;
    int y2;
    if (!g_ready || w <= 0 || h <= 0) return;
    x2 = x + w;
    y2 = y + h;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x2 > g_pix_w) x2 = g_pix_w;
    if (y2 > g_pix_h) y2 = g_pix_h;
    if (x2 <= x || y2 <= y) return;
    ensure();
    C2D_DrawRectSolid((float)x, (float)y, 0.0f, (float)(x2 - x), (float)(y2 - y), C2D_Color32(r, g, b, 255));
}

int ui_text(int x, int y, const char *text, int max_chars, u8 r, u8 g, u8 b) {
    int drawn = 0;
    if (!text || !g_ready) return x;
    ensure();
    for (const unsigned char *s = (const unsigned char *)text; *s && drawn < max_chars; s++) {
        unsigned char c = *s;
        if (c < 32) continue;
        if (c >= 0x80) {
            if ((c & 0xE0) == 0xC0 && s[1]) s += 1;
            else if ((c & 0xF0) == 0xE0 && s[1] && s[2]) s += 2;
            else if ((c & 0xF8) == 0xF0 && s[1] && s[2] && s[3]) s += 3;
            c = '?';
        }
        glyph_at(x, y, c, r, g, b);
        x += 8;
        drawn++;
    }
    return x;
}

static IconSlot *slot_for(const u16 *pix, int src_w, bool key_zero) {
    int free_slot = -1;
    int oldest = 0;
    u32 oldest_used = 0xffffffffu;
    for (int i = 0; i < ICON_SLOTS; i++) {
        IconSlot *slot = &g_icons[i];
        if (!slot->live) {
            if (free_slot < 0) free_slot = i;
            continue;
        }
        if (slot->pix == pix && slot->src_w == src_w && slot->key_zero == key_zero) return slot;
        if (slot->used < oldest_used) {
            oldest_used = slot->used;
            oldest = i;
        }
    }
    if (free_slot >= 0) return &g_icons[free_slot];
    if (g_icons[oldest].tex.data) C3D_TexDelete(&g_icons[oldest].tex);
    memset(&g_icons[oldest], 0, sizeof(g_icons[oldest]));
    return &g_icons[oldest];
}

void ui_icon(int x, int y, const u16 *icon, int src_w, int size, bool key_zero) {
    IconSlot *slot;
    u32 sum;
    float scale;
    if (!g_ready || size <= 0) return;
    ensure();
    if (!icon || src_w <= 0 || src_w > ICON_TEX) {
        ui_fill(x, y, size, size, 36, 40, 52);
        return;
    }
    sum = checksum(icon, src_w * src_w);
    slot = slot_for(icon, src_w, key_zero);
    if (!slot->live || slot->sum != sum || slot->pix != icon) {
        u32 *rgba = g_icon_lin;
        if (!rgba) {
            ui_fill(x, y, size, size, 36, 40, 52);
            return;
        }
        memset(rgba, 0, ICON_TEX * ICON_TEX * 4);
        for (int row = 0; row < src_w; row++) {
            for (int col = 0; col < src_w; col++) {
                u16 c = icon[row * src_w + col];
                u32 px = 0;
                if (!(key_zero && c == 0)) {
                    int r, g, b;
                    unpack565(c, &r, &g, &b);
                    px = C2D_Color32((u8)r, (u8)g, (u8)b, 255);
                }
                rgba[row * ICON_TEX + col] = px;
            }
        }
        if (!slot->live) memset(&slot->tex, 0, sizeof(slot->tex));
        if (!upload_rgba(&slot->tex, rgba, ICON_TEX)) {
            ui_fill(x, y, size, size, 36, 40, 52);
            return;
        }
        C3D_TexSetFilter(&slot->tex, GPU_LINEAR, GPU_LINEAR);
        slot->sub.width = (u16)src_w;
        slot->sub.height = (u16)src_w;
        slot->sub.left = 0.0f;
        slot->sub.right = src_w / (float)ICON_TEX;
        slot->sub.top = 1.0f;
        slot->sub.bottom = 1.0f - src_w / (float)ICON_TEX;
        slot->img.tex = &slot->tex;
        slot->img.subtex = &slot->sub;
        slot->pix = icon;
        slot->src_w = src_w;
        slot->key_zero = key_zero;
        slot->sum = sum;
        slot->live = true;
    }
    slot->used = (u32)++g_icon_clock;
    scale = size / (float)src_w;
    C2D_DrawImageAt(slot->img, (float)x, (float)y, 0.0f, NULL, scale, scale);
}
