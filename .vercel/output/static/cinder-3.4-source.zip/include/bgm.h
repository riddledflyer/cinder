#pragma once

void bgm_start(void);

void bgm_poll(void);
void bgm_stop(void);
