#pragma once

#include <3ds.h>
#include <stdbool.h>

void ui_init(void);
void ui_exit(void);

void ui_drop_images(void);
void ui_select(gfxScreen_t screen);
void ui_clear(void);
void ui_printf(const char *fmt, ...);
void ui_present(void);

void ui_size(int *width, int *height);
void ui_fill(int x, int y, int w, int h, u8 r, u8 g, u8 b);
int ui_text(int x, int y, const char *text, int max_chars, u8 r, u8 g, u8 b);

void ui_icon(int x, int y, const u16 *icon, int src_w, int size, bool key_zero);
