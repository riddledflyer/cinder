#pragma once

#define CINDER_VERSION "3.5"
#define CINDER_REVISION 35
