#include "ftp.h"
#include "version.h"

#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define SOC_ALIGN 0x1000
#define SOC_SIZE 0x100000
#define CHUNK (16 * 1024)

enum {
    XFER_NONE = 0,
    XFER_WAIT,
    XFER_LIST,
    XFER_RETR,
    XFER_STOR
};

static struct {
    bool running;
    bool ac_up;
    bool sd_changed;
    u32 *soc;
    int listen_fd;
    int ctrl;
    int data_fd;
    int data_listen;
    int xfer;
    int xfer_kind;
    int mlsd;
    bool sent_150;
    u16 data_port;
    u64 rest;
    u64 xfer_done;
    u64 xfer_total;
    u64 xfer_deadline;
    struct sockaddr_in active;
    bool use_active;
    FILE *fp;
    DIR *dir;
    char cwd[160];
    char ip[40];
    char status[96];
    char peer[40];
    char xfer_name[64];
    char sd_path[320];
    char inbuf[768];
    int inlen;
    char outq[1024];
    int outlen;
    u8 chunk[CHUNK];
    int chunk_len;
    int chunk_pos;
    int log_count;
    char log[FTP_LOG][48];
} g;

static bool g_ready;

static void ensure_init(void) {
    if (g_ready) return;
    memset(&g, 0, sizeof(g));
    g.listen_fd = -1;
    g.ctrl = -1;
    g.data_fd = -1;
    g.data_listen = -1;
    g.data_port = 5001;
    snprintf(g.cwd, sizeof(g.cwd), "/");
    snprintf(g.ip, sizeof(g.ip), "0.0.0.0");
    g_ready = true;
}

static void note(const char *text) {
    if (!text || !text[0]) return;
    if (g.log_count >= FTP_LOG) {
        memmove(g.log[0], g.log[1], (FTP_LOG - 1) * sizeof(g.log[0]));
        g.log_count = FTP_LOG - 1;
    }
    snprintf(g.log[g.log_count], sizeof(g.log[0]), "%s", text);
    g.log_count++;
}

static void set_status(const char *text) {
    snprintf(g.status, sizeof(g.status), "%s", text ? text : "");
}

static void set_nb(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) flags = 0;
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

static void nodelay(int fd) {
    int on = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));
}

static void close_fd(int *fd) {
    if (fd && *fd >= 0) {
        close(*fd);
        *fd = -1;
    }
}

static bool flush_out(void) {
    while (g.outlen > 0 && g.ctrl >= 0) {
        int n = send(g.ctrl, g.outq, g.outlen, 0);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) return false;
            return false;
        }
        if (n == 0) return false;
        if (n < g.outlen) memmove(g.outq, g.outq + n, (size_t)(g.outlen - n));
        g.outlen -= n;
    }
    return true;
}

static void reply_raw(const char *text) {
    if (!text || g.ctrl < 0) return;
    size_t n = strlen(text);
    if (n > sizeof(g.outq)) n = sizeof(g.outq);
    if (g.outlen + (int)n > (int)sizeof(g.outq)) flush_out();
    if (g.outlen + (int)n > (int)sizeof(g.outq)) return;
    memcpy(g.outq + g.outlen, text, n);
    g.outlen += (int)n;
    flush_out();
}

static void reply(int code, const char *text) {
    char line[384];
    snprintf(line, sizeof(line), "%d %s\r\n", code, text ? text : "");
    reply_raw(line);
}

static void clear_data(void) {
    if (g.fp) {
        fclose(g.fp);
        g.fp = NULL;
    }
    if (g.dir) {
        closedir(g.dir);
        g.dir = NULL;
    }
    close_fd(&g.data_fd);
    close_fd(&g.data_listen);
    g.xfer = XFER_NONE;
    g.sent_150 = false;
    g.chunk_len = 0;
    g.chunk_pos = 0;
    g.xfer_name[0] = '\0';
    g.use_active = false;
}

static bool normalize_path(char *out, size_t out_n, const char *cwd, const char *arg) {
    char raw[480];
    if (!arg || arg[0] == '\0') {
        snprintf(raw, sizeof(raw), "%s", cwd && cwd[0] ? cwd : "/");
    } else if (arg[0] == '/') {
        snprintf(raw, sizeof(raw), "%s", arg);
    } else if (!cwd || strcmp(cwd, "/") == 0) {
        snprintf(raw, sizeof(raw), "/%s", arg);
    } else {
        snprintf(raw, sizeof(raw), "%s/%s", cwd, arg);
    }
    for (char *p = raw; *p; p++) {
        if (*p == '\\') *p = '/';
    }

    char built[480];
    size_t len = 0;
    built[0] = '\0';
    const char *p = raw;
    while (*p) {
        while (*p == '/') p++;
        if (!*p) break;
        const char *start = p;
        while (*p && *p != '/') p++;
        size_t n = (size_t)(p - start);
        if (n == 1 && start[0] == '.') continue;
        if (n == 2 && start[0] == '.' && start[1] == '.') {
            if (len > 1) {
                char *slash = strrchr(built, '/');
                if (!slash || slash == built) {
                    built[1] = '\0';
                    len = 1;
                } else {
                    *slash = '\0';
                    len = strlen(built);
                }
            }
            continue;
        }
        if (n == 0 || n > 120) return false;
        if (len == 0) {
            if (1 + n >= sizeof(built)) return false;
            built[0] = '/';
            memcpy(built + 1, start, n);
            len = 1 + n;
            built[len] = '\0';
        } else if (len == 1) {
            if (len + n >= sizeof(built)) return false;
            memcpy(built + 1, start, n);
            len = 1 + n;
            built[len] = '\0';
        } else {
            if (len + 1 + n >= sizeof(built)) return false;
            built[len++] = '/';
            memcpy(built + len, start, n);
            len += n;
            built[len] = '\0';
        }
    }
    if (len == 0) {
        built[0] = '/';
        built[1] = '\0';
        len = 1;
    }
    if (len + 1 > out_n) return false;
    memcpy(out, built, len + 1);
    return true;
}

static bool to_sdmc(const char *ftp, char *out, size_t n) {
    int wrote;
    if (!ftp || ftp[0] != '/') return false;
    if (strcmp(ftp, "/") == 0) wrote = snprintf(out, n, "sdmc:/");
    else wrote = snprintf(out, n, "sdmc:%s", ftp);
    return wrote > 0 && (size_t)wrote < n;
}

static bool path_stat(const char *ftp, struct stat *st) {
    char sd[320];
    if (!to_sdmc(ftp, sd, sizeof(sd))) return false;
    if (stat(sd, st) == 0) return true;
    if (strcmp(ftp, "/") == 0) {
        memset(st, 0, sizeof(*st));
        st->st_mode = S_IFDIR | 0755;
        return true;
    }
    return false;
}

static bool is_dir_path(const char *ftp) {
    struct stat st;
    if (!path_stat(ftp, &st)) return false;
    return S_ISDIR(st.st_mode);
}

static void base_name(const char *path, char *out, size_t n) {
    const char *slash = strrchr(path, '/');
    const char *name = slash ? slash + 1 : path;
    if (!name[0]) name = "/";
    snprintf(out, n, "%s", name);
}

static void drop_client(const char *why) {
    clear_data();
    close_fd(&g.ctrl);
    g.inlen = 0;
    g.outlen = 0;
    g.rest = 0;
    g.peer[0] = '\0';
    if (why) note(why);
    if (g.running) set_status("Listening");
}

static bool send_blocked(int fd, const u8 *data, int len, int *sent) {
    while (*sent < len) {
        int n = send(fd, data + *sent, len - *sent, 0);
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) return true;
            return false;
        }
        if (n == 0) return false;
        *sent += n;
    }
    return true;
}

static bool open_pasv(void) {
    close_fd(&g.data_listen);
    close_fd(&g.data_fd);
    g.use_active = false;
    for (int attempt = 0; attempt < 24; attempt++) {
        int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
        if (fd < 0) return false;
        int on = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(g.data_port);
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == 0 && listen(fd, 1) == 0) {
            set_nb(fd);
            g.data_listen = fd;
            return true;
        }
        close(fd);
        g.data_port++;
        if (g.data_port < 5001 || g.data_port > 64000) g.data_port = 5001;
    }
    return false;
}

static void reply_pasv(void) {
    unsigned ip = ntohl(inet_addr(g.ip));
    if (g.ip[0] == '\0' || strcmp(g.ip, "0.0.0.0") == 0) ip = 0;
    unsigned port = g.data_port;
    char line[96];
    snprintf(line, sizeof(line), "Entering Passive Mode (%u,%u,%u,%u,%u,%u)",
             (ip >> 24) & 255, (ip >> 16) & 255, (ip >> 8) & 255, ip & 255,
             (port >> 8) & 255, port & 255);
    reply(227, line);
    g.data_port++;
    if (g.data_port < 5001 || g.data_port > 64000) g.data_port = 5001;
}

static bool accept_data(void) {
    if (g.data_fd >= 0) return true;
    if (g.data_listen < 0) return false;
    struct sockaddr_in peer;
    socklen_t sl = sizeof(peer);
    int fd = accept(g.data_listen, (struct sockaddr *)&peer, &sl);
    if (fd < 0) return false;
    set_nb(fd);
    nodelay(fd);
    g.data_fd = fd;
    close_fd(&g.data_listen);
    return true;
}

static bool connect_active(void) {
    if (g.data_fd >= 0) return true;
    if (!g.use_active) return false;
    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (fd < 0) return false;
    set_nb(fd);
    nodelay(fd);
    int rc = connect(fd, (struct sockaddr *)&g.active, sizeof(g.active));
    if (rc == 0) {
        g.data_fd = fd;
        return true;
    }
    if (errno == EINPROGRESS || errno == EAGAIN) {
        g.data_fd = fd;
        return false;
    }
    close(fd);
    return false;
}

static bool active_ready(void) {
    if (!g.use_active || g.data_fd < 0) return false;
    struct pollfd pfd;
    pfd.fd = g.data_fd;
    pfd.events = POLLOUT;
    pfd.revents = 0;
    if (poll(&pfd, 1, 0) <= 0) return false;
    int err = 0;
    socklen_t len = sizeof(err);
    if (getsockopt(g.data_fd, SOL_SOCKET, SO_ERROR, &err, &len) < 0 || err != 0) return false;
    return true;
}

static void finish_xfer(bool ok, const char *why) {
    bool announced = g.sent_150;
    clear_data();
    if (!announced) {
        reply(425, why && why[0] ? why : "Can't open data connection");
        return;
    }
    if (ok) {
        reply(226, "Transfer complete");
        set_status("Listening");
    } else {
        reply(426, why && why[0] ? why : "Transfer aborted");
        set_status(why && why[0] ? why : "Transfer aborted");
    }
}

static void quote_path(const char *path, char *out, size_t n) {
    size_t j = 0;
    if (n == 0) return;
    for (size_t i = 0; path[i] && j + 2 < n; i++) {
        if (path[i] == '"') out[j++] = '"';
        out[j++] = path[i];
    }
    out[j] = '\0';
}

static bool list_one(bool mlsd) {
    if (!g.dir) return false;
    struct dirent *ent = readdir(g.dir);
    if (!ent) return false;
    char child[320];
    if (strcmp(g.cwd, "/") == 0) snprintf(child, sizeof(child), "/%s", ent->d_name);
    else snprintf(child, sizeof(child), "%s/%s", g.cwd, ent->d_name);
    struct stat st;
    bool known = path_stat(child, &st);
    bool dir = known && S_ISDIR(st.st_mode);
    if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) dir = true;
    char safe[160];
    size_t j = 0;
    for (size_t i = 0; ent->d_name[i] && j + 1 < sizeof(safe); i++) {
        char c = ent->d_name[i];
        if (c == '\r' || c == '\n') c = '?';
        safe[j++] = c;
    }
    safe[j] = '\0';
    if (mlsd) {
        if (dir) g.chunk_len = snprintf((char *)g.chunk, CHUNK, "type=dir;modify=19700101000000; %s\r\n", safe);
        else g.chunk_len = snprintf((char *)g.chunk, CHUNK, "type=file;size=%llu;modify=19700101000000; %s\r\n",
                                    known ? (unsigned long long)st.st_size : 0ull, safe);
    } else {
        char when[24] = "Jan  1 00:00";
        if (known) {
            time_t t = (time_t)st.st_mtime;
            struct tm *tm = gmtime(&t);
            if (tm) strftime(when, sizeof(when), "%b %d %H:%M", tm);
        }
        g.chunk_len = snprintf((char *)g.chunk, CHUNK, "%s 1 cinder cinder %llu %s %s\r\n",
                               dir ? "drwxrwxrwx" : "-rw-rw-rw-",
                               dir ? 0ull : (known ? (unsigned long long)st.st_size : 0ull),
                               when, safe);
    }
    if (g.chunk_len < 0) g.chunk_len = 0;
    if (g.chunk_len >= CHUNK) g.chunk_len = CHUNK - 1;
    g.chunk_pos = 0;
    return g.chunk_len > 0;
}

static bool start_list(bool mlsd) {
    char sd[320];
    if (!to_sdmc(g.cwd, sd, sizeof(sd))) {
        reply(550, "Bad path");
        return false;
    }
    g.dir = opendir(sd);
    if (!g.dir && strcmp(g.cwd, "/") != 0) {
        reply(550, "Not a directory");
        return false;
    }
    g.xfer_kind = XFER_LIST;
    g.mlsd = mlsd ? 1 : 0;
    g.xfer = XFER_WAIT;
    g.xfer_done = 0;
    g.xfer_total = 0;
    g.xfer_deadline = osGetTime() + 20000;
    snprintf(g.xfer_name, sizeof(g.xfer_name), "%s", mlsd ? "MLSD" : "LIST");
    reply(150, "Opening data connection");
    g.sent_150 = true;
    return true;
}

static bool start_retr(const char *arg) {
    char ftp[240];
    if (!normalize_path(ftp, sizeof(ftp), g.cwd, arg) || is_dir_path(ftp)) {
        reply(550, "Not a file");
        return false;
    }
    char sd[320];
    if (!to_sdmc(ftp, sd, sizeof(sd))) {
        reply(550, "Bad path");
        return false;
    }
    struct stat st;
    if (stat(sd, &st) != 0 || S_ISDIR(st.st_mode)) {
        reply(550, "Not a file");
        return false;
    }
    if (g.rest > (u64)st.st_size) {
        reply(554, "Restart past end");
        g.rest = 0;
        return false;
    }
    FILE *fp = fopen(sd, "rb");
    if (!fp) {
        reply(550, "Can't open");
        return false;
    }
    if (g.rest && fseeko(fp, (off_t)g.rest, SEEK_SET) != 0) {
        fclose(fp);
        reply(554, "Restart failed");
        g.rest = 0;
        return false;
    }
    g.fp = fp;
    g.xfer_kind = XFER_RETR;
    g.xfer = XFER_WAIT;
    g.xfer_done = g.rest;
    g.xfer_total = (u64)st.st_size;
    g.rest = 0;
    g.xfer_deadline = osGetTime() + 20000;
    base_name(ftp, g.xfer_name, sizeof(g.xfer_name));
    snprintf(g.sd_path, sizeof(g.sd_path), "%s", sd);
    reply(150, "Opening data connection");
    g.sent_150 = true;
    set_status("Sending");
    return true;
}

static bool ends_cia(const char *name) {
    size_t n = strlen(name);
    if (n < 4) return false;
    const char *e = name + n - 4;
    return (e[0] == '.' ) &&
           (e[1] == 'c' || e[1] == 'C') &&
           (e[2] == 'i' || e[2] == 'I') &&
           (e[3] == 'a' || e[3] == 'A');
}

static bool start_stor(const char *arg, bool append) {
    char ftp[240];
    if (!arg || !arg[0] || !normalize_path(ftp, sizeof(ftp), g.cwd, arg)) {
        reply(550, "Bad path");
        return false;
    }
    if (strcmp(ftp, "/") == 0 || is_dir_path(ftp)) {
        reply(550, "Not a file");
        return false;
    }
    char parent[240];
    snprintf(parent, sizeof(parent), "%s", ftp);
    char *slash = strrchr(parent, '/');
    if (!slash) {
        reply(550, "Bad path");
        return false;
    }
    if (slash == parent) parent[1] = '\0';
    else *slash = '\0';
    if (!is_dir_path(parent)) {
        reply(550, "No such directory");
        return false;
    }
    char sd[320];
    if (!to_sdmc(ftp, sd, sizeof(sd))) {
        reply(550, "Bad path");
        return false;
    }
    FILE *fp = NULL;
    if (append) fp = fopen(sd, "ab");
    else if (g.rest) {
        fp = fopen(sd, "r+b");
        if (!fp) fp = fopen(sd, "wb");
        if (fp && fseeko(fp, (off_t)g.rest, SEEK_SET) != 0) {
            fclose(fp);
            fp = NULL;
        }
    } else {
        fp = fopen(sd, "wb");
    }
    if (!fp) {
        reply(550, "Can't create");
        g.rest = 0;
        return false;
    }
    g.fp = fp;
    g.xfer_kind = XFER_STOR;
    g.xfer = XFER_WAIT;
    g.xfer_done = append ? 0 : g.rest;
    g.xfer_total = 0;
    g.rest = 0;
    g.xfer_deadline = osGetTime() + 20000;
    base_name(ftp, g.xfer_name, sizeof(g.xfer_name));
    snprintf(g.sd_path, sizeof(g.sd_path), "%s", sd);
    reply(150, "Opening data connection");
    g.sent_150 = true;
    set_status("Receiving");
    return true;
}

static void mark_changed(const char *name) {
    g.sd_changed = true;
    if (name && ends_cia(name)) note("CIA stored");
}

static void handle(char *line) {
    char verb[16];
    char arg[320];
    size_t i = 0;
    while (line[i] == ' ') i++;
    size_t v = 0;
    while (line[i] && line[i] != ' ') {
        char c = line[i++];
        if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
        if (v + 1 < sizeof(verb)) verb[v++] = c;
    }
    verb[v] = '\0';
    while (line[i] == ' ') i++;
    snprintf(arg, sizeof(arg), "%s", line + i);
    size_t an = strlen(arg);
    while (an && (arg[an - 1] == ' ' || arg[an - 1] == '\r')) arg[--an] = '\0';

    if (verb[0] == '\0') return;
    if (strcmp(verb, "PASS") != 0) {
        char shown[48];
        if (arg[0] && strcmp(verb, "PASS") != 0) snprintf(shown, sizeof(shown), "%s %s", verb, arg);
        else snprintf(shown, sizeof(shown), "%s", verb);
        note(shown);
    } else {
        note("PASS");
    }

    if (strcmp(verb, "QUIT") == 0) {
        reply(221, "Bye");
        drop_client("Client left");
        return;
    }
    if (strcmp(verb, "USER") == 0) {
        reply(331, "Any password");
        return;
    }
    if (strcmp(verb, "PASS") == 0) {
        reply(230, "Logged in");
        return;
    }
    if (strcmp(verb, "SYST") == 0) {
        reply(215, "UNIX Type: L8");
        return;
    }
    if (strcmp(verb, "FEAT") == 0) {
        reply_raw("211-Features\r\n SIZE\r\n REST STREAM\r\n UTF8\r\n MLSD\r\n EPSV\r\n211 End\r\n");
        return;
    }
    if (strcmp(verb, "NOOP") == 0 || strcmp(verb, "CLNT") == 0 || strcmp(verb, "OPTS") == 0) {
        reply(200, "OK");
        return;
    }
    if (strcmp(verb, "TYPE") == 0 || strcmp(verb, "MODE") == 0 || strcmp(verb, "STRU") == 0) {
        reply(200, "OK");
        return;
    }
    if (strcmp(verb, "AUTH") == 0 || strcmp(verb, "PBSZ") == 0 || strcmp(verb, "PROT") == 0) {
        reply(502, "TLS is not available");
        return;
    }
    if (strcmp(verb, "PWD") == 0 || strcmp(verb, "XPWD") == 0) {
        char q[200];
        char body[280];
        quote_path(g.cwd, q, sizeof(q));
        snprintf(body, sizeof(body), "\"%s\" is current directory", q);
        reply(257, body);
        return;
    }
    if (strcmp(verb, "CWD") == 0 || strcmp(verb, "XCWD") == 0) {
        char next[160];
        const char *use = arg[0] ? arg : "/";
        if (!normalize_path(next, sizeof(next), g.cwd, use) || !is_dir_path(next)) {
            reply(550, "No such directory");
            return;
        }
        snprintf(g.cwd, sizeof(g.cwd), "%s", next);
        reply(250, "Directory changed");
        return;
    }
    if (strcmp(verb, "CDUP") == 0) {
        char next[160];
        if (!normalize_path(next, sizeof(next), g.cwd, "..")) {
            reply(550, "No such directory");
            return;
        }
        snprintf(g.cwd, sizeof(g.cwd), "%s", next);
        reply(250, "Directory changed");
        return;
    }
    if (strcmp(verb, "MKD") == 0 || strcmp(verb, "XMKD") == 0) {
        char next[240];
        char sd[320];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !to_sdmc(next, sd, sizeof(sd))) {
            reply(550, "Bad path");
            return;
        }
        if (mkdir(sd, 0777) != 0) {
            reply(550, "Can't create");
            return;
        }
        g.sd_changed = true;
        char q[200];
        char body[280];
        quote_path(next, q, sizeof(q));
        snprintf(body, sizeof(body), "\"%s\" created", q);
        reply(257, body);
        return;
    }
    if (strcmp(verb, "RMD") == 0 || strcmp(verb, "XRMD") == 0) {
        char next[240];
        char sd[320];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || strcmp(next, "/") == 0 ||
            !to_sdmc(next, sd, sizeof(sd))) {
            reply(550, "Bad path");
            return;
        }
        if (rmdir(sd) != 0) {
            reply(550, "Can't remove");
            return;
        }
        g.sd_changed = true;
        reply(250, "Removed");
        return;
    }
    if (strcmp(verb, "DELE") == 0) {
        char next[240];
        char sd[320];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !to_sdmc(next, sd, sizeof(sd))) {
            reply(550, "Bad path");
            return;
        }
        if (unlink(sd) != 0) {
            reply(550, "Can't delete");
            return;
        }
        mark_changed(next);
        reply(250, "Deleted");
        return;
    }
    if (strcmp(verb, "RNFR") == 0) {
        char next[240];
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !to_sdmc(next, g.sd_path, sizeof(g.sd_path))) {
            reply(550, "Bad path");
            return;
        }
        struct stat st;
        if (stat(g.sd_path, &st) != 0) {
            g.sd_path[0] = '\0';
            reply(550, "Not found");
            return;
        }
        reply(350, "Ready for destination");
        return;
    }
    if (strcmp(verb, "RNTO") == 0) {
        char next[240];
        char sd[320];
        if (!g.sd_path[0] || !arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) ||
            !to_sdmc(next, sd, sizeof(sd))) {
            reply(503, "No rename from");
            return;
        }
        if (rename(g.sd_path, sd) != 0) {
            reply(550, "Can't rename");
            return;
        }
        g.sd_path[0] = '\0';
        mark_changed(next);
        reply(250, "Renamed");
        return;
    }
    if (strcmp(verb, "SIZE") == 0) {
        char next[240];
        struct stat st;
        if (!arg[0] || !normalize_path(next, sizeof(next), g.cwd, arg) || !path_stat(next, &st) || S_ISDIR(st.st_mode)) {
            reply(550, "Not a file");
            return;
        }
        char body[40];
        snprintf(body, sizeof(body), "%llu", (unsigned long long)st.st_size);
        reply(213, body);
        return;
    }
    if (strcmp(verb, "REST") == 0) {
        char *end = NULL;
        unsigned long long off = strtoull(arg, &end, 10);
        if (!arg[0] || (end && *end)) {
            reply(501, "Bad restart");
            return;
        }
        g.rest = (u64)off;
        char body[48];
        snprintf(body, sizeof(body), "Restart at %llu", off);
        reply(350, body);
        return;
    }
    if (strcmp(verb, "PASV") == 0) {
        if (!open_pasv()) {
            reply(425, "Can't open passive port");
            return;
        }
        reply_pasv();
        return;
    }
    if (strcmp(verb, "EPSV") == 0) {
        if (!open_pasv()) {
            reply(425, "Can't open passive port");
            return;
        }
        char body[64];
        snprintf(body, sizeof(body), "Entering Extended Passive Mode (|||%u|)", (unsigned)g.data_port);
        /* open_pasv stored the bound port in g.data_port, then we must not
         * advertise the already-incremented value. Re-read the socket. */
        struct sockaddr_in bound;
        socklen_t bl = sizeof(bound);
        if (getsockname(g.data_listen, (struct sockaddr *)&bound, &bl) == 0) {
            snprintf(body, sizeof(body), "Entering Extended Passive Mode (|||%u|)", (unsigned)ntohs(bound.sin_port));
        }
        reply(229, body);
        g.data_port++;
        if (g.data_port < 5001 || g.data_port > 64000) g.data_port = 5001;
        return;
    }
    if (strcmp(verb, "PORT") == 0) {
        unsigned h1, h2, h3, h4, p1, p2;
        if (sscanf(arg, "%u,%u,%u,%u,%u,%u", &h1, &h2, &h3, &h4, &p1, &p2) != 6 ||
            h1 > 255 || h2 > 255 || h3 > 255 || h4 > 255 || p1 > 255 || p2 > 255) {
            reply(501, "Bad PORT");
            return;
        }
        close_fd(&g.data_listen);
        close_fd(&g.data_fd);
        memset(&g.active, 0, sizeof(g.active));
        g.active.sin_family = AF_INET;
        g.active.sin_port = htons((u16)(p1 * 256u + p2));
        char ipbuf[32];
        snprintf(ipbuf, sizeof(ipbuf), "%u.%u.%u.%u", h1, h2, h3, h4);
        if (inet_pton(AF_INET, ipbuf, &g.active.sin_addr) != 1) {
            reply(501, "Bad PORT");
            return;
        }
        g.use_active = true;
        reply(200, "PORT ok");
        return;
    }
    if (strcmp(verb, "EPRT") == 0) {
        /* |1|192.168.0.2|5001| */
        if (arg[0] != '|' || arg[1] != '1' || arg[2] != '|') {
            reply(522, "Only IPv4");
            return;
        }
        const char *ip = arg + 3;
        const char *bar = strchr(ip, '|');
        if (!bar || !bar[1]) {
            reply(501, "Bad EPRT");
            return;
        }
        char ipbuf[40];
        size_t n = (size_t)(bar - ip);
        if (n == 0 || n >= sizeof(ipbuf)) {
            reply(501, "Bad EPRT");
            return;
        }
        memcpy(ipbuf, ip, n);
        ipbuf[n] = '\0';
        unsigned port = (unsigned)strtoul(bar + 1, NULL, 10);
        if (port == 0 || port > 65535) {
            reply(501, "Bad EPRT");
            return;
        }
        close_fd(&g.data_listen);
        close_fd(&g.data_fd);
        memset(&g.active, 0, sizeof(g.active));
        g.active.sin_family = AF_INET;
        g.active.sin_port = htons((u16)port);
        if (inet_pton(AF_INET, ipbuf, &g.active.sin_addr) != 1) {
            reply(501, "Bad EPRT");
            return;
        }
        g.use_active = true;
        reply(200, "EPRT ok");
        return;
    }
    if (strcmp(verb, "LIST") == 0 || strcmp(verb, "NLST") == 0) {
        if (g.xfer != XFER_NONE) {
            reply(425, "Transfer already open");
            return;
        }
        if (!g.use_active && g.data_listen < 0 && g.data_fd < 0) {
            reply(425, "Use PASV or PORT first");
            return;
        }
        start_list(false);
        return;
    }
    if (strcmp(verb, "MLSD") == 0) {
        if (!g.use_active && g.data_listen < 0 && g.data_fd < 0) {
            reply(425, "Use PASV or PORT first");
            return;
        }
        start_list(true);
        return;
    }
    if (strcmp(verb, "RETR") == 0) {
        if (!g.use_active && g.data_listen < 0 && g.data_fd < 0) {
            reply(425, "Use PASV or PORT first");
            return;
        }
        start_retr(arg);
        return;
    }
    if (strcmp(verb, "STOR") == 0 || strcmp(verb, "APPE") == 0) {
        if (!g.use_active && g.data_listen < 0 && g.data_fd < 0) {
            reply(425, "Use PASV or PORT first");
            return;
        }
        start_stor(arg, strcmp(verb, "APPE") == 0);
        return;
    }
    if (strcmp(verb, "ABOR") == 0) {
        if (g.xfer != XFER_NONE) finish_xfer(false, "Aborted");
        else reply(226, "No transfer");
        return;
    }
    if (strcmp(verb, "ALLO") == 0) {
        reply(202, "OK");
        return;
    }
    reply(502, "Not implemented");
}

static void take_lines(void) {
    int start = 0;
    for (int i = 0; i < g.inlen; i++) {
        if (g.inbuf[i] != '\n') continue;
        g.inbuf[i] = '\0';
        if (i > start && g.inbuf[i - 1] == '\r') g.inbuf[i - 1] = '\0';
        if (g.xfer != XFER_NONE && strcmp(g.inbuf + start, "ABOR") == 0) {
            finish_xfer(false, "Aborted");
        } else if (g.xfer != XFER_NONE) {
            /* A pipelined command waits until this transfer ends. Put it back. */
            g.inbuf[i] = '\n';
            if (start > 0) {
                memmove(g.inbuf, g.inbuf + start, (size_t)(g.inlen - start));
                g.inlen -= start;
            }
            return;
        } else {
            handle(g.inbuf + start);
            if (g.ctrl < 0) {
                g.inlen = 0;
                return;
            }
        }
        start = i + 1;
    }
    if (start > 0) {
        memmove(g.inbuf, g.inbuf + start, (size_t)(g.inlen - start));
        g.inlen -= start;
    }
    if (g.inlen >= (int)sizeof(g.inbuf) - 1) g.inlen = 0;
}

static void read_ctrl(void) {
    if (g.ctrl < 0 || g.outlen > 0) return;
    if (g.inlen >= (int)sizeof(g.inbuf) - 1) return;
    int n = recv(g.ctrl, g.inbuf + g.inlen, sizeof(g.inbuf) - 1 - g.inlen, 0);
    if (n < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return;
        drop_client("Client lost");
        return;
    }
    if (n == 0) {
        drop_client("Client left");
        return;
    }
    g.inlen += n;
    g.inbuf[g.inlen] = '\0';
    take_lines();
}

static void pump(void) {
    if (g.xfer == XFER_NONE) return;
    if (g.xfer == XFER_WAIT) {
        bool ready = false;
        if (g.data_listen >= 0) ready = accept_data();
        else if (g.use_active) {
            if (g.data_fd < 0 && !connect_active() && g.data_fd < 0) {
                finish_xfer(false, "Can't open data connection");
                return;
            }
            ready = g.data_fd >= 0 && active_ready();
        } else if (g.data_fd >= 0) {
            ready = true;
        }
        if (!ready) {
            if (osGetTime() > g.xfer_deadline) finish_xfer(false, "Data connection timed out");
            return;
        }
        g.xfer = g.xfer_kind;
        if (g.xfer == XFER_LIST && !g.dir) {
            finish_xfer(true, NULL);
            return;
        }
    }

    int budget = 256 * 1024;
    if (g.xfer == XFER_LIST) {
        while (budget > 0 && g.data_fd >= 0) {
            if (g.chunk_pos < g.chunk_len) {
                int before = g.chunk_pos;
                if (!send_blocked(g.data_fd, g.chunk + g.chunk_pos, g.chunk_len - g.chunk_pos, &g.chunk_pos)) {
                    finish_xfer(false, "Send failed");
                    return;
                }
                budget -= g.chunk_pos - before;
                if (g.chunk_pos < g.chunk_len) return;
                g.chunk_len = 0;
                g.chunk_pos = 0;
            }
            if (!g.dir || !list_one(g.mlsd == 1)) {
                finish_xfer(true, NULL);
                return;
            }
        }
        return;
    }
    if (g.xfer == XFER_RETR && g.fp && g.data_fd >= 0) {
        while (budget > 0) {
            if (g.chunk_pos >= g.chunk_len) {
                size_t got = fread(g.chunk, 1, CHUNK, g.fp);
                g.chunk_len = (int)got;
                g.chunk_pos = 0;
                if (got == 0) {
                    finish_xfer(true, NULL);
                    return;
                }
            }
            int before = g.chunk_pos;
            if (!send_blocked(g.data_fd, g.chunk + g.chunk_pos, g.chunk_len - g.chunk_pos, &g.chunk_pos)) {
                finish_xfer(false, "Send failed");
                return;
            }
            int moved = g.chunk_pos - before;
            g.xfer_done += (u64)moved;
            budget -= moved;
            if (g.chunk_pos < g.chunk_len) return;
        }
        return;
    }
    if (g.xfer == XFER_STOR && g.fp && g.data_fd >= 0) {
        while (budget > 0) {
            int n = recv(g.data_fd, g.chunk, CHUNK, 0);
            if (n < 0) {
                if (errno == EAGAIN || errno == EWOULDBLOCK) return;
                finish_xfer(false, "Receive failed");
                return;
            }
            if (n == 0) {
                char name[64];
                snprintf(name, sizeof(name), "%s", g.xfer_name);
                mark_changed(name);
                finish_xfer(true, NULL);
                return;
            }
            size_t put = fwrite(g.chunk, 1, (size_t)n, g.fp);
            g.xfer_done += (u64)put;
            budget -= n;
            if (put != (size_t)n) {
                finish_xfer(false, "SD write failed");
                return;
            }
        }
    }
}

static void accept_client(void) {
    if (g.listen_fd < 0 || g.ctrl >= 0) return;
    struct sockaddr_in peer;
    socklen_t sl = sizeof(peer);
    int fd = accept(g.listen_fd, (struct sockaddr *)&peer, &sl);
    if (fd < 0) return;
    set_nb(fd);
    nodelay(fd);
    g.ctrl = fd;
    inet_ntop(AF_INET, &peer.sin_addr, g.peer, sizeof(g.peer));
    snprintf(g.cwd, sizeof(g.cwd), "/");
    g.rest = 0;
    note("Client connected");
    set_status("Client connected");
    char hello[64];
    snprintf(hello, sizeof(hello), "Cinder %s FTP", CINDER_VERSION);
    reply(220, hello);
}

static void refresh_ip(void) {
    struct in_addr ip, mask, bcast;
    memset(&ip, 0, sizeof(ip));
    if (g.soc && SOCU_GetIPInfo(&ip, &mask, &bcast) == 0) inet_ntop(AF_INET, &ip, g.ip, sizeof(g.ip));
    if (!g.ip[0]) snprintf(g.ip, sizeof(g.ip), "0.0.0.0");
    if (strcmp(g.ip, "0.0.0.0") == 0) {
        if (g.ctrl < 0) set_status("Wi-Fi is off. Press Y to retry.");
    } else if (g.ctrl < 0 && g.xfer == XFER_NONE) {
        set_status("Listening");
    }
}

Result ftp_start(void) {
    ensure_init();
    if (g.running) {
        refresh_ip();
        return 0;
    }

    if (!g.ac_up) {
        if (R_SUCCEEDED(acInit())) g.ac_up = true;
    }

    if (!g.soc) {
        g.soc = (u32 *)memalign(SOC_ALIGN, SOC_SIZE);
        if (!g.soc) {
            set_status("Out of memory");
            return -1;
        }
        Result rc = socInit(g.soc, SOC_SIZE);
        if (R_FAILED(rc)) {
            free(g.soc);
            g.soc = NULL;
            set_status("Wi-Fi is off");
            return rc;
        }
    }

    refresh_ip();

    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (fd < 0) {
        set_status("Can't open a socket");
        return -1;
    }
    int on = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(FTP_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(fd, 1) != 0) {
        close(fd);
        set_status("Port 5000 is in use");
        return -1;
    }
    set_nb(fd);
    g.listen_fd = fd;
    g.running = true;
    refresh_ip();
    if (strcmp(g.status, "Wi-Fi is off. Press Y to retry.") != 0 && g.status[0] == '\0') set_status("Listening");
    if (strcmp(g.ip, "0.0.0.0") != 0 && strcmp(g.status, "Wi-Fi is off. Press Y to retry.") != 0) set_status("Listening");
    note("Listening");
    return 0;
}

void ftp_stop(void) {
    ensure_init();
    clear_data();
    close_fd(&g.ctrl);
    close_fd(&g.listen_fd);
    g.inlen = 0;
    g.outlen = 0;
    g.running = false;
    g.peer[0] = '\0';
    g.rest = 0;
    if (g.soc) {
        socExit();
        free(g.soc);
        g.soc = NULL;
    }
    set_status("Stopped");
}

void ftp_poll(void) {
    ensure_init();
    if (!g.running) return;
    if (!flush_out() && g.ctrl < 0) return;
    accept_client();
    read_ctrl();
    pump();
    if (g.xfer == XFER_NONE && g.ctrl >= 0 && g.inlen > 0) take_lines();
}

void ftp_info(FtpInfo *out) {
    ensure_init();
    memset(out, 0, sizeof(*out));
    out->running = g.running;
    out->client = g.ctrl >= 0;
    snprintf(out->ip, sizeof(out->ip), "%s", g.ip);
    snprintf(out->status, sizeof(out->status), "%s", g.status);
    snprintf(out->cwd, sizeof(out->cwd), "%s", g.cwd[0] ? g.cwd : "/");
    snprintf(out->peer, sizeof(out->peer), "%s", g.peer);
    snprintf(out->xfer_name, sizeof(out->xfer_name), "%s", g.xfer == XFER_NONE ? "" : g.xfer_name);
    out->xfer_done = g.xfer == XFER_NONE ? 0 : g.xfer_done;
    out->xfer_total = g.xfer == XFER_NONE ? 0 : g.xfer_total;
    out->log_count = g.log_count;
    for (int i = 0; i < g.log_count; i++) snprintf(out->log[i], sizeof(out->log[i]), "%s", g.log[i]);
}

bool ftp_sd_changed(void) {
    ensure_init();
    bool was = g.sd_changed;
    g.sd_changed = false;
    return was;
}
