#!/usr/bin/env python3
"""Build the HOME Menu banner.

The menu plays its built-in sound when the wave is set to loop. The working
form is stereo 16-bit PCM, under 3 seconds, and not looping. bannertool's
-a path writes exactly that.
"""
import struct
import subprocess
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
PNG = HERE / "banner.png"
WAV = HERE / "banner.wav"
OUT = HERE / "banner.bin"

if not WAV.exists() or WAV.stat().st_size < 64:
    raise SystemExit(f"missing banner audio: {WAV}")

with wave.open(str(WAV), "rb") as handle:
    if handle.getnchannels() != 2 or handle.getsampwidth() != 2:
        raise SystemExit("banner wav must be stereo 16-bit")
    frames = handle.getnframes()
    rate = handle.getframerate()
seconds = frames / rate
if not (0 < seconds < 3.0):
    raise SystemExit(f"banner audio is {seconds:.3f}s, must be under 3 seconds")

subprocess.check_call(
    ["bannertool", "makebanner", "-i", str(PNG), "-a", str(WAV), "-o", str(OUT)]
)

blob = OUT.read_bytes()
cwav_off = struct.unpack_from("<I", blob, 0x84)[0]
if blob[cwav_off:cwav_off + 4] != b"CWAV":
    raise SystemExit("banner has no wave")
info = blob[cwav_off + 0x40 :]
channels = struct.unpack_from("<I", info, 0x1C)[0]
loop = info[9]
if channels != 2 or loop != 0:
    raise SystemExit(f"banner audio is channels={channels} loop={loop}, want stereo and not looping")
print(f"banner {len(blob)} bytes, {channels}ch loop={loop}, {seconds:.2f}s at {rate} Hz")
