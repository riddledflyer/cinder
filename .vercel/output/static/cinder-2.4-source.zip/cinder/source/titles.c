#include "titles.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Old 3DS application memory is 64MB. The reserved heap is 4MB.
 * The list, the id table, and the AM info table are all live at once. */
_Static_assert(TITLE_CAP <= 1024, "title cap");
_Static_assert(
    sizeof(TitleRec) * TITLE_CAP + sizeof(u64) * TITLE_CAP + sizeof(AM_TitleInfo) * TITLE_CAP < 1024 * 1024,
    "title load must stay under 1MB of the 4MB heap");

u64 titles_self_id(void) {
    s64 info = 0;
    /* 0x10001 is the running title id (GetProcessInfo). */
    if (R_SUCCEEDED(svcGetProcessInfo(&info, CUR_PROCESS_HANDLE, 0x10001)) && info != 0) {
        return (u64)info;
    }
    return CINDER_TITLE_ID;
}

bool titles_is_system_id(u64 id) {
    /* These highs are modules, applets, and system data. A game Nintendo
     * published is 00040000 (or a demo, update, or DLC high) and is not
     * in this list. Homebrew that does not use one of these highs is not
     * system software either. */
    switch ((u32)(id >> 32)) {
        case 0x00040010:
        case 0x0004001B:
        case 0x00040030:
        case 0x0004009B:
        case 0x000400DB:
        case 0x00040130:
        case 0x00040138:
        case 0x0004013F:
        case 0x00030005:
        case 0x0003000F:
        case 0x00030015:
        case 0x00030017:
        case 0x00048005:
        case 0x0004800F:
            return true;
        default:
            return false;
    }
}

TitleKind titles_kind_of(u64 id) {
    switch ((u32)(id >> 32)) {
        case 0x00040000: return KIND_GAME;
        case 0x00040002: return KIND_DEMO;
        case 0x0004000E: return KIND_UPDATE;
        case 0x0004008C: return KIND_DLC;
        case 0x00048004:
        case 0x00030004: return KIND_DSIWARE;
        default: return titles_is_system_id(id) ? KIND_SYSTEM : KIND_GAME;
    }
}

static int kind_rank(TitleKind kind) {
    switch (kind) {
        case KIND_GAME: return 0;
        case KIND_DEMO: return 1;
        case KIND_UPDATE: return 2;
        case KIND_DLC: return 3;
        case KIND_DSIWARE: return 4;
        default: return 5;
    }
}

static int cmp_title(const void *a, const void *b) {
    const TitleRec *ta = a;
    const TitleRec *tb = b;
    int rank = kind_rank(ta->kind) - kind_rank(tb->kind);
    if (rank != 0) return rank;
    return strcmp(ta->name, tb->name);
}

const char *titles_kind_name(TitleKind kind) {
    switch (kind) {
        case KIND_GAME: return "Game";
        case KIND_DEMO: return "Demo";
        case KIND_UPDATE: return "Update";
        case KIND_DLC: return "DLC";
        case KIND_DSIWARE: return "NDS";
        default: return "System";
    }
}

char titles_kind_char(TitleKind kind) {
    switch (kind) {
        case KIND_GAME: return 'G';
        case KIND_DEMO: return 'M';
        case KIND_UPDATE: return 'U';
        case KIND_DLC: return 'D';
        case KIND_DSIWARE: return 'W';
        default: return 'S';
    }
}

void titles_format_size(char *out, size_t n, u64 bytes) {
    const unsigned long long b = (unsigned long long)bytes;
    if (b < 1024ull) {
        snprintf(out, n, "%lluB", b);
    } else if (b < 1024ull * 1024ull) {
        snprintf(out, n, "%lluKB", (b + 1023ull) / 1024ull);
    } else if (b < 1024ull * 1024ull * 1024ull) {
        unsigned long long tenths = (b * 10ull) / (1024ull * 1024ull);
        snprintf(out, n, "%llu.%lluMB", tenths / 10ull, tenths % 10ull);
    } else {
        unsigned long long tenths = (b * 10ull) / (1024ull * 1024ull * 1024ull);
        snprintf(out, n, "%llu.%lluGB", tenths / 10ull, tenths % 10ull);
    }
}

void titles_format_version(char *out, size_t n, u16 version) {
    unsigned major = (version >> 10) & 0x3F;
    unsigned minor = (version >> 4) & 0x3F;
    unsigned micro = version & 0xF;
    snprintf(out, n, "%u.%u.%u", major, minor, micro);
}

Result titles_load(TitleList *list, FS_MediaType media) {
    memset(list, 0, sizeof(*list));
    list->media = media;

    u32 count = 0;
    Result rc = AM_GetTitleCount(media, &count);
    if (R_FAILED(rc) || count == 0) return rc;
    if (count > TITLE_CAP) count = TITLE_CAP;

    u64 *ids = calloc(count, sizeof(u64));
    AM_TitleInfo *info = calloc(count, sizeof(AM_TitleInfo));
    TitleRec *items = calloc(count, sizeof(TitleRec));
    if (!ids || !info || !items) {
        free(ids);
        free(info);
        free(items);
        return (Result)0xC86044D2; /* out of memory, app-level */
    }

    u32 read = 0;
    rc = AM_GetTitleList(&read, media, count, ids);
    if (R_SUCCEEDED(rc)) rc = AM_GetTitleInfo(media, read, ids, info);
    if (R_FAILED(rc) || read == 0) {
        free(ids);
        free(info);
        free(items);
        return rc;
    }

    u8 language = CFG_LANGUAGE_EN;
    if (R_SUCCEEDED(cfguInit())) {
        CFGU_GetSystemLanguage(&language);
        cfguExit();
    }

    u64 self = titles_self_id();
    u32 kept = 0;
    for (u32 i = 0; i < read; i++) {
        u64 id = info[i].titleID != 0 ? info[i].titleID : ids[i];
        TitleKind kind = titles_kind_of(id);
        if (kind == KIND_SYSTEM) continue;
        if (id == self || id == CINDER_TITLE_ID) continue;

        TitleRec *title = &items[kept++];
        memset(title, 0, sizeof(*title));
        title->id = id;
        title->media = media;
        title->size = info[i].size;
        title->version = info[i].version;
        title->kind = kind;
        title->selected = false;
        title->deletable = true;
        smdh_fill_names(title, language);
    }

    if (kept > 1) qsort(items, kept, sizeof(TitleRec), cmp_title);
    free(ids);
    free(info);
    if (kept == 0) {
        free(items);
        return 0;
    }
    if (kept < read) {
        TitleRec *shrunk = realloc(items, kept * sizeof(TitleRec));
        if (shrunk) items = shrunk;
    }
    list->items = items;
    list->count = kept;
    return 0;
}

void titles_free(TitleList *list) {
    if (list->items) {
        for (u32 i = 0; i < list->count; i++) {
            free(list->items[i].icon);
            free(list->items[i].anim);
        }
    }
    free(list->items);
    list->items = NULL;
    list->count = 0;
    dsi_shutdown();
}

static void absorb(TitleList *dst, TitleList *src) {
    if (!src->items || src->count == 0) {
        titles_free(src);
        return;
    }
    TitleRec *merged = realloc(dst->items, (dst->count + src->count) * sizeof(TitleRec));
    if (!merged) {
        titles_free(src);
        return;
    }
    memcpy(merged + dst->count, src->items, src->count * sizeof(TitleRec));
    dst->items = merged;
    dst->count += src->count;
    free(src->items);
    src->items = NULL;
    src->count = 0;
}

Result titles_load_all(TitleList *list) {
    TitleList sd;
    TitleList nand;
    memset(&sd, 0, sizeof(sd));
    memset(&nand, 0, sizeof(nand));
    Result sd_rc = titles_load(&sd, MEDIATYPE_SD);
    Result nand_rc = titles_load(&nand, MEDIATYPE_NAND);
    memset(list, 0, sizeof(*list));
    if (R_SUCCEEDED(sd_rc)) absorb(list, &sd);
    else titles_free(&sd);
    if (R_SUCCEEDED(nand_rc)) absorb(list, &nand);
    else titles_free(&nand);
    if (list->count > 1) qsort(list->items, list->count, sizeof(TitleRec), cmp_title);
    if (R_FAILED(sd_rc) && R_FAILED(nand_rc)) return sd_rc;
    return 0;
}

static bool id_in(const u64 *ids, u32 count, u64 id) {
    for (u32 i = 0; i < count; i++) {
        if (ids[i] == id) return true;
    }
    return false;
}

u32 titles_collect(const TitleList *list, u64 *out, u32 cap, bool include_related) {
    u32 count = 0;
    if (!list->items || cap == 0) return 0;

    for (u32 i = 0; i < list->count && count < cap; i++) {
        const TitleRec *title = &list->items[i];
        if (title->selected && title->deletable) out[count++] = title->id;
    }

    if (!include_related) return count;

    for (u32 i = 0; i < list->count; i++) {
        const TitleRec *base = &list->items[i];
        if (!base->selected || !base->deletable) continue;
        if (base->kind != KIND_GAME && base->kind != KIND_DEMO) continue;
        u32 low = (u32)base->id;
        for (u32 j = 0; j < list->count && count < cap; j++) {
            const TitleRec *other = &list->items[j];
            if (!other->deletable || other->media != base->media) continue;
            if (other->kind != KIND_UPDATE && other->kind != KIND_DLC) continue;
            if ((u32)other->id != low) continue;
            if (id_in(out, count, other->id)) continue;
            out[count++] = other->id;
        }
    }
    return count;
}

Result titles_delete(FS_MediaType media, const u64 *ids, u32 count, bool tickets,
                     TitleProgressFn progress, void *user) {
    u32 done = 0;
    Result last_fail = 0;
    bool any_fail = false;

    while (done < count) {
        if (!aptMainLoop()) break;
        u32 n = count - done;
        if (n > DELETE_CHUNK) n = DELETE_CHUNK;

        Result batch = AM_DeleteUserTitles((u64 *)(ids + done), n, media);
        if (R_SUCCEEDED(batch)) {
            for (u32 i = 0; i < n; i++) {
                bool ticket_ok = true;
                if (tickets) ticket_ok = R_SUCCEEDED(AM_DeleteTicket(ids[done + i]));
                if (progress) progress(done + i, count, ids[done + i], 0, ticket_ok, user);
            }
        } else {
            for (u32 i = 0; i < n; i++) {
                Result one = AM_DeleteUserTitle(media, ids[done + i]);
                bool ticket_ok = true;
                if (R_SUCCEEDED(one) && tickets) ticket_ok = R_SUCCEEDED(AM_DeleteTicket(ids[done + i]));
                if (R_FAILED(one)) {
                    any_fail = true;
                    last_fail = one;
                }
                if (progress) progress(done + i, count, ids[done + i], one, ticket_ok, user);
            }
        }
        done += n;
    }

    return any_fail ? last_fail : 0;
}
