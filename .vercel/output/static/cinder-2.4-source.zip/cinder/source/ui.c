#include "ui.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/* Linked from libctru. 8x8, 256 glyphs, bit 7 is the left pixel, byte 0 is the top row. */
extern const u8 default_font_bin[];

typedef struct {
    gfxScreen_t screen;
    u8 *fb;
    u16 stride;
    int cols;
    int rows;
    int cx;
    int cy;
    int pix_w;
    int pix_h;
} UiState;

static UiState g_ui;

static void bind_screen(gfxScreen_t screen) {
    u16 pw = 0;
    u16 ph = 0;
    g_ui.screen = screen;
    g_ui.fb = gfxGetFramebuffer(screen, GFX_LEFT, &pw, &ph);
    g_ui.stride = pw ? pw : 240;
    g_ui.pix_w = ph ? ph : (screen == GFX_TOP ? 400 : 320);
    g_ui.pix_h = pw ? pw : 240;
    g_ui.cols = g_ui.pix_w / 8;
    g_ui.rows = g_ui.pix_h / 8;
    if (g_ui.cols < 1) g_ui.cols = 1;
    if (g_ui.rows < 1) g_ui.rows = 1;
}

void ui_init(void) {
    /* 24-bit linear buffers. Byte stores are legal here; VRAM is not.
     * Double buffered, 2D, not wide. This is the path the LCD actually scans. */
    gfxInitDefault();
    gfxSet3D(false);
    gfxSetWide(false);
    memset(&g_ui, 0, sizeof(g_ui));
    for (int i = 0; i < 2; i++) {
        ui_select(GFX_TOP);
        ui_clear();
        ui_select(GFX_BOTTOM);
        ui_clear();
        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }
}

void ui_select(gfxScreen_t screen) {
    bind_screen(screen);
}

void ui_clear(void) {
    u16 pw = 0;
    u16 ph = 0;
    g_ui.fb = gfxGetFramebuffer(g_ui.screen, GFX_LEFT, &pw, &ph);
    g_ui.stride = pw ? pw : 240;
    g_ui.pix_w = ph ? ph : g_ui.pix_w;
    g_ui.pix_h = pw ? pw : 240;
    g_ui.cols = g_ui.pix_w / 8;
    g_ui.rows = g_ui.pix_h / 8;
    if (g_ui.cols < 1) g_ui.cols = 1;
    if (g_ui.rows < 1) g_ui.rows = 1;
    if (g_ui.fb && pw && ph) memset(g_ui.fb, 0, (size_t)pw * ph * 3);
    g_ui.cx = 0;
    g_ui.cy = 0;
}

static void put_px(int lx, int ly, int on) {
    u8 *p = g_ui.fb + ((size_t)lx * g_ui.stride + (239 - ly)) * 3;
    u8 v = on ? 192 : 0;
    p[0] = v;
    p[1] = v;
    p[2] = v;
}

static void draw_glyph(int c) {
    if (c < 0 || c > 255) c = ' ';
    const u8 *glyph = default_font_bin + (c * 8);
    int x = g_ui.cx * 8;
    int y = g_ui.cy * 8;
    for (int col = 0; col < 8; col++) {
        u8 mask = (u8)(0x80 >> col);
        for (int row = 0; row < 8; row++) {
            if (glyph[row] & mask) put_px(x + col, y + row, 1);
        }
    }
}

static void putc_ui(unsigned char c) {
    if (c == '\n') {
        g_ui.cx = 0;
        g_ui.cy++;
        return;
    }
    if (c == '\r') {
        g_ui.cx = 0;
        return;
    }
    if (g_ui.cx >= g_ui.cols) {
        g_ui.cx = 0;
        g_ui.cy++;
    }
    if (g_ui.cy < 0 || g_ui.cy >= g_ui.rows) return;
    if (c >= 32) draw_glyph(c);
    g_ui.cx++;
}

void ui_printf(const char *fmt, ...) {
    char buf[192];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    for (char *s = buf; *s; s++) putc_ui((unsigned char)*s);
}

void ui_present(void) {
    gfxFlushBuffers();
    gfxSwapBuffers();
    gspWaitForVBlank();
}

static void px(int x, int y, u8 r, u8 g, u8 b) {
    if (!g_ui.fb || x < 0 || y < 0 || x >= g_ui.pix_w || y >= g_ui.pix_h) return;
    u8 *p = g_ui.fb + ((size_t)x * g_ui.stride + (g_ui.pix_h - 1 - y)) * 3;
    p[0] = b;
    p[1] = g;
    p[2] = r;
}

void ui_size(int *width, int *height) {
    if (width) *width = g_ui.pix_w;
    if (height) *height = g_ui.pix_h;
}

void ui_fill(int x, int y, int w, int h, u8 r, u8 g, u8 b) {
    if (w <= 0 || h <= 0) return;
    for (int row = 0; row < h; row++) {
        for (int col = 0; col < w; col++) px(x + col, y + row, r, g, b);
    }
}

static void glyph_at(int x, int y, int c, u8 r, u8 g, u8 b) {
    if (c < 0 || c > 255) c = ' ';
    const u8 *glyph = default_font_bin + (c * 8);
    for (int col = 0; col < 8; col++) {
        u8 mask = (u8)(0x80 >> col);
        for (int row = 0; row < 8; row++) {
            if (glyph[row] & mask) px(x + col, y + row, r, g, b);
        }
    }
}

int ui_text(int x, int y, const char *text, int max_chars, u8 r, u8 g, u8 b) {
    if (!text) return x;
    int drawn = 0;
    for (const unsigned char *s = (const unsigned char *)text; *s && drawn < max_chars; s++) {
        unsigned char c = *s;
        if (c < 32) continue;
        if (c >= 0x80) {
            if ((c & 0xE0) == 0xC0 && s[1]) s += 1;
            else if ((c & 0xF0) == 0xE0 && s[1] && s[2]) s += 2;
            else if ((c & 0xF8) == 0xF0 && s[1] && s[2] && s[3]) s += 3;
            c = '?';
        }
        glyph_at(x, y, c, r, g, b);
        x += 8;
        drawn++;
    }
    return x;
}

static void unpack565(u16 c, int *r, int *g, int *b) {
    int r5 = (c >> 11) & 31;
    int g6 = (c >> 5) & 63;
    int b5 = c & 31;
    *r = (r5 << 3) | (r5 >> 2);
    *g = (g6 << 2) | (g6 >> 4);
    *b = (b5 << 3) | (b5 >> 2);
}

static void put565(int x, int y, u16 c) {
    int r, g, b;
    unpack565(c, &r, &g, &b);
    px(x, y, (u8)r, (u8)g, (u8)b);
}

void ui_icon(int x, int y, const u16 *icon, int src_w, int size, bool key_zero) {
    if (size <= 0) return;
    if (!icon || src_w <= 0) {
        ui_fill(x, y, size, size, 36, 40, 52);
        return;
    }
    if (src_w == size) {
        for (int row = 0; row < size; row++) {
            const u16 *line = icon + row * src_w;
            for (int col = 0; col < size; col++) {
                u16 c = line[col];
                if (key_zero && c == 0) continue;
                put565(x + col, y + row, c);
            }
        }
        return;
    }
    for (int row = 0; row < size; row++) {
        int sy = row * src_w;
        int y0 = sy / size;
        int fy = ((sy % size) * 256) / size;
        if (y0 >= src_w) y0 = src_w - 1;
        int y1 = y0 + 1;
        if (y1 >= src_w) y1 = y0;
        for (int col = 0; col < size; col++) {
            int sx = col * src_w;
            int x0 = sx / size;
            int fx = ((sx % size) * 256) / size;
            if (x0 >= src_w) x0 = src_w - 1;
            int x1 = x0 + 1;
            if (x1 >= src_w) x1 = x0;

            u16 c00 = icon[y0 * src_w + x0];
            u16 c10 = icon[y0 * src_w + x1];
            u16 c01 = icon[y1 * src_w + x0];
            u16 c11 = icon[y1 * src_w + x1];
            if (key_zero && c00 == 0) continue;
            if (key_zero && (c10 == 0 || c01 == 0 || c11 == 0)) {
                put565(x + col, y + row, c00);
                continue;
            }
            int r00, g00, b00, r10, g10, b10, r01, g01, b01, r11, g11, b11;
            unpack565(c00, &r00, &g00, &b00);
            unpack565(c10, &r10, &g10, &b10);
            unpack565(c01, &r01, &g01, &b01);
            unpack565(c11, &r11, &g11, &b11);
            int w00 = (256 - fx) * (256 - fy);
            int w10 = fx * (256 - fy);
            int w01 = (256 - fx) * fy;
            int w11 = fx * fy;
            px(x + col, y + row,
               (u8)((r00 * w00 + r10 * w10 + r01 * w01 + r11 * w11) >> 16),
               (u8)((g00 * w00 + g10 * w10 + g01 * w01 + g11 * w11) >> 16),
               (u8)((b00 * w00 + b10 * w10 + b01 * w01 + b11 * w11) >> 16));
        }
    }
}
