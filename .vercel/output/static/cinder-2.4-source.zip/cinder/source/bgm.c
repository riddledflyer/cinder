#include "bgm.h"

#include <3ds.h>
#include <string.h>

/* data/bgm.bin, converted from the bundled track.
 * Mono signed PCM8 at 16 kHz. A 16-bit or stereo copy does not fit in the
 * 4 MB linear heap next to the framebuffers on an old 3DS. */
extern const u8 bgm_bin[];
extern const u8 bgm_bin_end[];

#define BGM_RATE 16000

static u8 *g_pcm;
static u32 g_play;
static u32 g_rate = BGM_RATE;
static bool g_on;
static int g_chn = -1;
static aptHookCookie g_hook;
static bool g_hooked;

static int owned_channel(void) {
    /* csndPlaySound refuses any channel not in this mask, and it returns 1.
     * That is not a negative Result, so it looks like success and nothing plays.
     * Channel 0 is usually absent from the mask. */
    for (int ch = 0; ch < 32; ch++) {
        if (csndChannels & BIT(ch)) return ch;
    }
    return -1;
}

static void halt_channel(void) {
    if (g_chn < 0) return;
    CSND_SetVol(g_chn, 0, 0);
    CSND_SetPlayState(g_chn, 0);
    csndExecCmds(true);
}

static void resume_channel(void) {
    if (!g_on || !g_pcm || g_chn < 0 || g_play < 64) return;
    Result rc = csndPlaySound(g_chn, SOUND_FORMAT_8BIT | SOUND_REPEAT, g_rate, 1.0f, 0.0f,
                               g_pcm, g_pcm, g_play);
    if (rc != 0) return;
    CSND_SetVol(g_chn, 0x80008000u, 0);
    csndExecCmds(true);
}

static void apt_event(APT_HookType hook, void *param) {
    (void)param;
    if (hook == APTHOOK_ONSUSPEND || hook == APTHOOK_ONSLEEP || hook == APTHOOK_ONEXIT) halt_channel();
    else if (hook == APTHOOK_ONRESTORE || hook == APTHOOK_ONWAKEUP) resume_channel();
}

void bgm_start(void) {
    u32 size = (u32)(bgm_bin_end - bgm_bin);
    if (size < 64) return;
    if (R_FAILED(csndInit())) return;

    int ch = owned_channel();
    if (ch < 0) {
        csndExit();
        return;
    }

    u32 step = 1;
    u32 freeb = linearSpaceFree();
    while (step < 8 && size / step + 0x2000 > freeb) step++;
    u32 play = size / step;
    play &= ~3u;
    if (play < 64) {
        csndExit();
        return;
    }

    g_pcm = linearAlloc(play);
    if (!g_pcm) {
        csndExit();
        return;
    }
    if (step == 1) {
        memcpy(g_pcm, bgm_bin, play);
    } else {
        for (u32 i = 0; i < play; i++) g_pcm[i] = bgm_bin[i * step];
    }
    GSPGPU_FlushDataCache(g_pcm, play);

    g_rate = BGM_RATE / step;
    g_play = play;
    g_chn = ch;
    Result rc = csndPlaySound(ch, SOUND_FORMAT_8BIT | SOUND_REPEAT, g_rate, 1.0f, 0.0f, g_pcm, g_pcm, play);
    if (rc != 0) {
        linearFree(g_pcm);
        g_pcm = NULL;
        g_chn = -1;
        csndExit();
        return;
    }
    /* 1.0 at center pan only reaches half scale on each speaker. */
    CSND_SetVol(ch, 0x80008000u, 0);
    csndExecCmds(true);
    if (!g_hooked) {
        aptHook(&g_hook, apt_event, NULL);
        g_hooked = true;
    }
    g_on = true;
}

void bgm_stop(void) {
    if (!g_on && !g_pcm && g_chn < 0) return;
    /* SetPlayState only queues the stop. Without a flush, csndExit leaves
     * the channel running after the process is gone. */
    for (int ch = 0; ch < 32; ch++) {
        if (csndChannels & BIT(ch)) {
            CSND_SetVol(ch, 0, 0);
            CSND_SetPlayState(ch, 0);
        }
    }
    csndExecCmds(true);
    if (g_pcm && g_play) {
        memset(g_pcm, 0, g_play);
        GSPGPU_FlushDataCache(g_pcm, g_play);
    }
    svcSleepThread(20000000);
    if (g_hooked) {
        aptUnhook(&g_hook);
        g_hooked = false;
    }
    csndExit();
    if (g_pcm) linearFree(g_pcm);
    g_pcm = NULL;
    g_play = 0;
    g_chn = -1;
    g_on = false;
}
