#pragma once

/* Loops the bundled track. Silent if the sound service or linear heap refuses it. */
void bgm_start(void);
void bgm_stop(void);
