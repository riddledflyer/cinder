#pragma once

/* Loops the bundled track. Silent if the sound service or linear heap refuses it. */
void bgm_start(void);
/* Starts the track again if sleep closed the sound service. */
void bgm_poll(void);
void bgm_stop(void);
