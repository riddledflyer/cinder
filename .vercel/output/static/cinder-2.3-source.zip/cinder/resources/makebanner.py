#!/usr/bin/env python3
"""Build a banner the HOME Menu can play."""
import struct
import subprocess
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
PNG = HERE / "banner.png"
WAV = HERE / "banner.wav"
CWAV = HERE / "banner.bcwav"
OUT = HERE / "banner.bin"

# The menu plays its built-in sound unless the clip is stereo 16-bit PCM and
# strictly shorter than 3 seconds. One graphic is shared by every region so a
# missing slot cannot crash the menu, and the wave sits right after it.
if not WAV.exists() or WAV.stat().st_size < 64:
    raise SystemExit(f"missing banner audio: {WAV}")

with wave.open(str(WAV), "rb") as handle:
    if handle.getnchannels() != 2 or handle.getsampwidth() != 2:
        raise SystemExit("banner wav must be stereo 16-bit")
    frames = handle.getnframes()
    rate = handle.getframerate()
seconds = frames / rate
if seconds >= 3.0:
    raise SystemExit(f"banner audio is {seconds:.3f}s, must be under 3 seconds")

subprocess.check_call(
    [
        "bannertool", "makecwav",
        "-i", str(WAV),
        "-o", str(CWAV),
        "-l", "true",
        "-s", "0",
        "-f", str(frames - 1),
    ]
)
subprocess.check_call(
    ["bannertool", "makebanner", "-i", str(PNG), "-ca", str(CWAV), "-o", str(OUT)]
)

blob = bytearray(OUT.read_bytes())
cgfx = [struct.unpack_from("<I", blob, 8 + i * 4)[0] for i in range(14)]
shared = next((off for off in cgfx if off), 0)
if shared == 0:
    raise SystemExit("banner is missing its graphic")
for i, off in enumerate(cgfx):
    if off == 0:
        struct.pack_into("<I", blob, 8 + i * 4, shared)

cwav_off = struct.unpack_from("<I", blob, 0x84)[0]
# Loop end is the last sample, not one past it. One past makes the menu
# reject the wave and play the built-in sound instead.
struct.pack_into("<I", blob, cwav_off + 0x40 + 0x14, frames - 1)
OUT.write_bytes(blob)

blob = OUT.read_bytes()
cgfx = [struct.unpack_from("<I", blob, 8 + i * 4)[0] for i in range(14)]
info = blob[cwav_off + 0x40 :]
channels = struct.unpack_from("<I", info, 0x1C)[0]
loop_end = struct.unpack_from("<I", info, 0x14)[0]
if any(off == 0 for off in cgfx):
    raise SystemExit("banner is missing a region graphic")
if channels != 2 or info[9] != 1 or loop_end != frames - 1:
    raise SystemExit(
        f"banner audio is channels={channels} loop={info[9]} end={loop_end}, want stereo looping"
    )
print(
    f"banner {len(blob)} bytes, {channels}ch loop=1, "
    f"{seconds:.2f}s at {rate} Hz, cwav at {cwav_off:#x}"
)
