#pragma once

/* Shown on the top screen and on the HOME Menu icon.
 * CINDER_REVISION is the CIA remaster version in resources/app.rsf.
 * The download is named cinder-<version>.cia (APP_VERSION in the Makefile).
 * Bump version, revision, APP_VERSION, and the web VERSION together. */
#define CINDER_VERSION "3.2"
#define CINDER_REVISION 32
