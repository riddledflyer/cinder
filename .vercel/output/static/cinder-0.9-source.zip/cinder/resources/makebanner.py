#!/usr/bin/env python3
"""Build a banner the HOME Menu can play: stereo looping audio, every region slot filled."""
import struct
import subprocess
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
PNG = HERE / "banner.png"
WAV = HERE / "banner.wav"
CWAV = HERE / "banner.bcwav"
OUT = HERE / "banner.bin"

# One second of stereo silence. Mono or non-looping banner audio crashes the menu.
FRAMES = 22050
with wave.open(str(WAV), "w") as handle:
    handle.setnchannels(2)
    handle.setsampwidth(2)
    handle.setframerate(22050)
    handle.writeframes(b"\x00\x00" * (FRAMES * 2))

subprocess.check_call(
    ["bannertool", "makecwav", "-i", str(WAV), "-o", str(CWAV), "-l", "true"]
)

# -i is the common graphic. The rest are the per-region slots. A zero slot
# makes some menus dereference the missing graphic instead of falling back.
slots = [
    "-eei", "-efi", "-egi", "-eii", "-esi", "-edi", "-epi",
    "-eri", "-jji", "-uei", "-ufi", "-usi", "-upi",
]
cmd = ["bannertool", "makebanner", "-i", str(PNG)]
for flag in slots:
    cmd.extend([flag, str(PNG)])
cmd.extend(["-ca", str(CWAV), "-o", str(OUT)])
subprocess.check_call(cmd)

blob = OUT.read_bytes()
cgfx = [struct.unpack_from("<I", blob, 8 + i * 4)[0] for i in range(14)]
cwav_off = struct.unpack_from("<I", blob, 0x84)[0]
info = blob[cwav_off + 0x40 :]
channels = struct.unpack_from("<I", info, 0x1C)[0]
loop = info[9]
if any(off == 0 for off in cgfx):
    raise SystemExit("banner is missing a region graphic")
if channels != 2 or loop != 1:
    raise SystemExit(f"banner audio is channels={channels} loop={loop}, want stereo looping")
print(f"banner {len(blob)} bytes, {channels}ch loop={loop}")
