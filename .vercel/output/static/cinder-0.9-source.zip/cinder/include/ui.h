#pragma once

#include <3ds.h>
#include <stdbool.h>

/* BGR8 text, redrawn into the current back buffer every frame.
 * libctru's console is RGB565 and the Old 3DS LCD was splitting those lines. */
void ui_init(void);
void ui_select(gfxScreen_t screen);
void ui_clear(void);
void ui_printf(const char *fmt, ...);
void ui_present(void);

/* Landscape pixel drawing into the selected screen. */
void ui_size(int *width, int *height);
void ui_fill(int x, int y, int w, int h, u8 r, u8 g, u8 b);
int ui_text(int x, int y, const char *text, int max_chars, u8 r, u8 g, u8 b);
/* Scales a square RGB565 icon (src_w by src_w) into a size x size box.
 * A blank tile if icon is NULL. Pixel 0 is left unpainted when key_zero is set
 * (DSiWare color 0). SMDH icons pass key_zero false so black stays black. */
void ui_icon(int x, int y, const u16 *icon, int src_w, int size, bool key_zero);
